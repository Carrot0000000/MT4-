$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class MtDemoReviewCapture {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int Left,Top,Right,Bottom;}
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd,out RECT rect);
 [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd,IntPtr hdc,uint flags);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd,int command);
}
'@
$mtReviewProc=Get-Process terminal | Where-Object Path -eq 'C:\Program Files (x86)\FP Markets MT4 Terminal\terminal.exe' | Select-Object -First 1
if(-not $mtReviewProc){throw 'MT4 not running'}
if($mtReviewProc.MainWindowTitle -notmatch '176318407: MetaQuotes-Demo'){throw 'The expected demo account is not active'}
[MtDemoReviewCapture]::ShowWindow($mtReviewProc.MainWindowHandle,9)|Out-Null
Start-Sleep -Milliseconds 200
$mtReviewRect=[MtDemoReviewCapture+RECT]::new()
[MtDemoReviewCapture]::GetWindowRect($mtReviewProc.MainWindowHandle,[ref]$mtReviewRect)|Out-Null
$mtReviewBitmap=[Drawing.Bitmap]::new($mtReviewRect.Right-$mtReviewRect.Left,$mtReviewRect.Bottom-$mtReviewRect.Top)
$mtReviewGraphics=[Drawing.Graphics]::FromImage($mtReviewBitmap)
$mtReviewHdc=$mtReviewGraphics.GetHdc()
try{$mtReviewSucceeded=[MtDemoReviewCapture]::PrintWindow($mtReviewProc.MainWindowHandle,$mtReviewHdc,2)}finally{$mtReviewGraphics.ReleaseHdc($mtReviewHdc)}
$mtReviewBitmap.Save('C:\Users\96259\AppData\Local\Temp\codex-mt4-demo-review.png',[Drawing.Imaging.ImageFormat]::Png)
$mtReviewGraphics.Dispose()
$mtReviewBitmap.Dispose()
[pscustomobject]@{Captured=$mtReviewSucceeded;Title=$mtReviewProc.MainWindowTitle;At=(Get-Date -Format o)} | ConvertTo-Json
