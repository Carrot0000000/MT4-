$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class MtDemoUi {
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr extra);
}
'@
$mtDemoProcess=Get-Process terminal | Where-Object Path -eq 'C:\Program Files (x86)\FP Markets MT4 Terminal\terminal.exe' | Select-Object -First 1
if(-not $mtDemoProcess){throw 'MT4 not running'}
$mtDemoProcess.Refresh()
if($mtDemoProcess.MainWindowTitle -notmatch '176318407: MetaQuotes-Demo'){throw 'Expected demo account is not active'}
$mtDemoHandle=$mtDemoProcess.MainWindowHandle
function Activate-MtDemo {
 $mtDemoProcess.Refresh()
 if($mtDemoProcess.MainWindowTitle -notmatch '176318407: MetaQuotes-Demo'){throw 'Expected demo account is not active'}
 [MtDemoUi]::ShowWindow($mtDemoHandle,3)|Out-Null
 $mtForegroundPid=[uint32]0
 $mtForegroundThread=[MtDemoUi]::GetWindowThreadProcessId([MtDemoUi]::GetForegroundWindow(),[ref]$mtForegroundPid)
 $mtCurrentThread=[MtDemoUi]::GetCurrentThreadId()
 $mtAttached=$false
 if($mtForegroundThread -ne $mtCurrentThread){$mtAttached=[MtDemoUi]::AttachThreadInput($mtCurrentThread,$mtForegroundThread,$true)}
 try{
  [MtDemoUi]::BringWindowToTop($mtDemoHandle)|Out-Null
  [MtDemoUi]::SetForegroundWindow($mtDemoHandle)|Out-Null
 }finally{if($mtAttached){[MtDemoUi]::AttachThreadInput($mtCurrentThread,$mtForegroundThread,$false)|Out-Null}}
 Start-Sleep -Milliseconds 100
 $mtForegroundPid=[uint32]0
 [MtDemoUi]::GetWindowThreadProcessId([MtDemoUi]::GetForegroundWindow(),[ref]$mtForegroundPid)|Out-Null
 if($mtForegroundPid -ne $mtDemoProcess.Id){throw 'MT4 is not foreground; input aborted'}
}
function Click-MtDemo([int]$x,[int]$y) {
 Activate-MtDemo
 [MtDemoUi]::SetCursorPos($x,$y)|Out-Null
 Start-Sleep -Milliseconds 50
 [MtDemoUi]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
 [MtDemoUi]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 150
}
