#property strict
#property indicator_chart_window
#property indicator_buffers 0
#property version "1.00"
#property description "中文只读信息条：报价点差、K线倒计时、连接和账户状态。"
#property description "不发出交易、警报或网络请求。无报价时停止倒计时。"

input int RightMargin = 12;       // 右侧留白（像素）
input int BottomMargin = 24;      // 底部留白（像素）
input int PanelWidth = 360;       // 信息条宽度（像素）
input int FontSize = 9;           // 字号
input int QuoteTimeoutSeconds = 10; // 无报价多久暂停倒计时（秒）
input color TextColor = C'37,48,62'; // 正文字体颜色
input color BackgroundColor = clrWhite; // 背景色

string PREFIX = "CodexPracticeInfo.";
datetime last_symbol_time = 0;
datetime server_anchor = 0;
uint last_observed_ms = 0;
bool fresh_quote_observed = false;
int panel_height = 108;
int row_height = 22;
int effective_font = 9;
int quote_timeout = 10;

// Initial cached history is deliberately never treated as a fresh tick.
void ObserveQuote()
{
   datetime tick_time = (datetime)SymbolInfoInteger(Symbol(), SYMBOL_TIME);
   if(!IsConnected())
   {
      fresh_quote_observed = false;
      last_symbol_time = tick_time;
      return;
   }
   if(tick_time <= 0 || tick_time == last_symbol_time) return;

   bool advanced = (last_symbol_time > 0 && tick_time > last_symbol_time);
   last_symbol_time = tick_time;
   datetime server_time = TimeCurrent();
   long quote_lag = (long)server_time - (long)tick_time;
   if(!advanced || quote_lag < 0 || quote_lag >= quote_timeout)
   {
      fresh_quote_observed = false;
      return;
   }
   server_anchor = server_time;
   last_observed_ms = GetTickCount();
   fresh_quote_observed = true;
}

bool HasFreshQuote(uint &age_ms)
{
   // Unsigned subtraction also handles GetTickCount's 49.7-day rollover.
   age_ms = GetTickCount() - last_observed_ms;
   if(!IsConnected() || !fresh_quote_observed || age_ms >= (uint)(quote_timeout * 1000))
   {
      fresh_quote_observed = false;
      return false;
   }
   long server_lag = (long)TimeCurrent() - (long)last_symbol_time;
   if(server_lag < 0 || server_lag >= quote_timeout)
   {
      fresh_quote_observed = false;
      return false;
   }
   return true;
}

string TimeframeName()
{
   string value = EnumToString((ENUM_TIMEFRAMES)Period());
   StringReplace(value, "PERIOD_", "");
   return value;
}

string AccountModeText()
{
   if(AccountNumber() == 0) return "未登录";
   ENUM_ACCOUNT_TRADE_MODE mode = (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE);
   if(mode == ACCOUNT_TRADE_MODE_DEMO) return "模拟账户";
   if(mode == ACCOUNT_TRADE_MODE_CONTEST) return "竞赛账户";
   return "真实账户";
}

datetime BarEnd(const datetime opened)
{
   // Calendar month duration cannot be represented by PeriodSeconds alone.
   if(Period() == PERIOD_MN1)
   {
      MqlDateTime parts;
      if(!TimeToStruct(opened, parts)) return 0;
      parts.mon++;
      if(parts.mon > 12) { parts.mon = 1; parts.year++; }
      parts.day = 1;
      parts.hour = 0;
      parts.min = 0;
      parts.sec = 0;
      return StructToTime(parts);
   }
   int duration = PeriodSeconds((ENUM_TIMEFRAMES)Period());
   if(duration <= 0) return 0;
   return opened + duration;
}

string RemainingText(const bool fresh, const uint age_ms)
{
   if(!fresh) return "K线剩余：等待报价/休市";
   datetime opened = iTime(Symbol(), (ENUM_TIMEFRAMES)Period(), 0);
   datetime ends = BarEnd(opened);
   datetime estimated_server = server_anchor + (int)(age_ms / 1000);
   if(opened <= 0 || ends <= opened || estimated_server < opened)
      return "K线剩余：等待图表数据";
   if(estimated_server >= ends) return "K线剩余：等待新K线报价";
   long left = (long)ends - (long)estimated_server;
   int hours = (int)(left / 3600);
   int minutes = (int)((left % 3600) / 60);
   int seconds = (int)(left % 60);
   return "K线剩余：" + StringFormat("%02d:%02d:%02d", hours, minutes, seconds);
}

void SetCommonObjectProperties(const string name)
{
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 0);
   ObjectSetString(0, name, OBJPROP_TOOLTIP, "只读信息；点差不是网络延迟，倒计时不是交易信号。");
}

bool CreateObjects()
{
   string box = PREFIX + "Background";
   if(ObjectFind(0, box) < 0 && !ObjectCreate(0, box, OBJ_RECTANGLE_LABEL, 0, 0, 0)) return false;
   SetCommonObjectProperties(box);
   ObjectSetInteger(0, box, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, box, OBJPROP_BGCOLOR, BackgroundColor);
   ObjectSetInteger(0, box, OBJPROP_COLOR, C'211,220,230');
   ObjectSetInteger(0, box, OBJPROP_WIDTH, 1);
   for(int row = 0; row < 4; row++)
   {
      string label = PREFIX + "Line" + IntegerToString(row);
      if(ObjectFind(0, label) < 0 && !ObjectCreate(0, label, OBJ_LABEL, 0, 0, 0)) return false;
      SetCommonObjectProperties(label);
      ObjectSetInteger(0, label, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, label, OBJPROP_FONTSIZE, effective_font);
      ObjectSetInteger(0, label, OBJPROP_COLOR, TextColor);
      ObjectSetString(0, label, OBJPROP_FONT, "Microsoft YaHei");
   }
   return true;
}

void PlaceObjects()
{
   int chart_width = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS, 0);
   int chart_height = (int)ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS, 0);
   int width = (int)MathMax(300, PanelWidth);
   int x = (int)MathMax(2, chart_width - width - MathMax(0, RightMargin));
   int y = (int)MathMax(2, chart_height - panel_height - MathMax(0, BottomMargin));
   string box = PREFIX + "Background";
   ObjectSetInteger(0, box, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, box, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, box, OBJPROP_XSIZE, width);
   ObjectSetInteger(0, box, OBJPROP_YSIZE, panel_height);
   for(int row = 0; row < 4; row++)
   {
      string label = PREFIX + "Line" + IntegerToString(row);
      ObjectSetInteger(0, label, OBJPROP_XDISTANCE, x + 12);
      ObjectSetInteger(0, label, OBJPROP_YDISTANCE, y + 9 + row * row_height);
   }
}

void Render()
{
   ObserveQuote();
   uint age_ms = 0;
   bool fresh = HasFreshQuote(age_ms);
   string symbol_label = Symbol();
   if(symbol_label == "XAUUSD") symbol_label = "黄金";
   else if(symbol_label == "XAGUSD") symbol_label = "白银";
   string first = symbol_label + "  " + TimeframeName() + "  |  " + AccountModeText();
   double bid = SymbolInfoDouble(Symbol(), SYMBOL_BID);
   double ask = SymbolInfoDouble(Symbol(), SYMBOL_ASK);
   double point = SymbolInfoDouble(Symbol(), SYMBOL_POINT);
   int digits = (int)SymbolInfoInteger(Symbol(), SYMBOL_DIGITS);
   string spread_text = "点差：等待报价";
   if(bid > 0 && ask >= bid && point > 0)
   {
      double spread = ask - bid;
      spread_text = "点差：" + DoubleToString(spread, digits) + " / " + DoubleToString(spread / point, 0) + " points";
      if(!fresh) spread_text += "（最近报价）";
   }
   string status = "连接：未连接";
   if(IsConnected()) status = fresh ? "连接：已连接  |  报价更新中" : "连接：已连接  |  等待该品种新报价";
   ObjectSetString(0, PREFIX + "Line0", OBJPROP_TEXT, first);
   ObjectSetString(0, PREFIX + "Line1", OBJPROP_TEXT, RemainingText(fresh, age_ms));
   ObjectSetString(0, PREFIX + "Line2", OBJPROP_TEXT, spread_text);
   ObjectSetString(0, PREFIX + "Line3", OBJPROP_TEXT, status);
   color account_color = TextColor;
   if(AccountNumber() > 0 && (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE) == ACCOUNT_TRADE_MODE_REAL)
      account_color = clrFireBrick;
   ObjectSetInteger(0, PREFIX + "Line0", OBJPROP_COLOR, account_color);
   PlaceObjects();
   ChartRedraw(0);
}

int OnInit()
{
   IndicatorShortName("PracticeInfo 中文行情信息");
   effective_font = (int)MathMax(8, MathMin(FontSize, 16));
   row_height = (int)MathMax(22, effective_font * 2 + 4);
   panel_height = 20 + row_height * 4;
   quote_timeout = (int)MathMax(3, MathMin(QuoteTimeoutSeconds, 60));
   last_symbol_time = (datetime)SymbolInfoInteger(Symbol(), SYMBOL_TIME);
   fresh_quote_observed = false;
   if(!CreateObjects()) return INIT_FAILED;
   if(!EventSetTimer(1)) return INIT_FAILED;
   Render();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ObjectDelete(0, PREFIX + "Background");
   for(int row = 0; row < 4; row++) ObjectDelete(0, PREFIX + "Line" + IntegerToString(row));
   ChartRedraw(0);
}

void OnTimer() { Render(); }

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id == CHARTEVENT_CHART_CHANGE) { PlaceObjects(); ChartRedraw(0); }
}

int OnCalculate(const int rates_total, const int prev_calculated, const datetime &time[],
                const double &open[], const double &high[], const double &low[], const double &close[],
                const long &tick_volume[], const long &volume[], const int &spread[])
{
   Render();
   return rates_total;
}
