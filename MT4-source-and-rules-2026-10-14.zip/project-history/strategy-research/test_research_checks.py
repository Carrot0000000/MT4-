import struct
import tempfile
import unittest
from pathlib import Path
import research_checks as r


class ResearchSafetyTests(unittest.TestCase):
    def setUp(self):
        self.spec = {"tick_size_price": .01, "tick_value_per_lot": 1,
                     "min_lot": .01, "lot_step": .01, "max_lot": 100}

    def test_minimum_lot_is_not_rounded_up(self):
        self.assertEqual(r.position_size(19.16, self.spec, 2.5, .02)["lots"], 0)

    def test_lot_floor_never_exceeds_budget(self):
        for budget in (0.01, 1, 2.47505, 5, 19.18, 100):
            result = r.position_size(4.99, self.spec, budget, .02, 7)
            self.assertLessEqual(result["reserved_loss_usd"], budget)

    def test_step_grid_is_respected(self):
        self.assertEqual(r.floor_lots(.149, .1, .03, 10), .13)

    def test_stop_rounds_away_from_entry(self):
        self.assertEqual(r.rounded_price(4185.951, .01, False), 4185.95)
        self.assertEqual(r.rounded_price(4185.951, .01, True), 4185.96)

    def test_bid_structure_is_translated_to_ask_sell_stop(self):
        self.assertEqual(r.structural_stop(100, 5, -1, .3, .01), 101.3)
        self.assertEqual(r.structural_stop(100, 5, 1, .3, .01), 99)

    def test_profits_do_not_replenish_daily_budget(self):
        self.assertAlmostEqual(r.remaining_day_budget(500, [-4.99, 20], .01), .01)
        self.assertEqual(r.remaining_day_budget(500, [-4, -2], .01), 0)

    def test_bid_ask_spread_is_not_charged_twice(self):
        self.assertAlmostEqual(r.net_pnl(1, 4205.11, 4200.12, 1), -4.99)
        self.assertAlmostEqual(r.net_pnl(-1, 100, 99.1, 10, .2), 8.8)

    def test_economic_breakeven_covers_fees_and_reserve(self):
        for side in (1, -1):
            level = r.economic_breakeven(side, 100, 10, .5, .02, .01)
            self.assertGreaterEqual(r.net_pnl(side, 100, level-side*.02, 10, .5), .099999)

    def test_partial_bar_and_future_are_unavailable(self):
        bars = [r.Bar(t, 1, 2, .5, 1) for t in (0, 900, 1800)]
        self.assertEqual([b.time for b in r.closed(bars, 15, 1200)], [0])
        self.assertEqual([b.time for b in r.closed(bars, 15, 1800)], [0, 900])

    def test_pivot_requires_two_closed_right_bars(self):
        bars = [r.Bar(i*900, 5, 6, v, 5) for i, v in enumerate((4, 3, 1, 3, 4))]
        self.assertIsNone(r.pivot(bars[:4], 1))
        self.assertEqual(r.pivot(bars, 1), (1800, 1))

    def test_causal_features_are_unchanged_by_future_data(self):
        cfg = __import__("json").loads((r.ROOT/"rules-v0.1.json").read_text(encoding="utf-8"))
        h1, _ = r.read_hst(r.ROOT/"data"/"XAUUSD60.hst", "XAUUSD", 60)
        m15, _ = r.read_hst(r.ROOT/"data"/"XAUUSD15.hst", "XAUUSD", 15)
        decision = int(__import__("datetime").datetime(2026,10,12,3,41,57,tzinfo=r.timezone.utc).timestamp())
        before = r.causal_features(h1, m15, decision, cfg)
        future = r.Bar(decision+86400, 1000, 2000, 1, 1700)
        self.assertEqual(before, r.causal_features(h1+[future], m15+[future], decision, cfg))

    def test_final_disk_record_is_dropped(self):
        raw = bytearray(148)
        struct.pack_into("<i", raw, 0, 401)
        raw[68:74] = b"XAUUSD"
        struct.pack_into("<ii", raw, 80, 15, 2)
        for t in (0, 900):
            raw.extend(struct.pack("<qddddqiq", t, 1, 2, .5, 1.5, 1, 0, 0))
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/"test.hst"
            path.write_bytes(raw)
            bars, meta = r.read_hst(path, "XAUUSD", 15)
            self.assertEqual(len(bars), 1)
            self.assertEqual(meta["records_on_disk"], 2)

    def test_invalid_spec_blocks_sizing(self):
        bad = {**self.spec, "tick_size_price": 0}
        self.assertEqual(r.position_size(5, bad, 10)["lots"], 0)
        self.assertEqual(r.position_size(5, self.spec, float("nan"))["lots"], 0)
        self.assertEqual(r.position_size(5, self.spec, 10, float("inf"))["lots"], 0)
        self.assertEqual(r.floor_lots(float("nan"), .01, .01, 100), 0)


if __name__ == "__main__":
    unittest.main()
