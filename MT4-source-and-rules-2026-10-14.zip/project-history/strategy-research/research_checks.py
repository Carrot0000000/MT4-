"""Read-only MT4 history diagnosis. No terminal API, credentials or order submission.

The times in HST are server wall-clock labels encoded as epoch integers, not
validated UTC timestamps. Every final HST record is dropped as possibly partial.
Outputs are causal rule checks, NOT a profitability backtest.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
import statistics
import struct
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING
from pathlib import Path

ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Bar:
    time: int
    open: float
    high: float
    low: float
    close: float
    tick_volume: int = 0
    spread: int = 0
    real_volume: int = 0


def wall(t: int) -> str:
    # UTC formatter only decodes the numeric label; no historical offset inferred.
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def read_hst(path: Path, symbol: str, minutes: int) -> tuple[list[Bar], dict]:
    raw = path.read_bytes()
    if len(raw) < 208 or (len(raw) - 148) % 60:
        raise ValueError("Invalid HST401 record size")
    if struct.unpack_from("<i", raw)[0] != 401:
        raise ValueError("Only HST401 supported")
    actual_symbol = raw[68:80].split(b"\0")[0].decode("ascii")
    timeframe, digits = struct.unpack_from("<ii", raw, 80)
    if (actual_symbol, timeframe) != (symbol, minutes):
        raise ValueError("Unexpected symbol/timeframe")
    bars = [Bar(*r) for r in struct.iter_unpack("<qddddqiq", raw[148:])]
    for i, b in enumerate(bars):
        if not all(math.isfinite(v) and v > 0 for v in (b.open, b.high, b.low, b.close)):
            raise ValueError("Non-finite/nonpositive price")
        if b.low > min(b.open, b.close) or b.high < max(b.open, b.close) or b.low > b.high:
            raise ValueError("Invalid OHLC bounds")
        if i and bars[i-1].time >= b.time:
            raise ValueError("Nonmonotonic history")
    removed = bars.pop()  # The disk snapshot can contain a stale, incomplete bar.
    gaps = [(a.time, b.time, b.time-a.time) for a, b in zip(bars, bars[1:])
            if b.time-a.time != minutes*60]
    meta = {"file": path.name, "sha256": hashlib.sha256(raw).hexdigest(),
            "symbol": symbol, "timeframe_minutes": minutes, "digits": digits,
            "records_on_disk": len(bars)+1, "records_used": len(bars),
            "first_open_server": wall(bars[0].time), "last_open_server": wall(bars[-1].time),
            "dropped_final_record_open_server": wall(removed.time),
            "nonstandard_interbar_gap_count": len(gaps),
            "gap_interpretation": "includes scheduled closures; no synthetic bars inserted",
            "spread_fields_all_zero": all(b.spread == 0 for b in bars),
            "historical_spread_available": False,
            "time_basis": "server wall labels; historical UTC offset unverified"}
    return bars, meta


def ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    result = [values[0]]
    alpha = 2 / (period + 1)
    for x in values[1:]:
        result.append(alpha*x + (1-alpha)*result[-1])
    return result


def atr(bars: list[Bar], period: int = 14) -> list[float | None]:
    trs = [b.high-b.low if i == 0 else max(b.high-b.low, abs(b.high-bars[i-1].close),
            abs(b.low-bars[i-1].close)) for i, b in enumerate(bars)]
    result: list[float | None] = [None]*len(bars)
    if len(bars) < period:
        return result
    result[period-1] = statistics.mean(trs[:period])
    for i in range(period, len(bars)):
        result[i] = (result[i-1]*(period-1)+trs[i])/period
    return result


def closed(bars: list[Bar], minutes: int, decision: int) -> list[Bar]:
    return [b for b in bars if b.time + minutes*60 <= decision]


def pivot(bars: list[Bar], side: int, lookback: int = 32) -> tuple[int, float] | None:
    # Only a center with two fully closed bars to its right is eligible.
    for i in range(len(bars)-3, max(1, len(bars)-lookback-1), -1):
        values = [b.low if side == 1 else b.high for b in bars[i-2:i+3]]
        candidate = values[2]
        neighbors = values[:2]+values[3:]
        if (side == 1 and all(candidate < x for x in neighbors)) or (
                side == -1 and all(candidate > x for x in neighbors)):
            return bars[i].time, candidate
    return None


def rounded_price(value: float, tick: float, up: bool) -> float:
    if not math.isfinite(value) or not math.isfinite(tick) or tick <= 0:
        raise ValueError("Invalid price/tick")
    mode = ROUND_CEILING if up else ROUND_FLOOR
    return float((Decimal(str(value))/Decimal(str(tick))).to_integral_value(rounding=mode)
                 * Decimal(str(tick)))


def floor_lots(raw_lots: float, min_lot: float, step: float, max_lot: float) -> float:
    if not all(math.isfinite(x) and x > 0 for x in (raw_lots, min_lot, step, max_lot)):
        return 0.0
    value, minimum, increment = map(lambda x: Decimal(str(x)), (min(raw_lots, max_lot), min_lot, step))
    if value < minimum:
        return 0.0
    count = ((value-minimum)/increment).to_integral_value(rounding=ROUND_FLOOR)
    return float(minimum + count*increment)


def structural_stop(pivot_price: float, atr_value: float, side: int, spread: float,
                    tick: float, buffer_fraction: float = .2) -> float:
    # Bid bar pivot for BUY, translated to Ask trigger price for SELL.
    if side not in (-1, 1) or spread < 0 or atr_value <= 0:
        raise ValueError("Invalid structural stop inputs")
    raw = pivot_price-side*buffer_fraction*atr_value + (spread if side == -1 else 0)
    return rounded_price(raw, tick, up=(side == -1))


def remaining_day_budget(day_start: float, realized_net: list[float], fraction: float) -> float:
    return max(0.0, day_start*fraction-sum(-p for p in realized_net if p < 0))


def position_size(distance: float, spec: dict, budget: float, stop_slip: float = 0,
                  commission_per_lot: float = 0) -> dict:
    required = [distance, spec["tick_value_per_lot"], spec["tick_size_price"],
                spec["min_lot"], spec["lot_step"], spec["max_lot"]]
    if (not all(math.isfinite(x) and x > 0 for x in required) or
            not math.isfinite(budget) or budget <= 0 or
            not math.isfinite(stop_slip) or stop_slip < 0 or
            not math.isfinite(commission_per_lot) or commission_per_lot < 0):
        return {"lots": 0.0, "reason": "INVALID_SPEC_OR_NO_BUDGET"}
    per_lot = (distance+stop_slip)/spec["tick_size_price"]*spec["tick_value_per_lot"]+commission_per_lot
    lots = floor_lots(budget/per_lot, spec["min_lot"], spec["lot_step"], spec["max_lot"])
    return {"lots": lots, "raw_lots": budget/per_lot, "risk_at_min_lot": per_lot*spec["min_lot"],
            "reserved_loss_usd": per_lot*lots, "budget_usd": budget,
            "reason": "OK" if lots else "MINIMUM_LOT_EXCEEDS_BUDGET"}


def net_pnl(side: int, entry_fill: float, exit_fill: float, exposure: float, explicit_cost: float = 0) -> float:
    # Both values are executable fill quotes. Spread must not be deducted twice.
    return side*(exit_fill-entry_fill)*exposure-explicit_cost


def economic_breakeven(side: int, fill: float, exposure: float, explicit_cost: float,
                      slip: float, tick: float) -> float:
    if (exposure <= 0 or side not in (-1, 1) or explicit_cost < 0 or slip < 0 or tick <= 0 or
            not all(math.isfinite(v) for v in (fill, exposure, explicit_cost, slip, tick))):
        raise ValueError("Invalid exposure/side")
    target = fill + side*(explicit_cost/exposure+slip+tick)
    return rounded_price(target, tick, up=(side == 1))


def causal_features(h1: list[Bar], m15: list[Bar], decision: int, cfg: dict) -> dict:
    h, m = closed(h1, 60, decision), closed(m15, 15, decision)
    c = cfg["entry"]
    if len(h) < c["minimum_h1_bars"] or len(m) < c["minimum_m15_bars"]:
        return {"signal": 0, "reason": "INSUFFICIENT_WARMUP"}
    hf, hs = ema([b.close for b in h], c["h1_ema_fast"]), ema([b.close for b in h], c["h1_ema_slow"])
    slope = hf[-1]-hf[-1-c["h1_slope_bars"]]
    direction = 1 if h[-1].close > hf[-1] > hs[-1] and slope > 0 else (
                -1 if h[-1].close < hf[-1] < hs[-1] and slope < 0 else 0)
    me = ema([b.close for b in m], c["m15_pullback_ema"])
    a = atr(m, c["atr_period"])[-1]
    pullback = any(m[j].low <= me[j] <= m[j].high for j in range(len(m)-4, len(m)-1))
    long_trigger = m[-1].close > m[-2].high and m[-1].close > m[-1].open and m[-1].close > me[-1]
    short_trigger = m[-1].close < m[-2].low and m[-1].close < m[-1].open and m[-1].close < me[-1]
    lag = decision-(m[-1].time+900)
    contiguous = all(b.time-a0.time == 900 for a0, b in zip(m[-5:-1], m[-4:]))
    h1_fresh = decision-(h[-1].time+3600) < 3600
    ready = 0 <= lag <= c["trigger_valid_seconds_after_close"] and contiguous and h1_fresh
    signal = direction if ready and pullback and ((direction == 1 and long_trigger) or
                                                  (direction == -1 and short_trigger)) else 0
    p = pivot(m, direction or 1, c["pivot_lookback_bars"])
    return {"signal": signal, "direction": direction, "reason": "SIGNAL" if signal else "NO_TRADE",
            "closed_h1_count": len(h), "closed_m15_count": len(m),
            "last_closed_h1_open_server": wall(h[-1].time), "h1_close": h[-1].close,
            "h1_ema50": hf[-1], "h1_ema200": hs[-1], "h1_ema50_slope3": slope,
            "last_closed_m15_open_server": wall(m[-1].time), "m15_close": m[-1].close,
            "m15_ema20": me[-1], "m15_atr14": a, "pullback_detected": pullback,
            "long_trigger": long_trigger, "short_trigger": short_trigger,
            "trigger_lag_seconds": lag, "recent_m15_contiguous": contiguous,
            "h1_fresh": h1_fresh,
            "latest_confirmed_pivot_server": wall(p[0]) if p else None,
            "latest_confirmed_pivot_price": p[1] if p else None}


def write_json(path: Path, content) -> None:
    path.write_text(json.dumps(content, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def run() -> None:
    cfg_raw = (ROOT/"rules-v0.1.json").read_bytes()
    cfg = json.loads(cfg_raw)
    out = ROOT/"outputs"
    out.mkdir(exist_ok=True)
    histories, manifests = {}, []
    for symbol in ("XAUUSD", "XAGUSD"):
        for tf in (15, 60):
            name = f"{symbol}{tf}"
            bars, meta = read_hst(ROOT/"data"/f"{name}.hst", symbol, tf)
            histories[name] = bars
            manifests.append(meta)
            with (out/f"{name}-closed-bars.csv").open("w", newline="", encoding="utf-8-sig") as f:
                writer = csv.DictWriter(f, fieldnames=["server_wall_open"]+list(asdict(bars[0])))
                writer.writeheader()
                for b in bars:
                    writer.writerow({"server_wall_open": wall(b.time), **asdict(b)})
    with (ROOT/"data"/"symbol_specs.csv").open(encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    strings = {"symbol", "server", "account_currency", "snapshot_server_time", "snapshot_gmt_time"}
    specs = {r["symbol"]: {k: v if k in strings else float(v) for k, v in r.items()} for r in rows}
    write_json(out/"data-quality.json", {"histories": manifests, "symbol_specs": specs,
               "rules_sha256": hashlib.sha256(cfg_raw).hexdigest(),
               "no_m1_or_tick_history": True, "no_profitability_backtest": True})
    plan = json.loads((ROOT.parent/"trade-records"/"demo-one-trade-2026-10-12"/"trade-plan.json").read_text(encoding="utf-8-sig"))
    dt = datetime(2026, 10, 12, 3, 41, 57, tzinfo=timezone.utc)
    decision = int(dt.timestamp())
    feature = causal_features(histories["XAUUSD60"], histories["XAUUSD15"], decision, cfg)
    # Force BUY pivot in the known-case audit, independently of the rule direction.
    m = closed(histories["XAUUSD15"], 15, decision)
    p = pivot(m, 1, cfg["entry"]["pivot_lookback_bars"])
    structure_sl = rounded_price(p[1] - cfg["entry"]["structural_stop_atr_buffer"]*feature["m15_atr14"],
                                 specs["XAUUSD"]["tick_size_price"], False)
    capital = min(plan["InitialBalanceUSD"], plan["InitialBalanceUSD"])
    size = position_size(plan["Entry"]-structure_sl, specs["XAUUSD"], capital*.005, .02)
    remaining = remaining_day_budget(plan["InitialBalanceUSD"], [plan["RealizedProfitUSD"]], .01)
    close_time = int(datetime.strptime(plan["CloseTimeServer"], "%Y.%m.%d %H:%M:%S").replace(tzinfo=timezone.utc).timestamp())
    contained = [b for b in histories["XAUUSD15"] if b.time >= decision and b.time+900 <= close_time]
    exposure = plan["Lots"]*specs["XAUUSD"]["tick_value_per_lot"]/specs["XAUUSD"]["tick_size_price"]
    lower_bound_mfe = max((b.high-plan["Entry"])*exposure for b in contained)
    audit = {"case": "completed single demo trade; known before rules were proposed",
             "entry_server_wall": wall(decision), "close_server_wall": wall(close_time),
             "holding_seconds": close_time-decision, "actual_net_pnl_usd": plan["RealizedProfitUSD"],
             "actual_R": plan["RealizedProfitUSD"]/plan["StopLossAmountUSD"],
             "actual_initial_stop_distance": plan["Entry"]-plan["StopLoss"],
             "actual_initial_stop_distance_in_atr": (plan["Entry"]-plan["StopLoss"])/feature["m15_atr14"],
             "causal_entry_features": feature, "counterfactual_structural_buy_stop": structure_sl,
             "counterfactual_structural_buy_risk_check_at_entry": size,
             "current_per_trade_budget_usd": plan["FinalBalanceUSD"]*.005,
             "current_daily_budget_remaining_usd": remaining,
             "current_research_decision": "NO_TRADE",
             "current_reasons": ["one-trade authorization completed", "candidate unvalidated",
                                 "daily remaining loss budget below viable minimum-lot risk"],
             "fully_contained_m15_bars": len(contained),
             "observed_bid_bar_MFE_lower_bound_usd": lower_bound_mfe,
             "observed_monitor_peak_usd": 8.40,
             "true_MFE_known": False,
             "MFE_interpretation": "quoted executable Bid high inside fully contained bars; not a promised attainable market fill",
             "exit_variant_counterfactual_results": "not identified from incomplete entry/exit bars and absent ticks"}
    write_json(out/"known-trade-audit.json", audit)
    # One frozen candidate, three explicitly assumed cost cases. No parameter search.
    records = []
    for symbol in ("XAUUSD", "XAGUSD"):
        m15, h1 = histories[f"{symbol}15"], histories[f"{symbol}60"]
        for i in range(cfg["entry"]["minimum_m15_bars"], len(m15)):
            decision0 = m15[i].time
            feat = causal_features(h1, m15[:i], decision0, cfg)
            side = feat.get("signal", 0)
            if not side or feat["latest_confirmed_pivot_price"] is None:
                continue
            for scenario_no, cost in enumerate(cfg["research_cost_scenarios"][symbol], 1):
                stop = structural_stop(feat["latest_confirmed_pivot_price"], feat["m15_atr14"], side,
                                       cost["spread_price"], specs[symbol]["tick_size_price"],
                                       cfg["entry"]["structural_stop_atr_buffer"])
                fill = m15[i].open + cost["spread_price"] if side == 1 else m15[i].open
                distance = side*(fill-stop)
                # Spread is embedded once: BUY fill Ask; SELL structural stop translated to Ask.
                sizing = position_size(distance, specs[symbol], plan["FinalBalanceUSD"]*.005,
                                       cost["stop_slip_price"], 0)
                spread_pass = distance > 0 and cost["spread_price"] <= .1*distance
                drift = abs(m15[i].open-feat["m15_close"]) <= .1*feat["m15_atr14"]
                records.append({"symbol": symbol, "decision_server_wall": wall(decision0),
                                "side": "BUY" if side == 1 else "SELL", "cost_scenario": scenario_no,
                                "assumed_spread_price": cost["spread_price"], "assumed_stop_slip_price": cost["stop_slip_price"],
                                "hypothetical_fill": fill, "structural_stop": stop, "stop_distance": distance,
                                "atr14": feat["m15_atr14"], "spread_gate": spread_pass,
                                "entry_drift_gate": drift, "lots_at_495_01_and_0_5_percent": sizing["lots"],
                                "minimum_lot_reserved_loss_usd": sizing.get("risk_at_min_lot"),
                                "size_reason": sizing["reason"],
                                "trade_executable": False, "blocking_unmodeled_gates": "news, historical quotes/fees, daily and portfolio state, prospective validation"})
    fields = list(records[0]) if records else ["symbol", "decision_server_wall"]
    with (out/"historical-candidate-risk-checks.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(records)
    summaries = []
    for symbol in ("XAUUSD", "XAGUSD"):
        for sc in (1, 2, 3):
            subset = [r for r in records if r["symbol"] == symbol and r["cost_scenario"] == sc]
            risks = [r["minimum_lot_reserved_loss_usd"] for r in subset if r["minimum_lot_reserved_loss_usd"] is not None]
            summaries.append({"symbol": symbol, "assumed_cost_scenario": sc, "raw_direction_pullback_triggers": len(subset),
                              "pass_spread_and_drift": sum(r["spread_gate"] and r["entry_drift_gate"] for r in subset),
                              "minimum_lot_fits_fixed_2_47505_budget": sum(r["lots_at_495_01_and_0_5_percent"] > 0 for r in subset),
                              "pass_all_three_diagnostic_gates": sum(r["spread_gate"] and r["entry_drift_gate"] and r["lots_at_495_01_and_0_5_percent"] > 0 for r in subset),
                              "median_minimum_lot_loss_usd": statistics.median(risks) if risks else None})
    write_json(out/"candidate-diagnostics.json", {"status": "retrospective risk diagnosis; not a backtest or executed trades",
               "capital_fixed_usd": plan["FinalBalanceUSD"], "per_trade_budget_fixed_usd": plan["FinalBalanceUSD"]*.005,
               "summary": summaries, "parameter_search_performed": False,
               "all_exit_variants_unvalidated": True, "news_calendar_not_reconstructed": True,
               "historical_spreads_and_fees_assumed": True,
               "historical_contract_specs_assumed_equal_to_current_demo_snapshot": True,
               "candidate_profitability": "UNKNOWN", "rules_sha256": hashlib.sha256(cfg_raw).hexdigest()})
    print(json.dumps({"known_case_h1_direction": feature["direction"], "structural_stop": structure_sl,
                      "minimum_lot_reserved_loss": size["risk_at_min_lot"], "today_remaining_budget": remaining,
                      "diagnostics": summaries}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    run()
