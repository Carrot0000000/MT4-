"""Package documentation and a PREPARED-only MT4 demo research preset."""
import csv
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA_ROOT = Path(r"C:\Users\96259\AppData\Roaming\MetaQuotes\Terminal\3398008DB8784ED46E704350351E2CE1")


def package():
    # This operation creates a research artifact; it does NOT import MT4 inputs.
    text = (DATA_ROOT/"MQL4"/"Presets"/"PositionSizer-Beginner-Demo.set").read_text(encoding="utf-8-sig")
    replacement = {"DefaultRisk": "0.5", "DefaultMaxRiskPercentage": "0.5",
                   "DefaultMaxRiskPerSymbol": "0.5", "DefaultMaxRiskTotal": "0.5",
                   "DefaultMaxPositionSizeTotal": "0.01", "DefaultMaxNumberOfTradesTotal": "1",
                   "QuickRisk2": "0.5"}
    lines = []
    found = set()
    for line in text.splitlines():
        key, separator, _ = line.partition("=")
        if key in replacement and separator:
            line = key+"="+replacement[key]
            found.add(key)
        lines.append(line)
    if found != set(replacement):
        raise ValueError("Unexpected base preset fields")
    (ROOT/"PositionSizer-Research-Demo-0.5pct.set").write_text("\n".join(lines)+"\n", encoding="utf-8")
    with (ROOT/"研究记录模板.csv").open("w", encoding="utf-8-sig", newline="") as f:
        fields = ["记录类型", "规则版本", "品种", "方向", "订单号", "服务器开仓时间", "服务器平仓时间",
                  "H1方向证据", "M15触发证据", "结构失效位置", "风险预算USD", "实际手数", "实际成交价",
                  "实际SL", "实际TP", "明确费用USD", "滑点预留", "退出版本", "退出原因", "净盈亏USD",
                  "初始风险R_USD", "净结果R", "报价浮盈下界USD", "是否完整逐笔数据", "规则偏离与备注"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerow({"记录类型": "原单历史复盘_不属于新规则验证", "规则版本": "原固定金额练习",
            "品种": "XAUUSD", "方向": "BUY", "订单号": "1634326487", "服务器开仓时间": "2026-10-12 03:41:57",
            "服务器平仓时间": "2026-10-12 06:05:25", "H1方向证据": "原入场论据不完整；新候选判为过渡",
            "M15触发证据": "原入场论据不完整；新候选无触发", "结构失效位置": "原单未预先建立；反事实新版4185.95",
            "风险预算USD": 5, "实际手数": .01, "实际成交价": 4205.11, "实际SL": 4200.12, "实际TP": 4215.09,
            "明确费用USD": 0, "滑点预留": "原单未完整预定", "退出版本": "原固定SL/TP", "退出原因": "SL",
            "净盈亏USD": -4.99, "初始风险R_USD": 4.99, "净结果R": -1, "报价浮盈下界USD": 9.01,
            "是否完整逐笔数据": "否", "规则偏离与备注": "已结束且无第二笔；此记录不能证明新规则盈利"})
    result = subprocess.run([__import__("sys").executable, "-m", "unittest", "-v", "test_research_checks.py"],
                            cwd=ROOT, capture_output=True, text=True)
    (ROOT/"outputs"/"checks-result.txt").write_text(result.stdout+result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError("Safety checks failed")
    audit = json.loads((ROOT/"outputs"/"known-trade-audit.json").read_text(encoding="utf-8"))
    plt.rcParams["font.family"] = "Microsoft YaHei"
    fig, ax = plt.subplots(figsize=(9, 4.4), layout="constrained")
    values = [2.5, 4.99, audit["counterfactual_structural_buy_risk_check_at_entry"]["risk_at_min_lot"]]
    names = ["新版单笔预算\n入场时500美元×0.5%", "原单计划损失\n最终亏损4.99美元", "结构止损示例的最小手数风险\n含假设滑点预留0.02"]
    bars = ax.barh(names, values, color=["#277da8", "#c46a24", "#a34747"], height=.56)
    ax.invert_yaxis()
    ax.set_xlim(0, 23)
    ax.set_xlabel("美元")
    ax.set_title("先确定止损，再判断最小手数是否超预算", loc="left", pad=18)
    for b, v in zip(bars, values):
        ax.text(v+.25, b.get_y()+b.get_height()/2, f"${v:.2f}", va="center", weight="bold")
    ax.grid(axis="x", alpha=.18)
    ax.set_axisbelow(True)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    fig.text(.03, -.045, "原单已知后的候选规则演示；结构位置和缓冲不是唯一正确答案；本图不表示盈利回测。", fontsize=9)
    fig.savefig(ROOT/"outputs"/"风险预算对比.png", dpi=180, bbox_inches="tight")
    plt.close(fig)
    files = ["rules-v0.1.json", "research_checks.py", "test_research_checks.py",
             "PositionSizer-Research-Demo-0.5pct.set", "交易复盘与规则优化-详细版.txt", "四步检查.txt"]
    manifest = {"frozen_at_utc": datetime.now(timezone.utc).isoformat(),
                "role": "known-case development version; future data required",
                "profitability_validated": False, "active_mt4_configuration_changed": False,
                "new_orders_placed": 0, "checks_passed": 13,
                "risk_preset_status": "prepared file only; not imported, runtime values unverified",
                "files": {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files}}
    (ROOT/"version-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"packaged": True, "checks_passed": 13, "new_orders_placed": 0, "preset_imported": False}, ensure_ascii=False))


if __name__ == "__main__":
    package()
