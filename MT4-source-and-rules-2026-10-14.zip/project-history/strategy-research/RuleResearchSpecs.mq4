#property strict
#property version "1.00"
// Read-only broker specification export. No order operations.
void OnStart()
{
   if(AccountNumber()!=176318407 || AccountInfoInteger(ACCOUNT_TRADE_MODE)!=ACCOUNT_TRADE_MODE_DEMO ||
      !TerminalInfoInteger(TERMINAL_CONNECTED))
   { Print("RuleResearchSpecs: expected connected demo account is not active."); return; }
   FolderCreate("RuleResearch");
   int f=FileOpen("RuleResearch\\symbol_specs.csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   if(f==INVALID_HANDLE){ Print("RuleResearchSpecs: file error ",GetLastError());return; }
   FileWrite(f,"symbol","server","account_currency","balance","equity","leverage","point","digits","contract_size","tick_value_per_lot","tick_size_price","marketinfo_ticksize_raw","min_lot","lot_step","max_lot","stop_level_points","freeze_level_points","margin_required_per_lot","trade_allowed","bid","ask","snapshot_server_time","snapshot_gmt_time");
   string symbols[2]={"XAUUSD","XAGUSD"};
   for(int i=0;i<2;i++)
   {
      string s=symbols[i];
      SymbolSelect(s,true);
      FileWrite(f,s,AccountServer(),AccountCurrency(),
         DoubleToString(AccountBalance(),2),DoubleToString(AccountEquity(),2),AccountLeverage(),
         DoubleToString(MarketInfo(s,MODE_POINT),8),(int)MarketInfo(s,MODE_DIGITS),
         DoubleToString(MarketInfo(s,MODE_LOTSIZE),8),
         DoubleToString(MarketInfo(s,MODE_TICKVALUE),8),
         DoubleToString(SymbolInfoDouble(s,SYMBOL_TRADE_TICK_SIZE),8),
         DoubleToString(MarketInfo(s,MODE_TICKSIZE),8),
         DoubleToString(MarketInfo(s,MODE_MINLOT),8),
         DoubleToString(MarketInfo(s,MODE_LOTSTEP),8),
         DoubleToString(MarketInfo(s,MODE_MAXLOT),8),
         (int)MarketInfo(s,MODE_STOPLEVEL),(int)MarketInfo(s,MODE_FREEZELEVEL),
         DoubleToString(MarketInfo(s,MODE_MARGINREQUIRED),8),
         (int)MarketInfo(s,MODE_TRADEALLOWED),
         DoubleToString(MarketInfo(s,MODE_BID),8),
         DoubleToString(MarketInfo(s,MODE_ASK),8),
         TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),
         TimeToString(TimeGMT(),TIME_DATE|TIME_SECONDS));
   }
   FileClose(f);
   Print("RuleResearchSpecs: read-only export completed.");
}
