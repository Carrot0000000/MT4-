"""Exercise the rejected fill scenario through the production entry function with fake APIs."""
from build_upgrade_v0_12 import ROOT,LIVE,STAGE,BACKUP,body
src=(STAGE/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(BACKUP/'Scripts/Codex/UpgradeReviewV011.mq4').read_text(encoding='utf-8-sig')
test=test.replace('version "2.100"','version "2.200"').replace('v011-','v012-')
test=test.replace('#include <Codex/ExecutionTiming.mqh>', '#include <Codex/ExecutionTiming.mqh>\n#include <Codex/EntrySlippage.mqh>')
test=test.replace('Near(admission_floors[1],13.12)', 'Near(admission_floors[1],14.12)')
for n in ['Cycle','CheckOutcome','RefreshAdmission']:
    test=test.replace(body(test,n),body(src,n))
test=test.replace(body(test,'TestProductionTryEntry'),body(src,'TryEntry').replace('void TryEntry(','void TestProductionTryEntry(',1))
test=test.replace('void AlignedCycle(){}','void AlignedCycle(){}\nvoid AlignedCycle12(){}')
test=test.replace('int Direction(const string symbol){return 1;}','int mock_direction=1;double mock_structure=99;\nint Direction(const string symbol){return mock_direction;}')
test=test.replace('double RecentStructure(const string symbol,const int side){return 99;}', 'double RecentStructure(const string symbol,const int side){return mock_structure;}')
test=test.replace('mock_balance=10000;mock_aligned_signal=false;', 'mock_direction=1;mock_structure=99;mock_balance=10000;mock_aligned_signal=false;',1)
test=test.replace('return mock_aligned_signal&&frame==PERIOD_M5&&shift==2?99.9:100;', 'return mock_aligned_signal&&frame==PERIOD_M5&&shift==2?(mock_direction==1?99.9:100.1):100;')
test=test.replace('return mock_aligned_signal?99.8:100;', 'return mock_aligned_signal?(mock_direction==1?99.8:100.2):100;')
test=test.replace('frame==PERIOD_M5?99.95:', 'frame==PERIOD_M5?(mock_direction==1?99.95:100.05):')
new=r'''
void RunEntryReserveTests()
{
   ECheck(Near(APEntryReserve(20,.01),.20)&&Near(APEntryReserve(20,.001),.020),"opening reserve converts broker points to price for each metal");
   ECheck(APEntryReserve(-1,.01)<0&&APEntryReserve(20,0)<0&&Near(APEntryReserve(0,.01),0),"invalid points blocked and explicit zero reserve preserved");
   double exit=.05,fee=.07,distance=4.83,entry=APEntryReserve(20,.01);
   ECheck(Near(distance+exit+fee,4.95)&&Near(distance+.15+exit+fee,5.10),"audited v011 incident reproduced numerically");
   ECheck(APLots(5,distance,exit+entry,.01,1,.01,.01,.01,7)==0,"audited incident rejected before OrderSend with opening reserve");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_bid=side==1?99.98:100;mock_ask=mock_bid+.02;mock_direction=side;mock_structure=side==1?95.37:104.61;
      attempted[0]=0;TestProductionTryEntry(0);
      ECheck(mock_sends==0&&last_codes[0]==AP_BUDGET&&Near(last_minimum_risks[0],5.15),"production buy and sell reject near-cap plan before sending");
      ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_bid=side==1?99.98:100;mock_ask=mock_bid+.02;mock_direction=side;mock_structure=side==1?95.57:104.41;
      attempted[0]=0;TestProductionTryEntry(0);
      ECheck(mock_sends==1&&Near(last_minimum_risks[0],4.95),"production buy and sell with sufficient headroom remain eligible");
   }
   int checked=0,bad=0;
   for(int metal=0;metal<2;metal++)for(int d=1;d<=100;d++)
   {
      double point=metal==0?.01:.001,value=metal==0?1:5,slip=metal==0?.05:.02;
      double dist=d*(metal==0?.05:.001),reserve=APEntryReserve(20,point);
      double lots=APLots(5,dist,slip+reserve,point,value,.01,.01,.01,7);
      if(lots<=0)continue;
      for(int j=0;j<=20;j++)
      {
         double filled_risk=(dist+j*point+slip)/point*value*lots+7*lots;
         if(filled_risk>5+1e-7)bad++;checked++;
      }
   }
   ECheck(checked>1000&&bad==0,"all admitted metal plans remain under cap through their full reserved opening deviation");
   // Preserve the old paired campaign; start a new six-book campaign for changed admission.
   ResetScenario();RoundTripFeePerLotUSD=7;
   bf_root="DemoAutopilot\\test-v012-newaligned-"+IntegerToString(GetTickCount())+"-";
   ECheck(BF_PROTOCOL!=AF_PROTOCOL&&BFInitialize()&&!bf_fault,"new admission protocol is isolated from prior research");
   mock_now=2420;mock_aligned_signal=true;mock_bid=100;mock_ask=100.02;
   for(int i=0;i<6;i++)
   {
      Spec s;BFReadSpec(0,i,s);FLBook p=bf_books[i];
      ECheck(BFPlan(i,0,s,p)&&p.r<=5,"all six new admission books preserve capped post-fill risk");
   }
   int f=FileOpen("DemoAutopilot\\v012-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"entry_slip_property_scenarios\":"+IntegerToString(checked)+",\"actual_order_operations\":0}");FileClose(f);}
}
'''
test=test.replace('#undef OrderClosePrice','#define AlignedCycle12 TestAlignedCycle12\n#include <Codex/AlignedForward12.mqh>\n#undef AlignedCycle12\n'+new+'\n#undef OrderClosePrice',1)
test=test.replace('RunQualityTests();Print(', 'RunQualityTests();RunEntryReserveTests();Print(')
(LIVE/'Scripts/Codex/UpgradeReviewV012.mq4').write_text(test,encoding='utf-8-sig')
print('Generated native v0.12 incident regression and bounded entry-deviation checks.')
