"""Native tests: pure protection math, production state machine and paired replay persistence."""
from pathlib import Path
from build_upgrade_v0_9 import body

ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal'/'MQL4'
source=(ROOT/'staging-v0.9/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(ROOT/'backup-fp-v0.8/Scripts/Codex/UpgradeReviewV08.mq4').read_text(encoding='utf-8-sig')
test=test.replace('#include <Codex/BudgetAdmission.mqh>','#include <Codex/BudgetAdmission.mqh>\n#include <Codex/ForwardCore.mqh>\n#include <Codex/ProfitProtection.mqh>\n#include <Codex/SnapshotWriter.mqh>')
test=test.replace('version "1.800"','version "1.900"')
for name in ['Manage','Cycle','CheckOutcome']:
    test=test.replace(body(test,name),body(source,name))
test=test.replace(body(test,'TestProductionTryEntry'),body(source,'TryEntry').replace('void TryEntry(','void TestProductionTryEntry(',1))
test=test.replace('int EntryWindowSeconds=120,','bool EnableForwardResearch=true;\nint EntryWindowSeconds=120,')
test=test.replace('void LabCycle(){}','void LabCycle(){}\n'+body(source,'Escape'))
test=test.replace('Near(mock_last_tighten,100.13)','Near(mock_last_tighten,101.66)')
test=test.replace('production break-even reserves full round-trip fees','production profit lock reserves full round-trip fees')
test=test.replace('v08-','v09-')
test=test.replace('void OnStart(){RunCoreTests();RunExecutionTests();RunUpgradeTests();Print("V08 native checks finished: ",passed+exec_passed," passed / ",failed+exec_failed," failed; zero real Order APIs invoked.");}', '')
new=r'''
void ResetExitFixture(const bool new_path=true)
{
   ep_seq=0;ep_pairs=0;ep_baseline=0;ep_trial=0;ep_fault=false;ep_error="";ep_initialized=false;
   ep_last_cycle=0;ep_checkpoint=0;ep_status_time=0;
   for(int j=0;j<EP_SLOTS;j++)
   {ep_tickets[j]=0;ep_completed[j]=false;for(int m=0;m<2;m++){FLInit(ep_books[2*j+m],500);ep_nets[2*j+m]=0;}}
   if(new_path){ep_root="DemoAutopilot\\test-v09-"+IntegerToString(GetTickCount())+"-";ep_campaign=0;ep_signature="";}
}
void RunProtectionTests()
{
   ECheck(APProtectedNet(5.99,10)<0&&Near(APProtectedNet(6,10),0),"earlier BE trigger boundary is 0.6R");
   ECheck(Near(APProtectedNet(10,10),2.5),"at 1R the intended protected net is 0.25R");
   ECheck(Near(APProtectedNet(15,10),10),"at 1.5R the intended protected net is 1R");
   ECheck(!APProtectedGiveback(9,0,10),"sub-1R noise cannot trigger giveback market exit");
   ECheck(APProtectedGiveback(10,2.5,10)&&!APProtectedGiveback(10,2.51,10),"giveback boundary after 1R");
   ECheck(APProtectedGiveback(15,10,10)&&!APProtectedGiveback(15,10.01,10),"late giveback boundary retained");
   ECheck(APProtectedNet(10,0)<0&&APProtectedStop(100,0,0,.05,.01,2,1,10,10)==0,"invalid risk or units blocked");
   for(int side=-1;side<=1;side+=2)
   {
      double stop=APProtectedStop(100,1,.07,.05,.01,2,side,6,6);
      ECheck(APNet(side,100,stop-side*.05,1,.07)>=1.5-1e-7,"both sides protect requested net after modeled fee and slip");
      FLBook p;FLInit(p,500);p.active=true;p.side=side;p.fill=100;p.sl=100-side*5;p.tp=100+side*10;
      p.units=1;p.fee=.07;p.slip=.05;p.peak=6;p.r=6;
      double bid=side==1?106:93.98,ask=bid+.02;
      double old=p.sl;
      ECheck(APProtectedTighten(p,bid,ask,.01,2,.01)&&side*(p.sl-old)>0,"both sides tighten instead of widening");
      double same=p.sl;ECheck(!APProtectedTighten(p,bid,ask,.01,2,.01)&&Near(p.sl,same),"unchanged target does not resend modify");
      p.sl=100-side*5;ECheck(!APProtectedTighten(p,bid,ask,.01,2,10),"broker freeze or distance prevents impossible tightening");
   }
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;mock_bid=103.65;mock_ask=103.67;Manage();
   ECheck(mock_tightens==0&&mock_closes==0,"production Manage does not tighten below 0.6R");
   mock_bid=103.70;mock_ask=103.72;Manage();
   ECheck(mock_tightens==1&&Near(mock_last_tighten,100.13),"production Manage shifts BE above costs at 0.6R");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;
   GlobalVariableSet(K("peak",123),6);mock_bid=101.50;mock_ask=101.52;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,"earlier giveback uses existing sticky close machinery");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;
   GlobalVariableSet(K("peak",123),6);mock_bid=101.50;mock_ask=101.52;mock_error=138;Manage();
   mock_bid=107;mock_ask=107.02;mock_error=0;mock_now++;Manage();
   ECheck(mock_closes==2&&!mock_live,"rebound does not cancel earlier-protection exit intent");

   int cases=0,bad=0;
   for(int side=-1;side<=1;side+=2)for(int u=1;u<=5;u++)for(int k=0;k<=200;k++)
   {
      double r=5,peak=k*.01*r,keep=APProtectedNet(peak,r),units=u*.5;
      if(keep>=0)
      {
         double stop=APProtectedStop(100,units,.07,.05,.01,2,side,peak,r);
         if(stop<=0||APNet(side,100,stop-side*.05,units,.07)<keep-1e-7)bad++;
         if(keep>peak+1e-7)bad++;
      }
      cases++;
   }
   ECheck(cases==2010&&bad==0,"2010 price-step cases preserve costs and retained-net bound");

   // Replay future accepted-entry clone, then restore its append-only record.
   ResetScenario();MaximumHoldMinutes=20;RoundTripFeePerLotUSD=7;mock_open=2100;mock_now=2200;
   ResetExitFixture();Spec s;ReadSpec(0,s);EPStart(123,0,s);
   ECheck(ep_initialized&&!ep_fault&&ep_tickets[0]==123&&ep_books[0].active&&ep_books[1].active,"identical two-arm enrollment succeeds");
   EPStart(123,0,s);ECheck(ep_tickets[1]==0,"duplicate enrollment does not create another pair");
   mock_bid=104;mock_ask=104.02;ReadSpec(0,s);EPManage(0,0,s);EPManage(0,1,s);
   ECheck(Near(ep_books[0].sl,95)&&Near(ep_books[1].sl,100.13),"trial protects earlier on the same price path");
   mock_now=2250;mock_bid=100.12;mock_ask=100.14;ReadSpec(0,s);EPManage(0,0,s);EPManage(0,1,s);
   ECheck(ep_books[0].active&&!ep_books[1].active&&Near(ep_nets[1],0),"trial sampled stop includes adverse modeled fill and fees");
   mock_now=3300;mock_bid=98;mock_ask=98.02;ReadSpec(0,s);EPManage(0,0,s);EPComplete(0);
   ECheck(ep_pairs==1&&Near(ep_baseline,-2.12)&&Near(ep_trial,0),"paired result completes after baseline time exit");
   EPComplete(0);ECheck(ep_pairs==1,"same pair is not counted twice");
   long saved_seq=ep_seq;ResetExitFixture(false);
   ECheck(EPInitialize()&&!ep_fault&&ep_seq==saved_seq&&ep_pairs==1&&Near(ep_baseline,-2.12)&&Near(ep_trial,0),"native ledger restores complete paired results without double count");
   EPStart(123,0,s);ECheck(ep_pairs==1&&ep_tickets[1]==0,"restart retains enrollment idempotence");
   mock_identity=false;EPStart(124,0,s);ECheck(ep_tickets[0]==123,"wrong account cannot enroll virtual pair");
   mock_identity=true;
   FLBook gap;FLInit(gap,500);gap.side=1;gap.fill=100;gap.sl=100.13;gap.tp=110;gap.units=1;gap.fee=.07;gap.slip=.05;
   ECheck(Near(FLExitPrice(gap,98,98.02,FL_STOP),97.95),"gapped stop never invents a fill at protected level");
   int f=FileOpen("DemoAutopilot\\v09-protection-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"version\":\"0.9\",\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
         ",\"failures\":["+failure_labels+"],\"protection_property_scenarios\":"+IntegerToString(cases)+",\"actual_order_operations\":0}");FileClose(f);
   }
}
'''
test=test.replace('#undef AccountLeverage','#include <Codex/ExitComparison.mqh>\n'+new+'\n#undef AccountLeverage',1)
# Include runs under the fake APIs; all ledger files use a unique test prefix.
test+='\nvoid OnStart(){ep_root="DemoAutopilot\\\\test-v09-main-"+IntegerToString(GetTickCount())+"-";RunCoreTests();RunExecutionTests();RunUpgradeTests();RunProtectionTests();Print("V09 checks: ",passed+exec_passed," passed / ",failed+exec_failed," failed; zero real order operations.");}\n'
(LIVE/'Scripts/Codex/UpgradeReviewV09.mq4').write_text(test,encoding='utf-8-sig')
print('Generated v0.9 native production-function and persistence tests; broker mutations mocked.')
