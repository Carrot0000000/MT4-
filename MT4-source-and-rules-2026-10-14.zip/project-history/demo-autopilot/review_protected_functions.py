"""Verify the upgrade did not change account guards, order management or risk math."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FUNCTIONS = {
    "DemoPracticeAutopilot.mq4": [
        "Identity", "OwnerMarker", "Owner", "MutationAllowed", "ReadSpec",
        "IsOwnedSelected", "OwnedCount", "SyncClosed", "SafeClose", "SafeTighten",
        "Manage", "Direction", "Pivot", "OnDeinit", "OnChartEvent",
    ],
    "AutopilotCore.mqh": [
        "APIdentity", "APFinitePositive", "APPrice", "APLots", "APStop",
        "APBreakEven", "APNet", "APGiveback",
    ],
}


def function_body(source, name):
    match = re.search(r"(?m)^(?:bool|int|double|string|void) " + re.escape(name) + r"\(", source)
    if not match:
        raise ValueError("Function missing: " + name)
    opening = source.index("{", match.end())
    depth = 0
    for i in range(opening, len(source)):
        depth += (source[i] == "{") - (source[i] == "}")
        if depth == 0:
            return source[match.start():i+1].replace("\r\n", "\n")
    raise ValueError("Unterminated function: " + name)


checks = []
for filename, names in FUNCTIONS.items():
    before = (ROOT / "backup-v0.2" / filename).read_text(encoding="utf-8-sig")
    after = (ROOT / filename).read_text(encoding="utf-8-sig")
    for name in names:
        old_body, new_body = function_body(before, name), function_body(after, name)
        checks.append({"file": filename, "function": name, "unchanged": old_body == new_body,
                       "body_sha256": hashlib.sha256(new_body.encode("utf-8")).hexdigest()})
result = {"protected_functions": checks, "all_unchanged": all(c["unchanged"] for c in checks)}
(ROOT / "guard-review-v0.3.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"protected_functions_checked": len(checks), "all_unchanged": result["all_unchanged"]}))
if not result["all_unchanged"]:
    raise SystemExit("Protected functions changed; inspect before completing upgrade")
