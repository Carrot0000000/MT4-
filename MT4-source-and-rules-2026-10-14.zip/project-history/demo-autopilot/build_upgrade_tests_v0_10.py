"""Native regression using production functions, with every trading API mocked."""
from build_upgrade_v0_10 import ROOT, LIVE, STAGE, BACKUP, body

source=(STAGE/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
old=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(BACKUP/'Scripts/Codex/UpgradeReviewV09.mq4').read_text(encoding='utf-8-sig')
test=test.replace('version "1.900"','version "2.000"').replace('v09-','v010-')
test=test.replace('#include <Codex/SnapshotWriter.mqh>','#include <Codex/SnapshotWriter.mqh>\n#include <Codex/ExecutionTiming.mqh>')
for name in ['SafeClose','Manage','Cycle','CheckOutcome']:
    test=test.replace(body(test,name),body(source,name))
test=test.replace(body(test,'SafeTighten'),'')
test=test.replace('int FakeOrderType(){return OP_BUY;}','int mock_side=OP_BUY;\nint FakeOrderType(){return mock_side;}')
fake_modify=r'''
bool FakeOrderModify(const int ticket,const double open,const double sl,const double tp,const datetime expiry,const color arrow)
{
   mock_tightens++;mock_last_tighten=sl;mock_last_error=mock_error;
   if(mock_error!=0)return false;
   mock_sl=sl;mock_tp=tp;return true;
}
'''
test=test.replace('bool ReadSpec(',fake_modify+'\nbool ReadSpec(',1)
test=test.replace('#define OrderSend FakeOrderSend','#define OrderSend FakeOrderSend\n#define OrderModify FakeOrderModify\n'+
                  body(source,'ActionReadyAt')+'\n'+body(source,'ExitReasonText')+'\n'+body(source,'SafeTighten'))
test=test.replace('   vars=0;RoundTripFeePerLotUSD=0;', '   mock_side=OP_BUY;vars=0;RoundTripFeePerLotUSD=0;',1)
legacy=body(old,'SafeClose').replace('bool SafeClose(', 'bool LegacySafeClose(',1)+'\n'+body(old,'SafeTighten').replace('bool SafeTighten(', 'bool LegacySafeTighten(',1)
new=r'''
void RunTimingTests()
{
   // Reproduce the old bug with both ORIGINAL production functions under fake APIs.
   ResetScenario();mock_error=130;LegacySafeTighten(123,100.13);mock_error=0;
   bool old_closed=LegacySafeClose(123,AP_EXIT_USER);
   ECheck(!old_closed&&mock_closes==0&&mock_live&&GlobalVariableGet(K("action_after",123))==2205,
      "v09 reproduction: invalid modify blocks immediate user close for five seconds");
   for(int side=0;side<2;side++)for(int e=0;e<2;e++)
   {
      ResetScenario();mock_side=side==0?OP_BUY:OP_SELL;
      if(side==1){mock_bid=97.98;mock_ask=98;mock_sl=105;mock_tp=90;}
      double target=side==0?100.13:99.87;
      mock_error=e==0?130:145;
      ECheck(!SafeTighten(123,target)&&mock_tightens==1,"modify-specific rejection is observed");
      SafeTighten(123,target);ECheck(mock_tightens==1,"modify retry remains throttled after rejection");
      mock_error=0;
      ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==1&&!mock_live,"buy and sell user close bypasses modify-only rejection backoff");
   }
   ResetScenario();mock_error=130;SafeTighten(123,100.13);mock_error=0;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_TIME,
      "production time exit is no longer delayed by invalid modify");
   ResetScenario();MaximumHoldMinutes=0;mock_error=145;SafeTighten(123,100.13);mock_error=0;
   GlobalVariableSet(K("peak",123),6);mock_bid=101;mock_ask=101.02;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,
      "production profit giveback is no longer delayed by denied modify");
   int shared_errors[8]={4,6,8,128,137,139,141,146};
   for(int i=0;i<8;i++)
   {
      ResetScenario();mock_error=shared_errors[i];SafeTighten(123,100.13);
      mock_error=0;int wait=APRetrySeconds(shared_errors[i]);
      ECheck(!SafeClose(123,AP_EXIT_USER)&&mock_closes==0&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_USER,
         "transport or rate-limit failure retains shared backoff and persistent close intent");
      mock_now+=wait-1;SafeClose(123,AP_EXIT_USER);ECheck(mock_closes==0,"shared deadline is not bypassed one second early");
      mock_now++;ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==1,"close may retry at shared deadline");
   }
   ResetScenario();mock_error=130;SafeTighten(123,100.13);mock_error=138;SafeClose(123,AP_EXIT_USER);
   ECheck(mock_closes==1&&mock_live,"requote after modify rejection records separate close failure");
   mock_error=0;SafeClose(123,AP_EXIT_USER);ECheck(mock_closes==1,"independent close retry never spins within the same second");
   mock_now++;ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==2,"close retry succeeds without waiting for modify deadline");
   ResetScenario();GlobalVariableSet(K("action_after",123),mock_now+10);
   ECheck(!SafeClose(123,AP_EXIT_TIME)&&mock_closes==0,"old persisted in-flight retry deadline is preserved on upgrade");
   mock_now+=10;ECheck(SafeClose(123,AP_EXIT_TIME),"legacy deadline expires normally");
   ResetScenario();GlobalVariableSet(K("exit_intent",123),AP_EXIT_TIME);
   ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"no modify may follow a latched close intent");
   ResetScenario();mock_identity=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"wrong account cannot modify");
   ResetScenario();mock_owner=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"wrong owner cannot modify");
   ResetScenario();mock_fresh=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"stale quote cannot modify");
   ResetScenario();mock_mutation=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"closed permissions cannot modify");
   ResetScenario();ECheck(!SafeTighten(123,94)&&mock_tightens==0,"production buy stop cannot widen");
   ECheck(!SafeTighten(123,102)&&mock_tightens==0,"production stop cannot violate market distance");
   ResetScenario();mock_side=OP_SELL;mock_bid=97.98;mock_ask=98;mock_sl=105;mock_tp=90;
   ECheck(!SafeTighten(123,106)&&mock_tightens==0,"production sell stop cannot widen");
   ECheck(APHoldSecondsLeft(1000,2199,20)==1&&APHoldSecondsLeft(1000,2200,20)==0&&
      APHoldSecondsLeft(1000,2300,20)==0&&APHoldSecondsLeft(1000,2200,0)==-1,"display distinguishes remaining time, overdue and disabled limit");
   ECheck(ExitReasonText(AP_EXIT_GIVEBACK)=="PROFIT_PROTECTION_GIVEBACK","exit log no longer mislabels v09 giveback as 1.5R only");
   int f=FileOpen("DemoAutopilot\\v010-timing-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
         ",\"failures\":["+failure_labels+"],\"old_bug_reproduced\":true,\"actual_order_operations\":0}");FileClose(f);
   }
}
'''
test=test.replace('#undef AccountLeverage',legacy+'\n'+new+'\n#undef OrderModify\n#undef AccountLeverage',1)
test=test.replace('RunProtectionTests();Print(', 'RunProtectionTests();RunTimingTests();Print(')
(LIVE/'Scripts/Codex/UpgradeReviewV010.mq4').write_text(test,encoding='utf-8-sig')
print('Generated v0.10 native tests; original bug reproduction plus production order API mocks.')
