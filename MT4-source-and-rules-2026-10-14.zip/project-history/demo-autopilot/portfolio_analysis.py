"""Independent audit of admission risk and matched virtual portfolio accounting."""
import argparse,csv,json,math
from pathlib import Path

def analyze(directory:Path):
    with (directory/'dual-v07-campaign.csv').open(encoding='utf-8-sig',newline='') as f:meta=next(csv.reader(f))
    if len(meta)!=4 or meta[0]!='DUAL07.R1':raise ValueError('portfolio identity mismatch')
    parameters=dict(piece.split('=',1) for piece in meta[1].split('|') if '=' in piece)
    risk_percent=float(parameters['risk'])
    if not 0<risk_percent<=1:raise ValueError('unsupported risk setting')
    campaign=meta[2]
    with (directory/f'dual-v07-{campaign}-ledger.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    states={};seq={i:0 for i in range(3)};admissions=[]
    for r in rows:
        if None in r or any(v is None for v in r.values()):raise ValueError('incomplete ledger row')
        i=int(r['model']);s=int(r['seq'])
        if r['campaign']!=campaign or r['parameter_signature']!=meta[1] or s!=seq[i]+1:raise ValueError('mixed series or sequence gap')
        if r['action']=='OPEN':
            ctx=dict(piece.split('=',1) for piece in r['exit_reason'].split('|'))
            cash=float(ctx['cash']);equity=float(ctx['equity']);used=float(ctx['reserved_before']);remaining=float(ctx['remaining']);risk=float(r['reserved_r'])
            previous=sum(float(states[j]['reserved_r']) for j in (0,1) if j in states and states[j]['active']=='1') if i<2 else 0
            expected=max(0,min(cash,equity)*risk_percent/100-used)
            if abs(previous-used)>1e-7 or abs(expected-remaining)>1e-7 or risk>remaining+1e-7:raise ValueError('portfolio risk admission inconsistent')
            active=sum(states[j]['active']=='1' for j in (0,1) if j in states) if i<2 else int(i in states and states[i]['active']=='1')
            if active>=(2 if i<2 else 1):raise ValueError('position limit exceeded')
            admissions.append({'slot':i,'risk_before':used,'risk_new':risk,'risk_after':used+risk,'budget':min(cash,equity)*risk_percent/100})
        states[i]=r;seq[i]=s
    if set(states)!={0,1,2}:raise ValueError('missing matched portfolio states')
    start=float(states[0]['starting_cash'])
    if any(abs(float(r['starting_cash'])-start)>1e-7 for r in states.values()):raise ValueError('different initial funding')
    dual_cash=start+sum(float(states[i]['cash'])-start for i in (0,1))
    single_cash=float(states[2]['cash']);dual_n=sum(int(states[i]['closed_count']) for i in (0,1));single_n=int(states[2]['closed_count'])
    return {'protocol':meta[0],'campaign':campaign,'actual_order_operations':0,'automatic_promotion':False,
        'risk_admissions_checked':len(admissions),'admissions':admissions,'dual_initial_cash':start,'single_initial_cash':start,
        'dual_cash':dual_cash,'single_cash':single_cash,'dual_net':dual_cash-start,'single_net':single_cash-start,
        'dual_closed':dual_n,'single_closed':single_n,'maximum_dual_positions':2,'total_risk_percent':risk_percent,
        'dual_stress_net':sum(float(states[i]['stress_sum']) for i in (0,1)),'single_stress_net':float(states[2]['stress_sum']),
        'sufficient_to_choose_winner':False,
        'comparison_note':'same risk ceiling does not imply equal actual risk utilization; compare exposure, costs and drawdown before changing the broker controller'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=analyze(a.directory);a.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'admissions_checked':result['risk_admissions_checked'],'dual_closed':result['dual_closed'],'single_closed':result['single_closed']}))
