"""Generate a separate preregistered six-book forward campaign from the retained engine."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal/MQL4'

def main():
    source=(LIVE/'Include/Codex/ForwardLab.mqh').read_text(encoding='utf-8-sig')
    names=re.findall(r'(?m)^(?:string|bool|void) (\w+)\(',source)
    mapping={name:('AFNum' if name=='FF' else 'AlignedCycle' if name=='LabCycle' else 'AF'+name[2:]) for name in names}
    for old,new in mapping.items():source=re.sub(r'\b'+old+r'\b',new,source)
    source=re.sub(r'\bfl_', 'af_',source)
    source=source.replace('CODEX_FORWARD_LAB','CODEX_ALIGNED_FORWARD_V011').replace('FL_PROTOCOL','AF_PROTOCOL').replace('FL_COLUMNS','AF_COLUMNS')
    source=source.replace('FWD06.R1','ALIGN11.R1').replace('lab-v06-','aligned-v011-').replace('APL06.','AAF11.')
    source=source.replace('research-status.json','aligned-v011-status.json').replace('ForwardLab paused:', 'AlignedForward paused:')
    source=source.replace('af_books[3]','af_books[6]').replace('af_reasons[3]={"待初始化","待初始化","待初始化"}', 'af_reasons[6]={"待初始化","待初始化","待初始化","待初始化","待初始化","待初始化"}')
    source=source.replace('i<3','i<6').replace('m<3','m<6').replace('model>2','model>5')
    source=source.replace('string AFName(const int model){return model==0?"H1_BASE":model==1?"M15_FAST":"H1_M15_AGREE";}', '''string AFName(const int model){return (model%3==0?"H1_BASE":model%3==1?"M15_FAST":"H1_M15_AGREE")+(model>=3?"_COST2":"_BASECOST");}
double AFFee(const int model){return RoundTripFeePerLotUSD*(model>=3?2:1);}
void AFStressSpec(const int model,Spec &s)
{
   if(model<3)return;
   double half=s.spread*.5;s.bid-=half;s.ask+=half;s.spread=s.ask-s.bid;s.slip*=2;
}
bool AFReadSpec(const int index,const int model,Spec &s)
{if(!ReadSpec(index,s))return false;AFStressSpec(model,s);return APFinitePositive(s.bid)&&s.ask>=s.bid;}
double AFBudget(const double cash)
{return APPracticeBudget(cash,cash,PracticeCapitalUSD,RiskPercent);}
''')
    source=source.replace('return "DemoAutopilot\\\\aligned-v011-"+IntegerToString(af_campaign)', 'return af_root+IntegerToString(af_campaign)')
    source=source.replace('FLBook af_books[6];', 'string af_root="DemoAutopilot\\\\aligned-v011-";\ndouble af_initial_cash=0;\nFLBook af_books[6];')
    source=source.replace('string campaign_file="DemoAutopilot\\\\aligned-v011-campaign.csv";', 'string campaign_file=af_root+"campaign.csv";')
    source=source.replace('FLInit(af_books[i],MathMin(PracticeCapitalUSD,AccountBalance()))', 'FLInit(af_books[i],af_initial_cash)')
    source=source.replace('af_started=(datetime)StringToInteger(FileReadString(meta));FileClose(meta);', 'af_started=(datetime)StringToInteger(FileReadString(meta));af_initial_cash=StringToDouble(FileReadString(meta));FileClose(meta);')
    source=source.replace('af_campaign=(long)TimeLocal();af_started=TimeCurrent();', 'af_campaign=(long)TimeLocal();af_started=TimeCurrent();af_initial_cash=AccountBalance();')
    source=source.replace('AF_PROTOCOL,af_signature,af_campaign,(long)af_started);', 'AF_PROTOCOL,af_signature,af_campaign,(long)af_started,AFNum(af_initial_cash));')
    source=source.replace('if(af_campaign<=0||af_started<=0)', 'if(af_campaign<=0||af_started<=0||!APFinitePositive(af_initial_cash))')
    source=source.replace('if(!FLStateValid(p)||p.seq<=af_books[model].seq)', 'if(!FLStateValid(p)||MathAbs(p.start-af_initial_cash)>1e-7||p.seq<=af_books[model].seq)')
    source=source.replace('FLDirection(model,','FLDirection(model%3,')
    source=source.replace('budget=p.cash*RiskPercent/100','budget=AFBudget(p.cash)')
    source=source.replace('MathMin(s.maximum,MaximumLots),RoundTripFeePerLotUSD)', 'MathMin(s.maximum,MaximumLots),AFFee(model))')
    source=source.replace('p.fee=RoundTripFeePerLotUSD*lots;', 'p.fee=AFFee(model)*lots;')
    source=source.replace('FLExitChoice(next,','APProtectedExit(next,').replace('FLTighten(next,','APProtectedTighten(next,')
    source=source.replace('ReadSpec(next.index,s)','AFReadSpec(next.index,model,s)').replace('ReadSpec(s,spec)','AFReadSpec(s,m,spec)')
    source=source.replace('   PLShutdown();','').replace('   PortfolioCycle();','')
    source=source.replace('"|hold="', '"|policy=v09|risk_basis=fixed_cap500|cash=broker_balance_at_start|stress=2x_spread_fee_slip|hold="',1)
    # Stop creation of new shadow positions in exactly the same permission/leverage situations.
    source=source.replace('!AutoEntries||Paused()||!APCooldownReady', '!AutoEntries||Paused()||!MutationAllowed()||AccountLeverage()!=500||!APCooldownReady')
    # No old calendar schema is shared with this independent campaign. Include all six books.
    start=source.index('void AFCalendarSnapshot()');end=source.index('void AFStatus()',start)
    source=source[:start]+r'''
void AFCalendarSnapshot()
{
   datetime bar=iTime("XAUUSD",PERIOD_M5,0);if(bar<=af_started||bar<=af_calendar)return;
   double equity[6]={0,0,0,0,0,0};bool complete=true;
   for(int i=0;i<6;i++)
   {
      equity[i]=af_books[i].cash;
      if(af_books[i].active)
      {
         Spec s;if(!AFReadSpec(af_books[i].index,i,s)){complete=false;continue;}
         FLBook p=af_books[i];equity[i]+=FLMark(p,s.bid,s.ask)-p.slip*p.units;
      }
   }
   // The ledger checkpoints persist af_calendar indirectly via a separate append-only calendar.
   int f=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){AFFault("cannot write aligned calendar");return;}
   if(FileSize(f)==0)FileWrite(f,"campaign","bar_server","sample_server","sample_local","complete","h1_equity","m15_equity","agree_equity","h1_cost2_equity","m15_cost2_equity","agree_cost2_equity");
   FileSeek(f,0,SEEK_END);uint written=FileWrite(f,af_campaign,(long)bar,(long)TimeCurrent(),TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS),complete?1:0,
      AFNum(equity[0]),AFNum(equity[1]),AFNum(equity[2]),AFNum(equity[3]),AFNum(equity[4]),AFNum(equity[5]));
   FileFlush(f);FileClose(f);if(written==0){AFFault("aligned calendar write failed");return;}af_calendar=bar;
}
bool AFRestoreCalendar()
{
   if(!FileIsExist(AFPath("calendar.csv")))return true;
   int f=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){AFFault("cannot restore aligned calendar");return false;}
   bool header=true;datetime last=0;
   while(!FileIsEnding(f))
   {
      string row[];int count=0;
      while(!FileIsEnding(f)){ArrayResize(row,count+1);row[count++]=FileReadString(f);if(FileIsLineEnding(f))break;}
      if(count==1&&row[0]=="")continue;
      if(count!=11){FileClose(f);AFFault("incomplete aligned calendar row");return false;}
      if(header){header=false;if(row[0]!="campaign"||row[10]!="agree_cost2_equity"){FileClose(f);AFFault("calendar schema mismatch");return false;}continue;}
      for(int k=0;k<11;k++)if(k!=3&&!FLNumberToken(row[k])){FileClose(f);AFFault("invalid calendar number");return false;}
      datetime bar=(datetime)StringToInteger(row[1]);
      if(StringToInteger(row[0])!=af_campaign||bar<=last){FileClose(f);AFFault("calendar identity or ordering mismatch");return false;}
      last=bar;
   }
   FileClose(f);af_calendar=last;return true;
}
''' +source[end:]
    source=source.replace('if(!AFRestore())return false;', 'if(!AFRestore()||!AFRestoreCalendar())return false;')
    start=source.index('void AFStatus()');end=source.index('string AFDisplay()',start)
    source=source[:start]+r'''
string AFHealthJson()
{
   return "{\"initialized\":"+(af_initialized?"true":"false")+",\"fault\":"+(af_fault?"true":"false")+
      ",\"error\":\""+Escape(af_error)+"\",\"campaign\":"+IntegerToString(af_campaign)+",\"model_count\":6,\"automatic_promotion\":false}";
}
void AFStatus()
{
   string json="{\"version\":\"0.11\",\"protocol\":\""+AF_PROTOCOL+"\",\"campaign\":"+IntegerToString(af_campaign)+
      ",\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+"\",\"campaign_start_server\":\""+TimeToString(af_started,TIME_DATE|TIME_SECONDS)+
      "\",\"fault\":"+(af_fault?"true":"false")+",\"error\":\""+Escape(af_error)+"\",\"actual_order_operations\":0,\"automatic_promotion\":false,\"profitability_validated\":false,"+
      "\"practice_risk_capital_usd\":"+AFNum(PracticeCapitalUSD)+",\"exit_policy\":\"v09_early_protection\",\"models\":[";
   for(int i=0;i<6;i++)
   {
      FLBook p=af_books[i];if(i>0)json+=",";
      json+="{\"name\":\""+AFName(i)+"\",\"reason\":\""+Escape(af_reasons[i])+"\",\"active_virtual\":"+(p.active?"true":"false")+
         ",\"closed_count\":"+IntegerToString(p.n)+",\"wins\":"+IntegerToString(p.wins)+",\"cash\":"+AFNum(p.cash)+",\"starting_cash\":"+AFNum(p.start)+
         ",\"net_usd\":"+AFNum(p.cash-p.start)+",\"gross_gains\":"+AFNum(p.gains)+",\"gross_losses\":"+AFNum(p.losses)+
         ",\"max_observed_mark_drawdown\":"+AFNum(p.max_drawdown)+",\"next_flat_risk_budget_usd\":"+AFNum(AFBudget(p.cash))+
         ",\"cost_multiplier\":"+IntegerToString(i>=3?2:1)+"}";
   }
   json+="],\"comparison_scope\":\"whole independent one-position virtual portfolios including entry admission, cooldown and exit timing\","+
      "\"fill_model\":\"observed quote entry, sampled stop gaps and adverse exit slip; no queue, partial fills, swaps or broker rejections\","+
      "\"stress_model\":\"2x spread symmetrically widened at same midpoint; 2x estimated fee and slip reserve; affects admission, marking, stops and sizing\","+
      "\"statistical_claim\":\"none; same-day few-trade rankings are descriptive only\"}";
   if(!WriteSnapshot(af_root+"status.json",json))Print("Aligned snapshot unavailable; check freshness.");
}
''' +source[end:]
    assert not any(re.search(r'\b'+api+r'\s*\(',source) for api in ('OrderSend','OrderClose','OrderModify'))
    assert 'budget=AFBudget(p.cash)' in source and 'APProtectedExit' in source
    (ROOT/'AlignedForward.mqh').write_text(source,encoding='utf-8-sig')
    print('Generated isolated ALIGN11.R1: three directions x two complete execution-cost scenarios.')

if __name__=='__main__':main()
