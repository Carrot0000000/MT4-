"""Prevent a known fill-risk overrun before sending, then recover one audited demo incident."""
from pathlib import Path
import re,json,shutil
from build_upgrade_v0_10 import body
ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal/MQL4'
STAGE=ROOT/'staging-v0.12'
BACKUP=ROOT/'backup-fp-v0.11'

def main():
    STAGE.mkdir(exist_ok=True)
    current=(LIVE/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    if 'version "2.100"' not in current and not (BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').exists():raise RuntimeError('Expected v0.11')
    for rel in ['Experts/Codex/DemoPracticeAutopilot.mq4','Experts/Codex/DemoPracticeAutopilot.ex4','Scripts/Codex/UpgradeReviewV011.mq4','Presets/continuous-demo.set','Include/Codex/AlignedForward.mqh']:
        dest=BACKUP/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copy2(LIVE/rel,dest)
    old=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    src=old.replace('version "2.100"','version "2.200"').replace('v0.11','v0.12').replace('\\"version\\":\\"0.11\\"','\\"version\\":\\"0.12\\"').replace('FileWrite(f,"0.11",ticket>0?','FileWrite(f,"0.12",ticket>0?')
    src=src.replace('#include <Codex/ExecutionQuality.mqh>','#include <Codex/ExecutionQuality.mqh>\n#include <Codex/EntrySlippage.mqh>')
    old_entry=body(src,'TryEntry')
    new_entry=old_entry.replace('double minimum_risk=((distance+s.slip)', 'double entry_reserve=APEntryReserve(SlippagePoints,s.point);\n   if(entry_reserve<0){CheckOutcome(index,AP_SPEC_INVALID);return;}\n   double minimum_risk=((distance+s.slip+entry_reserve)')
    new_entry=new_entry.replace('APLots(budget,distance,s.slip,','APLots(budget,distance,s.slip+entry_reserve,')
    new_entry=new_entry.replace('double risk=(distance+s.slip)', 'double risk=(distance+s.slip+entry_reserve)')
    # The confirmed fill already includes the actual opening deviation: don't charge it twice.
    assert 'double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)' in new_entry
    src=src.replace(old_entry,new_entry)
    src=src.replace('APAdmissionRiskFloor(s.spread,MaxSpreadFraction,s.slip,','APAdmissionRiskFloor(s.spread,MaxSpreadFraction,s.slip+APEntryReserve(SlippagePoints,s.point),')
    src=src.replace('APMinimumRiskForSpread(tmp.spread,MaxSpreadFraction,tmp.slip,','APMinimumRiskForSpread(tmp.spread,MaxSpreadFraction,tmp.slip+APEntryReserve(SlippagePoints,tmp.point),')
    src=src.replace('LabCycle();EPCycle();AlignedCycle();','LabCycle();EPCycle();AlignedCycle();AlignedCycle12();')
    src=src.replace('AFShutdown();EPShutdown();FLShutdown();','BFShutdown();AFShutdown();EPShutdown();FLShutdown();')
    src=src.replace('AFHealthJson()+","+', 'BFHealthJson()+",\\\"legacy_aligned_forward_health\\\":"+AFHealthJson()+","+')
    src=src.replace('"\\\"entry_timeframe_minutes\\\":5,','"\\\"opening_slip_reserve_basis\\\":\\\"SlippagePoints times symbol point; separate from exit reserve\\\",\\\"entry_timeframe_minutes\\\":5,')
    src+='\n#include <Codex/AlignedForward12.mqh>\n'
    names=['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','SafeClose','SafeTighten','Manage','ReconcileFlat','Direction','RecentStructure','OnChartEvent']
    checks={n:body(old,n)==body(src,n) for n in names};assert all(checks.values())
    af=(BACKUP/'Include/Codex/AlignedForward.mqh').read_text(encoding='utf-8-sig')
    af=re.sub(r'\bAF(?=[A-Z_])','BF',af);af=re.sub(r'\baf_','bf_',af)
    af=af.replace('AlignedCycle','AlignedCycle12').replace('CODEX_ALIGNED_FORWARD_V011','CODEX_ALIGNED_FORWARD_V012').replace('ALIGN11.R1','ALIGN12.R1').replace('aligned-v011-','aligned-v012-').replace('AAF11.','AAF12.').replace('\\"version\\":\\"0.11\\"','\\"version\\":\\"0.12\\"')
    af=af.replace('"|policy=v09|', '"|entry_slippage_points="+IntegerToString(SlippagePoints)+"|policy=v09|')
    af=af.replace('double lots=APLots(budget,distance,s.slip,', 'double entry_reserve=APEntryReserve(SlippagePoints,s.point)*(model>=3?2:1);\n   double lots=APLots(budget,distance,s.slip+entry_reserve,')
    (STAGE/'DemoPracticeAutopilot.mq4').write_text(src,encoding='utf-8-sig')
    (ROOT/'AlignedForward12.mqh').write_text(af,encoding='utf-8-sig')
    for name in ['EntrySlippage.mqh','AlignedForward12.mqh']:
        shutil.copy2(ROOT/name,STAGE/name);shutil.copy2(ROOT/name,LIVE/'Include/Codex'/name)
    (STAGE/'guard-review.json').write_text(json.dumps({'checks':checks,'risk_cap_unchanged':True,'post_fill_check_unchanged':True,'opening_reserve_added':True,'old_research_retained':True},indent=2),encoding='utf-8')
    print('Staged v0.12: opening deviation reserved before sending; existing risk and exit guards unchanged.')
if __name__=='__main__':main()
