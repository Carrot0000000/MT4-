﻿#property strict
#property version "1.500"
#property description "Continuous practice; hard locked to one MetaQuotes DEMO login. Unvalidated strategy."
#include "AutopilotCore.mqh"

input bool AutoEntries=false;
input double RiskPercent=1;
input double MaximumLots=0.01;
input int CooldownMinutes=5;
input int MaximumHoldMinutes=20;
input double RoundTripFeePerLotUSD=0;
input int SlippagePoints=20;
input int EntryWindowSeconds=120;
input double MaxSpreadFraction=0.20;
input double EntryDriftATR=0.25;
// There is deliberately no cumulative loss or daily trade-count limit in this demo-only version.
const int MAGIC=2026101217;
const string PREFIX="DAP_";
const ENUM_TIMEFRAMES ENTRY_TF=PERIOD_M5;
const int ENTRY_SECONDS=300;
string symbols[2]={"XAUUSD","XAGUSD"};
string reasons[2]={"等待报价和已完成K线","等待报价和已完成K线"};
datetime attempted[2]={0,0},last_quote_time[2]={0,0},last_arrival[2]={0,0};
bool seen_new_quote[2]={false,false},working=false,have_owner=false;
string key="AP02.176318407.",mode="初始化";
datetime last_status=0,last_sync=0;
datetime last_history_request=0;
bool closed_this_cycle=false;
datetime last_metrics_flush=0;
int last_codes[2]={0,0},check_counts[2]={0,0};
datetime last_bars[2]={0,0},last_local_checks[2]={0,0},last_server_checks[2]={0,0};
double last_budgets[2]={-1,-1},last_minimum_risks[2]={-1,-1};
double spread_minimum_risks[2]={-1,-1},current_spreads[2]={-1,-1};
bool quotes_fresh[2]={false,false};

struct Spec
{
   double tick,value,point,minimum,step,maximum,spread,bid,ask,slip;
   int digits;
};

string Escape(string s)
{ StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");StringReplace(s,"\r"," ");StringReplace(s,"\n"," ");return s; }
string K(const string field,const int ticket=0)
{return key+field+(ticket>0?"."+IntegerToString(ticket):"");}
bool Identity()
{return APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting()) && AccountCurrency()=="USD";}
string OwnerMarker(){return K("owner_chart_"+IntegerToString(ChartID()));}
bool Owner()
{
   // Chart IDs exceed double's exact integer range; store the exact ID in the variable NAME.
   return have_owner && GlobalVariableCheck(K("owner")) && GlobalVariableGet(K("owner"))==1 &&
      GlobalVariableCheck(OwnerMarker()) && GlobalVariableGet(OwnerMarker())==1;
}
bool MutationAllowed()
{
   return Identity() && Owner() && IsConnected() && IsTradeAllowed() && !IsTradeContextBusy() &&
      (bool)AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) && (bool)AccountInfoInteger(ACCOUNT_TRADE_EXPERT);
}
bool Paused(){return GlobalVariableGet(K("pause"))>0 || GlobalVariableGet(K("halt"))>0;}
int IndexOf(const string symbol){for(int i=0;i<2;i++)if(symbols[i]==symbol)return i;return -1;}

void Event(const string action,const string symbol,const int ticket,const string details)
{
   int f=FileOpen("DemoAutopilot\\events.csv",FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);mode="暂停：无法写入交易记录";return;}
   if(FileSize(f)==0)FileWrite(f,"server_time","local_time","action","symbol","ticket","details");
   FileSeek(f,0,SEEK_END);
   FileWrite(f,TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS),action,symbol,ticket,details);
   FileFlush(f);FileClose(f);
   Print("DemoAutopilot: ",action," ",symbol," #",ticket," ",details);
}

string DK(const int index,const string field){return K("d04."+symbols[index]+"."+field);}
void CheckOutcome(const int index,const int code,const double minimum_risk=-1,const bool force=false)
{
   reasons[index]=APCheckText(code);
   datetime bar=iTime(symbols[index],ENTRY_TF,0);
   if(!force&&!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds))return;
   if(!APRecordChanged(last_bars[index],last_codes[index],bar,code))return;
   last_bars[index]=bar;last_codes[index]=code;check_counts[index]++;
   last_local_checks[index]=TimeLocal();last_server_checks[index]=TimeCurrent();
   last_budgets[index]=MathMin(AccountBalance(),AccountEquity())*RiskPercent/100;
   last_minimum_risks[index]=minimum_risk;
   GlobalVariableSet(DK(index,"bar"),(double)bar);GlobalVariableSet(DK(index,"code"),code);
   GlobalVariableSet(DK(index,"local"),(double)last_local_checks[index]);
   GlobalVariableSet(DK(index,"server"),(double)last_server_checks[index]);
   GlobalVariableSet(DK(index,"budget"),last_budgets[index]);
   GlobalVariableSet(DK(index,"min_risk"),minimum_risk);GlobalVariableSet(DK(index,"count"),check_counts[index]);
   GlobalVariablesFlush();
   Event(code==AP_FILLED?"CHECK_ACCEPTED":"CHECK_REJECTED",symbols[index],0,
      "v0.5 timeframe=M5 bar_server="+TimeToString(bar,TIME_DATE|TIME_MINUTES)+" code="+IntegerToString(code)+
      " reason="+APCheckText(code)+" budget_usd="+DoubleToString(last_budgets[index],4)+
      " minimum_structural_risk_usd="+(minimum_risk>=0?DoubleToString(minimum_risk,4):"unknown")+
      " spread_gate_risk_lower_bound_usd="+(quotes_fresh[index]?DoubleToString(spread_minimum_risks[index],4):"unknown"));
}
void RestoreChecks()
{
   for(int i=0;i<2;i++)
   {
      if(!GlobalVariableCheck(DK(i,"code")))continue;
      last_codes[i]=(int)GlobalVariableGet(DK(i,"code"));last_bars[i]=(datetime)GlobalVariableGet(DK(i,"bar"));
      last_local_checks[i]=(datetime)GlobalVariableGet(DK(i,"local"));
      last_server_checks[i]=(datetime)GlobalVariableGet(DK(i,"server"));
      last_budgets[i]=GlobalVariableGet(DK(i,"budget"));last_minimum_risks[i]=GlobalVariableGet(DK(i,"min_risk"));
      check_counts[i]=(int)GlobalVariableGet(DK(i,"count"));
   }
}
string VisibleReason(const int index)
{
   if(reasons[index]=="等待下一次M5收盘触发" && last_codes[index]>0)
      return "等新K线；上次"+TimeToString(last_local_checks[index],TIME_MINUTES)+" "+APCheckText(last_codes[index]);
   return reasons[index];
}
string Metric(const double value){return MathIsValidNumber(value)&&value>=0?DoubleToString(value,6):"null";}
string CheckJson(const int index)
{
   return "{\"last_code\":"+IntegerToString(last_codes[index])+",\"last_reason\":\""+Escape(APCheckText(last_codes[index]))+
      "\",\"last_check_local\":\""+(last_local_checks[index]>0?TimeToString(last_local_checks[index],TIME_DATE|TIME_SECONDS):"")+
      "\",\"last_check_server\":\""+(last_server_checks[index]>0?TimeToString(last_server_checks[index],TIME_DATE|TIME_SECONDS):"")+
      "\",\"signal_bar_close_server\":\""+(last_bars[index]>0?TimeToString(last_bars[index],TIME_DATE|TIME_SECONDS):"")+
      "\",\"last_budget_usd\":"+Metric(last_budgets[index])+",\"last_minimum_structural_risk_usd\":"+Metric(last_minimum_risks[index])+
      ",\"recorded_outcome_changes\":"+IntegerToString(check_counts[index])+",\"quotes_fresh\":"+(quotes_fresh[index]?"true":"false")+
      ",\"m5_bars\":"+IntegerToString(iBars(symbols[index],ENTRY_TF))+",\"h1_bars\":"+IntegerToString(iBars(symbols[index],PERIOD_H1))+
      ",\"current_spread_price\":"+(quotes_fresh[index]?Metric(current_spreads[index]):"null")+
      ",\"current_spread_gate_risk_lower_bound_usd\":"+(quotes_fresh[index]?Metric(spread_minimum_risks[index]):"null")+"}";
}

bool ReadSpec(const int index,Spec &s)
{
   string symbol=symbols[index];MqlTick q;
   if(!SymbolInfoTick(symbol,q)||!APFinitePositive(q.bid)||!APFinitePositive(q.ask)||q.ask<q.bid)return false;
   if(q.time!=last_quote_time[index])
   {
      if(last_quote_time[index]!=0)seen_new_quote[index]=true;
      last_quote_time[index]=q.time;last_arrival[index]=TimeLocal();
   }
   if(!seen_new_quote[index] || TimeLocal()-last_arrival[index]>5 || TimeCurrent()-q.time>5 || q.time>TimeCurrent()+2)return false;
   s.bid=q.bid;s.ask=q.ask;s.spread=q.ask-q.bid;
   s.tick=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   s.value=MarketInfo(symbol,MODE_TICKVALUE);s.point=MarketInfo(symbol,MODE_POINT);
   s.minimum=MarketInfo(symbol,MODE_MINLOT);s.step=MarketInfo(symbol,MODE_LOTSTEP);
   s.maximum=MarketInfo(symbol,MODE_MAXLOT);s.digits=(int)MarketInfo(symbol,MODE_DIGITS);
   s.slip=index==0?0.05:0.02;
   return APFinitePositive(s.tick)&&APFinitePositive(s.value)&&APFinitePositive(s.point)&&
          APFinitePositive(s.minimum)&&APFinitePositive(s.step)&&APFinitePositive(s.maximum);
}

bool IsOwnedSelected()
{return OrderMagicNumber()==MAGIC && IndexOf(OrderSymbol())>=0 && (OrderType()==OP_BUY||OrderType()==OP_SELL);}
int OwnedCount()
{
   int count=0;for(int i=OrdersTotal()-1;i>=0;i--)if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)&&IsOwnedSelected())count++;
   return count;
}

bool ClosedJournalSelected()
{
   int ticket=OrderTicket();if(GlobalVariableCheck(K("journal_closed",ticket)))return true;
   int f=FileOpen("DemoAutopilot\\closed-trades.csv",FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);return false;}
   if(FileSize(f)==0)FileWrite(f,"ticket","symbol","side","lots","open_server","close_server","open_price","close_price",
      "profit","commission","swap","net_usd","reserved_r_usd","peak_observed_estimate_usd","worst_observed_estimate_usd",
      "initial_sl_recorded","initial_tp_recorded","final_sl","final_tp","exit_intent","metrics_since_v05","outside_protection_change_seen");
   FileSeek(f,0,SEEK_END);
   uint written=FileWrite(f,ticket,OrderSymbol(),OrderType()==OP_BUY?1:-1,DoubleToString(OrderLots(),8),
      TimeToString(OrderOpenTime(),TIME_DATE|TIME_SECONDS),TimeToString(OrderCloseTime(),TIME_DATE|TIME_SECONDS),
      DoubleToString(OrderOpenPrice(),8),DoubleToString(OrderClosePrice(),8),DoubleToString(OrderProfit(),4),
      DoubleToString(OrderCommission(),4),DoubleToString(OrderSwap(),4),DoubleToString(OrderProfit()+OrderCommission()+OrderSwap(),4),
      DoubleToString(GlobalVariableGet(K("initial_R",ticket)),4),DoubleToString(GlobalVariableGet(K("peak",ticket)),4),
      GlobalVariableCheck(K("worst",ticket))?DoubleToString(GlobalVariableGet(K("worst",ticket)),4):"unknown",
      GlobalVariableCheck(K("initial_sl",ticket))?DoubleToString(GlobalVariableGet(K("initial_sl",ticket)),8):"unknown",
      GlobalVariableCheck(K("initial_tp",ticket))?DoubleToString(GlobalVariableGet(K("initial_tp",ticket)),8):"unknown",
      DoubleToString(OrderStopLoss(),8),DoubleToString(OrderTakeProfit(),8),
      APExitText((int)GlobalVariableGet(K("exit_intent",ticket))),GlobalVariableCheck(K("worst",ticket))?"true":"false",
      GlobalVariableGet(K("outside_change",ticket))>0?"true":"false");
   FileFlush(f);FileClose(f);
   if(written==0){GlobalVariableSet(K("halt"),1);return false;}
   GlobalVariableSet(K("journal_closed",ticket),1);return true;
}

void SyncClosed()
{
   datetime latest=(datetime)GlobalVariableGet(K("last_close"));
   for(int i=OrdersHistoryTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)||!IsOwnedSelected()||OrderCloseTime()==0)continue;
      if(OrderCloseTime()>latest)latest=OrderCloseTime();
      int ticket=OrderTicket();
      if(!GlobalVariableCheck(K("closed_logged",ticket)))
      {
         double net=OrderProfit()+OrderCommission()+OrderSwap();
         Event("CLOSED",OrderSymbol(),ticket,"net_usd="+DoubleToString(net,2)+" exit="+DoubleToString(OrderClosePrice(),(int)MarketInfo(OrderSymbol(),MODE_DIGITS)));
         GlobalVariableSet(K("closed_logged",ticket),1);
      }
      ClosedJournalSelected();
   }
   GlobalVariableSet(K("last_close"),(double)latest);
}

// A vanished live ticket must be confirmed in history before another order can be sent.
bool ReconcileFlat()
{
   if(OrdersTotal()!=0)return false;
   int ticket=(int)GlobalVariableGet(K("last_live_ticket"));
   if(ticket>0)
   {
      if(!OrderSelect(ticket,SELECT_BY_TICKET)||!IsOwnedSelected()||OrderCloseTime()==0)return false;
      datetime closed=OrderCloseTime(),latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      GlobalVariableSet(K("last_live_ticket"),0);closed_this_cycle=true;
      SyncClosed();last_sync=TimeLocal();GlobalVariablesFlush();
   }
   return true;
}
bool EntryGate()
{
   if(!Identity()||!Owner()||OrdersTotal()!=0||Paused()||!AutoEntries)return false;
   bool reconciled=ReconcileFlat();
   return APEntryCycleReady(closed_this_cycle,reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes);
}

bool SafeClose(const int ticket,const int requested)
{
   if(!Identity()||!Owner()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int intent=APStickyExit((int)GlobalVariableGet(K("exit_intent",ticket)),requested);
   GlobalVariableSet(K("exit_intent",ticket),intent);GlobalVariablesFlush();
   if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))return false;
   if(!MutationAllowed())return false;
   string symbol=OrderSymbol();int index=IndexOf(symbol);Spec s;
   RefreshRates();
   if(!ReadSpec(index,s))return false;
   double lots=OrderLots(),price=OrderType()==OP_BUY?s.bid:s.ask;
   // The same account and ownership guards are rechecked immediately before every mutation.
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();
   if(ok)
   {
      // Persist immediately; SyncClosed's periodic scan was too late in v0.4.
      datetime closed=TimeCurrent();
      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0)closed=OrderCloseTime();
      datetime latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      closed_this_cycle=true;GlobalVariablesFlush();
   }
   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,APExitText(intent)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:APRetrySeconds(error))));
   return ok;
}

bool SafeTighten(const int ticket,const double target)
{
   if(!MutationAllowed()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());Spec s;
   if(!ReadSpec(index,s)||!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))return false;
   double old=OrderStopLoss();
   if((side==1&&target<=old+s.tick*.5)||(side==-1&&target>=old-s.tick*.5))return false;
   double minimum=(MathMax(MarketInfo(OrderSymbol(),MODE_STOPLEVEL),MarketInfo(OrderSymbol(),MODE_FREEZELEVEL))+1)*s.point;
   if((side==1&&target>=s.bid-minimum)||(side==-1&&target<=s.ask+minimum))return false;
   string symbol=OrderSymbol();double open=OrderOpenPrice(),tp=OrderTakeProfit();
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderModify(ticket,open,target,tp,0,clrNONE);int error=GetLastError();
   if(ok)
   {GlobalVariableSet(K("observed_sl",ticket),target);GlobalVariableSet(K("observed_tp",ticket),tp);GlobalVariablesFlush();}
   Event(ok?"SL_TIGHTEN_ACCEPTED":"SL_TIGHTEN_FAILED",symbol,ticket,"sl="+DoubleToString(target,s.digits)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:5)));
   return ok;
}

void ObserveProtectionSelected()
{
   int ticket=OrderTicket();double sl=OrderStopLoss(),tp=OrderTakeProfit();
   if(GlobalVariableCheck(K("observed_sl",ticket)))
   {
      double old_sl=GlobalVariableGet(K("observed_sl",ticket)),old_tp=GlobalVariableGet(K("observed_tp",ticket));
      if(MathAbs(sl-old_sl)>1e-7||MathAbs(tp-old_tp)>1e-7)
      {
         GlobalVariableSet(K("outside_change",ticket),1);
         Event("PROTECTION_CHANGED_OUTSIDE_EA",OrderSymbol(),ticket,"old_sl="+DoubleToString(old_sl,8)+" new_sl="+DoubleToString(sl,8)+
            " old_tp="+DoubleToString(old_tp,8)+" new_tp="+DoubleToString(tp,8)+" actor_unknown; retain permitted user adjustment");
      }
   }
   GlobalVariableSet(K("observed_sl",ticket),sl);GlobalVariableSet(K("observed_tp",ticket),tp);
}

void Manage()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      int ticket=OrderTicket(),side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());
      GlobalVariableSet(K("last_live_ticket"),ticket);
      ObserveProtectionSelected();
      Spec s;if(!ReadSpec(index,s))continue;
      if(GlobalVariableGet(K("flatten"))>0){SafeClose(ticket,AP_EXIT_USER);continue;}
      if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_PROTECTION);continue;}
      if(!GlobalVariableCheck(K("initial_R",ticket)))
      {
         // A crash immediately after OrderSend can recover the prior persisted plan.
         double pending=GlobalVariableGet(K("pending_R"));
         if(APFinitePositive(pending))GlobalVariableSet(K("initial_R",ticket),pending);
         else{GlobalVariableSet(K("halt"),1);mode="暂停：持仓初始风险状态缺失";continue;}
      }
      double r=GlobalVariableGet(K("initial_R",ticket));
      double units=OrderLots()*s.value/s.tick;
      double cost=MathMax(0,-OrderCommission())+MathMax(0,-OrderSwap());
      double remaining_risk=MathMax(0,side*(OrderOpenPrice()-OrderStopLoss()))*units+s.slip*units+cost;
      if(remaining_risk>r+0.01)
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_RISK);continue;}
      double price=side==1?s.bid:s.ask;
      double net=APNet(side,OrderOpenPrice(),price,units,cost);
      double peak=MathMax(net,GlobalVariableGet(K("peak",ticket)));
      GlobalVariableSet(K("peak",ticket),peak);
      double worst=GlobalVariableCheck(K("worst",ticket))?GlobalVariableGet(K("worst",ticket)):net;
      GlobalVariableSet(K("worst",ticket),MathMin(net,worst));
      if(TimeLocal()-last_metrics_flush>=5){GlobalVariablesFlush();last_metrics_flush=TimeLocal();}
      int intent=(int)GlobalVariableGet(K("exit_intent",ticket));
      if(intent>0){SafeClose(ticket,intent);continue;}
      if(APGiveback(peak,net,r)){SafeClose(ticket,AP_EXIT_GIVEBACK);continue;}
      if(MaximumHoldMinutes>0 && TimeCurrent()-OrderOpenTime()>=MaximumHoldMinutes*60)
      {SafeClose(ticket,AP_EXIT_TIME);continue;}
      if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))continue;
      if(net>=r)
      {
         double be=APBreakEven(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side);
         if(APFinitePositive(be))SafeTighten(ticket,be);
      }
   }
   if(OwnedCount()==0 && GlobalVariableGet(K("flatten"))>0)GlobalVariableSet(K("flatten"),0);
}

int Direction(const string symbol)
{
   double close=iClose(symbol,PERIOD_H1,1),fast=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1);
   return APBias(close,fast);
}

double RecentStructure(const string symbol,const int side)
{
   // Extremes of three already closed M5 bars; never shorten this stop to fit a budget.
   double first=side==1?iLow(symbol,ENTRY_TF,1):iHigh(symbol,ENTRY_TF,1);
   double second=side==1?iLow(symbol,ENTRY_TF,2):iHigh(symbol,ENTRY_TF,2);
   double third=side==1?iLow(symbol,ENTRY_TF,3):iHigh(symbol,ENTRY_TF,3);
   return APRangeExtreme(first,second,third,side);
}
void RequestHistory()
{
   MqlRates rates[];
   for(int i=0;i<2;i++)
   {
      if(iBars(symbols[i],ENTRY_TF)<101)CopyRates(symbols[i],ENTRY_TF,0,120,rates);
      if(iBars(symbols[i],PERIOD_H1)<101)CopyRates(symbols[i],PERIOD_H1,0,120,rates);
   }
}

bool EntryJournal(const int index,const int ticket,const int side,const Spec &s,const double lots,
                  const double fill,const double sl,const double tp,const double risk,const double budget)
{
   string symbol=symbols[index];int f=FileOpen("DemoAutopilot\\entry-features.csv",FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);return false;}
   if(FileSize(f)==0)FileWrite(f,"version","stage","ticket","server_time","symbol","side","lots","fill","sl","tp","reserved_r","budget",
      "spread","tick","tick_value","m5_signal_start","m5_open","m5_close","previous_close","m5_ema20","m5_atr14","h1_signal_start","h1_close","h1_ema50");
   FileSeek(f,0,SEEK_END);
   uint written=FileWrite(f,"0.5",ticket>0?"filled":"plan",ticket,TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),symbol,side,
      DoubleToString(lots,8),DoubleToString(fill,8),DoubleToString(sl,8),DoubleToString(tp,8),DoubleToString(risk,4),DoubleToString(budget,4),
      DoubleToString(s.spread,8),DoubleToString(s.tick,8),DoubleToString(s.value,8),
      TimeToString(iTime(symbol,ENTRY_TF,1),TIME_DATE|TIME_SECONDS),DoubleToString(iOpen(symbol,ENTRY_TF,1),8),
      DoubleToString(iClose(symbol,ENTRY_TF,1),8),DoubleToString(iClose(symbol,ENTRY_TF,2),8),
      DoubleToString(iMA(symbol,ENTRY_TF,20,0,MODE_EMA,PRICE_CLOSE,1),8),DoubleToString(iATR(symbol,ENTRY_TF,14,1),8),
      TimeToString(iTime(symbol,PERIOD_H1,1),TIME_DATE|TIME_SECONDS),DoubleToString(iClose(symbol,PERIOD_H1,1),8),
      DoubleToString(iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1),8));
   FileFlush(f);FileClose(f);if(written==0)GlobalVariableSet(K("halt"),1);return written>0;
}

void TryEntry(const int index)
{
   if(!EntryGate())return;
   string symbol=symbols[index];Spec s;
   if(!ReadSpec(index,s)){CheckOutcome(index,AP_QUOTE);return;}
   if(iBars(symbol,PERIOD_H1)<101||iBars(symbol,ENTRY_TF)<101){CheckOutcome(index,AP_HISTORY);return;}
   datetime bar=iTime(symbol,ENTRY_TF,0),previous=iTime(symbol,ENTRY_TF,1);
   if(previous+ENTRY_SECONDS!=bar||!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds)){reasons[index]="等待下一次M5收盘触发";return;}
   if(attempted[index]==bar || (datetime)GlobalVariableGet(K("bar_"+symbol))==bar){reasons[index]="本根K线已检查，等待新信号";return;}
   datetime h1_end=iTime(symbol,PERIOD_H1,1)+3600;
   if(h1_end>TimeCurrent()||TimeCurrent()-h1_end>=3600){CheckOutcome(index,AP_H1_STALE);return;}
   for(int j=1;j<5;j++)if(iTime(symbol,ENTRY_TF,j)-iTime(symbol,ENTRY_TF,j+1)!=ENTRY_SECONDS)
   {CheckOutcome(index,AP_GAP);return;}
   int side=Direction(symbol);
   if(side==0){CheckOutcome(index,AP_DIRECTION);return;}
   double close=iClose(symbol,ENTRY_TF,1),open=iOpen(symbol,ENTRY_TF,1);
   double ema=iMA(symbol,ENTRY_TF,20,0,MODE_EMA,PRICE_CLOSE,1),previous_close=iClose(symbol,ENTRY_TF,2);
   if(!APMomentum(side,open,close,previous_close,ema)){CheckOutcome(index,AP_TRIGGER);return;}
   double atr=iATR(symbol,ENTRY_TF,14,1),structure=RecentStructure(symbol,side);
   if(!APFinitePositive(atr)||!APFinitePositive(structure)){CheckOutcome(index,AP_STRUCTURE);return;}
   if(MathAbs(s.bid-close)>APDriftLimit(atr,s.tick,EntryDriftATR)){CheckOutcome(index,AP_DRIFT);return;}
   double structural_sl=APStop(structure,atr,side,s.spread,s.tick,s.digits),fill=side==1?s.ask:s.bid;
   double sl=APCostAwareInitialStop(structural_sl,fill,s.spread,MaxSpreadFraction,s.tick,s.digits,side);
   double distance=side*(fill-sl);
   if(!APFinitePositive(sl)||!APFinitePositive(distance)){CheckOutcome(index,AP_STOP);return;}
   double minimum_risk=((distance+s.slip)/s.tick*s.value+RoundTripFeePerLotUSD)*s.minimum;
   if(s.spread>MaxSpreadFraction*distance){CheckOutcome(index,AP_SPREAD,minimum_risk);return;}
   double budget=MathMin(AccountBalance(),AccountEquity())*RiskPercent/100;
   double lots=APLots(budget,distance,s.slip,s.tick,s.value,s.minimum,s.step,MathMin(s.maximum,MaximumLots),RoundTripFeePerLotUSD);
   if(lots==0){CheckOutcome(index,AP_BUDGET,minimum_risk);return;}
   double tp=APPrice(fill+side*2*distance,s.tick,s.digits,side==1);
   double stop_distance=(MarketInfo(symbol,MODE_STOPLEVEL)+1)*s.point;
   if((side==1&&(s.bid-sl<stop_distance||tp-s.bid<stop_distance)) ||
      (side==-1&&(sl-s.ask<stop_distance||s.ask-tp<stop_distance)))
   {CheckOutcome(index,AP_STOP_LEVEL,minimum_risk);return;}
   int type=side==1?OP_BUY:OP_SELL;ResetLastError();
   double free=AccountFreeMarginCheck(symbol,type,lots);int margin_error=GetLastError();
   if(margin_error!=0||free<=0||MarketInfo(symbol,MODE_TRADEALLOWED)==0){CheckOutcome(index,AP_MARGIN,minimum_risk);return;}
   if(!MutationAllowed()||!EntryGate()){CheckOutcome(index,AP_PERMISSION,minimum_risk);return;}
   // Persist signal consumption before sending. Unknown execution errors NEVER trigger an immediate duplicate resend.
   attempted[index]=bar;GlobalVariableSet(K("bar_"+symbol),(double)bar);
   double risk=(distance+s.slip)/s.tick*s.value*lots+RoundTripFeePerLotUSD*lots;
   GlobalVariableSet(K("pending_R"),risk);GlobalVariablesFlush();
   Event("ENTRY_PLAN",symbol,0,"side="+IntegerToString(side)+" lots="+DoubleToString(lots,8)+" risk_usd="+DoubleToString(risk,4)+" sl="+DoubleToString(sl,s.digits)+" tp="+DoubleToString(tp,s.digits));
   if(!EntryJournal(index,0,side,s,lots,fill,sl,tp,risk,budget))return;
   if(!MutationAllowed()||!EntryGate())return;
   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.5",MAGIC,0,clrNONE);
   int error=GetLastError();
   if(ticket<0)
   {
      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));
      if(error==128||error==6){GlobalVariableSet(K("halt"),1);Event("HALT",symbol,0,"uncertain execution; inspect account before manual recovery");}
      CheckOutcome(index,AP_SEND_ERROR,minimum_risk,true);return;
   }
   GlobalVariableSet(K("initial_R",ticket),risk);GlobalVariableSet(K("peak",ticket),0);
   GlobalVariableSet(K("last_live_ticket"),ticket);GlobalVariablesFlush();
   Event("ENTRY_ACCEPTED",symbol,ticket,"server returned ticket");
   if(!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())
   {GlobalVariableSet(K("halt"),1);Event("HALT",symbol,ticket,"cannot verify accepted ticket");return;}
   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)/s.tick*s.value*OrderLots()+RoundTripFeePerLotUSD*OrderLots();
   GlobalVariableSet(K("initial_R",ticket),actual);
   GlobalVariableSet(K("initial_sl",ticket),OrderStopLoss());GlobalVariableSet(K("initial_tp",ticket),OrderTakeProfit());
   GlobalVariableSet(K("observed_sl",ticket),OrderStopLoss());GlobalVariableSet(K("observed_tp",ticket),OrderTakeProfit());
   GlobalVariablesFlush();
   EntryJournal(index,ticket,side,s,OrderLots(),OrderOpenPrice(),OrderStopLoss(),OrderTakeProfit(),actual,budget);
   if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit())||actual>budget+0.01)
   {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_FILL);}
   CheckOutcome(index,AP_FILLED,minimum_risk,true);
}

void Label(const string name,const string text,const int y)
{
   string obj=PREFIX+name;if(ObjectFind(0,obj)<0)ObjectCreate(0,obj,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,obj,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,obj,OBJPROP_XDISTANCE,24);
   ObjectSetInteger(0,obj,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,obj,OBJPROP_COLOR,clrDarkSlateGray);
   ObjectSetInteger(0,obj,OBJPROP_FONTSIZE,10);ObjectSetInteger(0,obj,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,obj,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,obj,OBJPROP_TEXT,text);
}
void Button(const string name,const string text,const int x)
{
   string obj=PREFIX+name;if(ObjectFind(0,obj)<0)ObjectCreate(0,obj,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,obj,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,obj,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,obj,OBJPROP_YDISTANCE,178);ObjectSetInteger(0,obj,OBJPROP_XSIZE,235);ObjectSetInteger(0,obj,OBJPROP_YSIZE,30);
   ObjectSetInteger(0,obj,OBJPROP_COLOR,clrDarkSlateGray);ObjectSetInteger(0,obj,OBJPROP_BGCOLOR,clrWhiteSmoke);
   ObjectSetInteger(0,obj,OBJPROP_FONTSIZE,10);ObjectSetString(0,obj,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,obj,OBJPROP_TEXT,text);
}
void Display()
{
   string bg=PREFIX+"bg";if(ObjectFind(0,bg)<0)ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,12);
   ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,20);ObjectSetInteger(0,bg,OBJPROP_XSIZE,510);ObjectSetInteger(0,bg,OBJPROP_YSIZE,200);
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,clrWhite);ObjectSetInteger(0,bg,OBJPROP_COLOR,clrSilver);
   ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   Label("title","频繁模拟练习 v0.5  |  "+mode,30);
   Label("balance",Identity()?"余额 "+DoubleToString(AccountBalance(),2)+" USD  |  预留风险 "+DoubleToString(RiskPercent,2)+"% / "+DoubleToString(MathMin(AccountBalance(),AccountEquity())*RiskPercent/100,2):"账户不匹配：禁止任何交易",57);
   Label("gold","黄金："+VisibleReason(0),84);Label("silver","白银："+VisibleReason(1),109);
   Label("rule","每5分钟检查；同时一笔；累计亏损不限",137);
   Button("pause",Paused()?"继续模拟入场":"暂停新单（继续管理持仓）",24);
   Button("flatten","平仓并停止（本程序订单）",270);ChartRedraw();
}

void Status()
{
   int f=FileOpen("DemoAutopilot\\status.json",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);return;}
   string json="{\"version\":\"0.5\",\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+
      "\",\"server_time\":\""+TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS)+"\",\"expected_demo\":"+(Identity()?"true":"false")+
      ",\"connected\":"+(IsConnected()?"true":"false")+",\"trade_allowed\":"+(IsTradeAllowed()?"true":"false")+
      ",\"auto_entries_input\":"+(AutoEntries?"true":"false")+",\"paused\":"+(Paused()?"true":"false")+
      ",\"halt\":"+(GlobalVariableGet(K("halt"))>0?"true":"false")+",\"owner\":"+(Owner()?"true":"false")+
      ",\"mode\":\""+Escape(mode)+"\",\"balance\":"+DoubleToString(Identity()?AccountBalance():0,2)+
      ",\"equity\":"+DoubleToString(Identity()?AccountEquity():0,2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+
      ",\"owned_open_orders\":"+IntegerToString(OwnedCount())+",\"risk_percent\":"+DoubleToString(RiskPercent,3)+
      ",\"cumulative_loss_cap\":null,\"profitability_validated\":false,\"news_filter_installed\":false,"+
      "\"entry_timeframe_minutes\":5,\"cooldown_minutes\":"+IntegerToString(CooldownMinutes)+
      ",\"maximum_hold_minutes\":"+IntegerToString(MaximumHoldMinutes)+",\"entry_window_seconds\":"+IntegerToString(EntryWindowSeconds)+
      ",\"max_spread_fraction\":"+DoubleToString(MaxSpreadFraction,3)+","+
      "\"last_close_server\":\""+TimeToString((datetime)GlobalVariableGet(K("last_close")),TIME_DATE|TIME_SECONDS)+
      "\",\"last_known_ticket\":"+IntegerToString((int)GlobalVariableGet(K("last_live_ticket")))+","+
      "\"gold_reason\":\""+Escape(reasons[0])+"\",\"silver_reason\":\""+Escape(reasons[1])+"\","+
      "\"entry_checks\":{\"XAUUSD\":"+CheckJson(0)+",\"XAGUSD\":"+CheckJson(1)+"}}";
   FileWriteString(f,json);FileFlush(f);FileClose(f);
}

void Cycle()
{
   if(working)return;working=true;closed_this_cycle=false;
   if(!Identity())mode="账户不匹配，禁止交易";
   else if(!Owner())mode="重复实例，禁止交易";
   else if(!IsConnected())mode="断线；等待连接";
   else
   {
      if(TimeLocal()-last_history_request>=5){RequestHistory();last_history_request=TimeLocal();}
      Spec tmp;for(int i=0;i<2;i++)
      {
         quotes_fresh[i]=ReadSpec(i,tmp);
         if(quotes_fresh[i])
         {
            current_spreads[i]=tmp.spread;
            spread_minimum_risks[i]=APMinimumRiskForSpread(tmp.spread,MaxSpreadFraction,tmp.slip,tmp.tick,tmp.value,tmp.minimum,RoundTripFeePerLotUSD);
         }
      }
      if(TimeLocal()-last_sync>=5){SyncClosed();last_sync=TimeLocal();}
      Manage();
      bool flat_reconciled=OrdersTotal()==0?ReconcileFlat():false;
      if(GlobalVariableGet(K("halt"))>0)mode="异常暂停，检查记录";
      else if(!AutoEntries||Paused())mode="暂停新单";
      else if(!IsTradeAllowed())mode="自动交易权限关闭";
      else if(OrdersTotal()>0)mode=OwnedCount()>0?"持仓实时管理":"已有其他订单，暂停新单";
      else if(!flat_reconciled)mode="等待平仓记录确认";
      else if(!APEntryCycleReady(closed_this_cycle,flat_reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes))mode="平仓后冷却，继续观察";
      else
      {
         mode="持续观察，条件满足才入场";
         for(int i=0;i<2;i++){TryEntry(i);if(OrdersTotal()>0)break;}
      }
   }
   Display();if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}
   working=false;
}

int OnInit()
{
   if(RiskPercent<=0||RiskPercent>1||MaximumLots<=0||MaximumLots>0.01||CooldownMinutes<0||MaximumHoldMinutes<0||RoundTripFeePerLotUSD<0||SlippagePoints<0||
      EntryWindowSeconds<1||EntryWindowSeconds>180||MaxSpreadFraction<=0||MaxSpreadFraction>0.25||EntryDriftATR<=0||EntryDriftATR>0.5)
      return INIT_PARAMETERS_INCORRECT;
   FolderCreate("DemoAutopilot");
   if(!GlobalVariableCheck(K("owner"))&&!GlobalVariableTemp(K("owner")))return INIT_FAILED;
   have_owner=GlobalVariableCheck(OwnerMarker())&&GlobalVariableGet(OwnerMarker())==1&&GlobalVariableGet(K("owner"))==1;
   if(!have_owner)
   {
      have_owner=GlobalVariableSetOnCondition(K("owner"),1,0);
      if(have_owner)
      {
         if(!GlobalVariableCheck(OwnerMarker())&&!GlobalVariableTemp(OwnerMarker()))
         {GlobalVariableSet(K("owner"),0);have_owner=false;return INIT_FAILED;}
         GlobalVariableSet(OwnerMarker(),1);
      }
   }
   if(!have_owner){Print("DemoAutopilot duplicate instance rejected.");return INIT_FAILED;}
   if(!GlobalVariableCheck(K("pause")))GlobalVariableSet(K("pause"),0);
   if(!GlobalVariableCheck(K("halt")))GlobalVariableSet(K("halt"),0);
   if(!GlobalVariableCheck(K("flatten")))GlobalVariableSet(K("flatten"),0);
   for(int i=0;i<2;i++){SymbolSelect(symbols[i],true);attempted[i]=(datetime)GlobalVariableGet(K("bar_"+symbols[i]));}
   RestoreChecks();
   if(!EventSetTimer(1))return INIT_FAILED;
   Event("START","",0,"v0.5 execution fixes; unchanged M5 entry; demo login locked; risk="+DoubleToString(RiskPercent,2)+"%; auto_entries="+(AutoEntries?"true":"false"));
   Cycle();return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   EventKillTimer();
   if(Owner())
   {
      Event("STOP","",0,"deinit_reason="+IntegerToString(reason));
      GlobalVariableSetOnCondition(K("owner"),0,1);GlobalVariableDel(OwnerMarker());
   }
   ObjectsDeleteAll(0,PREFIX);ChartRedraw();
}
void OnTick(){Cycle();}
void OnTimer(){Cycle();}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
{
   if(id!=CHARTEVENT_OBJECT_CLICK||!Identity()||!Owner())return;
   if(sparam==PREFIX+"pause")
   {
      // Operational faults are not cleared by the ordinary resume button.
      if(GlobalVariableGet(K("halt"))>0){mode="异常仍在，请先检查交易记录";return;}
      GlobalVariableSet(K("pause"),GlobalVariableGet(K("pause"))>0?0:1);
      Event("PAUSE_TOGGLE","",0,GlobalVariableGet(K("pause"))>0?"paused":"resumed");
   }
   if(sparam==PREFIX+"flatten")
   {GlobalVariableSet(K("pause"),1);GlobalVariableSet(K("flatten"),1);Event("USER_FLATTEN","",0,"close only this program's demo orders and remain paused");}
   ObjectSetInteger(0,sparam,OBJPROP_STATE,false);GlobalVariablesFlush();Cycle();
}
