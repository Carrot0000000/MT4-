param(
 [string]$ExpectedExe='C:\Program Files (x86)\FP Markets MT4 Terminal\terminal.exe',
 [string]$ExpectedTitle='176318407: MetaQuotes-Demo'
)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public static class MtWizardCapture {
 [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h,IntPtr dc,uint flags);
}
'@
$taskProcess=Get-Process terminal | Where-Object Path -eq $ExpectedExe | Select-Object -First 1
if($taskProcess.MainWindowTitle -notmatch $ExpectedTitle){throw 'Wrong active account'}
$cond=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$taskProcess.Id)
$items=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$cond)
$wizard=$items | Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Window -and $_.Current.Name -eq '开新模拟帐号'} | Select-Object -First 1
if(-not $wizard){throw 'Wizard missing'}
$grid=$wizard.FindFirst([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::DataGrid))
if(-not $grid){throw 'Not server selection; avoid capturing personal details'}
$rect=$wizard.Current.BoundingRectangle
$bitmap=[Drawing.Bitmap]::new([int]$rect.Width,[int]$rect.Height)
$graphics=[Drawing.Graphics]::FromImage($bitmap)
$hdc=$graphics.GetHdc()
try{$ok=[MtWizardCapture]::PrintWindow([IntPtr]$wizard.Current.NativeWindowHandle,$hdc,2)}finally{$graphics.ReleaseHdc($hdc)}
$bitmap.Save('C:\Users\96259\AppData\Local\Temp\codex-mt4-account-wizard.png',[Drawing.Imaging.ImageFormat]::Png)
$graphics.Dispose()
$bitmap.Dispose()
[pscustomobject]@{captured=$ok;bounds=$rect.ToString()}
