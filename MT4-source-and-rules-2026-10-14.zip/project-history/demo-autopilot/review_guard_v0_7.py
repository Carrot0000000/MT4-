"""Ensure v0.7 changes research/diagnostics while preserving broker execution."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def body(source,name):
    m=re.search(r'(?m)^(?:bool|int|double|string|void) '+re.escape(name)+r'\(',source)
    start=source.index('{',m.end());depth=0
    for i in range(start,len(source)):
        depth+=(source[i]=='{')-(source[i]=='}')
        if depth==0:return source[m.start():i+1]
    raise ValueError(name)
checks=[]
old=(ROOT/'backup-v0.6'/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
new=(ROOT/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
names=['Identity','OwnerMarker','Owner','MutationAllowed','ReadSpec','IsOwnedSelected','OwnedCount','ClosedJournalSelected',
    'SyncClosed','ReconcileFlat','EntryGate','SafeClose','SafeTighten','ObserveProtectionSelected','Manage','Direction','RecentStructure',
    'RequestHistory','EntryJournal','TryEntry','OnChartEvent','OnDeinit']
for name in names:
    a,b=body(old,name),body(new,name)
    if name=='TryEntry':a=a.replace('DemoAutopilot-v0.6','DemoAutopilot-v0.7')
    checks.append({'function':name,'passed':a==b})
for filename in ['AutopilotCore.mqh','ForwardCore.mqh']:
    checks.append({'function':filename+' unchanged pure execution calculations','passed':
        (ROOT/'backup-v0.6'/filename).read_text(encoding='utf-8-sig')==(ROOT/filename).read_text(encoding='utf-8-sig')})
for filename in ['PortfolioLab.mqh','ResearchStats.mqh','SnapshotWriter.mqh']:
    source=(ROOT/filename).read_text(encoding='utf-8-sig')
    checks.append({'function':filename+' no trading API','passed':re.search(r'\b(?:OrderSend|OrderClose|OrderModify)\s*\(',source) is None})
lab=(ROOT/'PortfolioLab.mqh').read_text(encoding='utf-8-sig')
checks.append({'function':'portfolio hard risk admission guard','passed':'next.r>remaining+1e-7' in lab and 'PLFreeBudget(cash,equity,RiskPercent,reserved)' in lab})
checks.append({'function':'portfolio data isolated from directional experiment','passed':'dual-v07-campaign.csv' in lab and 'DUAL07.R1' in lab})
result={'all_passed':all(c['passed'] for c in checks),'checks':checks,'real_order_maximum':1,'virtual_portfolio_maximum':2,'profitability_validated':False}
(ROOT/'guard-review-v0.7.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checked':len(checks),'all_passed':result['all_passed']}))
if not result['all_passed']:raise SystemExit('Broker isolation check failed')
