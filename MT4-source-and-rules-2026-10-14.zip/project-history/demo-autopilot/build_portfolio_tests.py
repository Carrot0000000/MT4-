"""Exercise the exact production admission function with mocked quote/plan/storage."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
source=(ROOT/'PortfolioLab.mqh').read_text(encoding='utf-8-sig')
m=re.search(r'(?m)^bool PLTry\(',source);start=source.index('{',m.end());depth=0
for i in range(start,len(source)):
    depth+=(source[i]=='{')-(source[i]=='}')
    if depth==0:
        code=source[m.start():i+1];break
code=code.replace('PLTry(','FixtureAdmission(').replace('ReadSpec(','FixtureQuotes(').replace('PLPlan(','FixturePlan(').replace('MarketInfo(','FixtureMargin(').replace('PLSave(','FixtureSave(')
head=r'''
bool fixture_quotes=true,fixture_save=true;double fixture_risk=1.3,fixture_margin=100;int fixture_writes=0;
bool FixtureQuotes(const int index,Spec &s){return fixture_quotes;}
bool FixturePlan(const int model,const int index,const Spec &s,FLBook &p,const double remaining)
{p.r=fixture_risk;p.lots=.01;p.active=true;p.index=index;return true;}
double FixtureMargin(const string symbol,const int type){return fixture_margin;}
bool FixtureSave(const int slot,FLBook &p,const string action,const double net=0,const double stress=0,const double exit=0,const string why="")
{fixture_writes++;return fixture_save;}
'''
tail=r'''
void RunPortfolioAdmissionTests()
{
   for(int i=0;i<3;i++)FLInit(pl_books[i],500);
   fixture_quotes=true;fixture_save=true;fixture_margin=100;fixture_writes=0;fixture_risk=1.3;
   FC(!FixtureAdmission(1,1,500,500,3.8,0)&&fixture_writes==0,"production admission rejects sum risk beyond one percent");
   FC(FixtureAdmission(1,1,500,500,3.7,0)&&fixture_writes==1,"production admission accepts exact remaining risk");
   FC(!FixtureAdmission(1,1,500,490,3.7,0),"production admission checks equity not cash alone");
   fixture_quotes=false;FC(!FixtureAdmission(0,0,500,500,0,0),"stale quote blocks portfolio admission");fixture_quotes=true;
   fixture_margin=100000;FC(!FixtureAdmission(0,0,500,500,0,0),"aggregate virtual margin blocks excess use");fixture_margin=100;
   fixture_save=false;FC(!FixtureAdmission(0,0,500,500,0,0),"unrecorded admission not committed");fixture_save=true;
   FC(!FixtureAdmission(0,0,500,500,5,0),"full existing risk budget cannot be reused");
}
'''
(ROOT/'PortfolioAdmissionTests.mqh').write_text(head+code+tail,encoding='utf-8-sig')
print('Generated actual admission regression cases; storage and quotes are mocked.')
