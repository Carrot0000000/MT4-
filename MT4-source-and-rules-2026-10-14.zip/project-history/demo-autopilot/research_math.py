"""Descriptive posterior and fixed-analysis, calendar-aligned sensitivity checks.

Only the native fixed mixture has a time-uniform interpretation, and that targets
bounded utility scores under a conditional-null assumption, not raw profitability.
"""
from __future__ import annotations
import argparse,csv,json,math
from pathlib import Path
import numpy as np

def beta_cdf_integer(x: float,a: int,b: int)->float:
    if a<1 or b<1:raise ValueError('positive integer parameters required')
    if x<=0:return 0.0
    if x>=1:return 1.0
    n=a+b-1
    terms=[math.lgamma(n+1)-math.lgamma(k+1)-math.lgamma(n-k+1)+k*math.log(x)+(n-k)*math.log1p(-x) for k in range(a,n+1)]
    top=max(terms)
    return min(1.0,math.exp(top)*sum(math.exp(t-top) for t in terms))

def beta_quantile(q:float,a:int,b:int)->float:
    if not 0<=q<=1:raise ValueError('quantile outside [0,1]')
    lo,hi=0.0,1.0
    for _ in range(70):
        mid=(lo+hi)/2
        if beta_cdf_integer(mid,a,b)<q:lo=mid
        else:hi=mid
    return (lo+hi)/2

def posterior(wins:int,n:int)->dict:
    if n<0 or not 0<=wins<=n:raise ValueError('invalid win counts')
    a,b=wins+1,n-wins+1
    return {'alpha':a,'beta':b,'mean':a/(a+b),'credible_interval_95':[beta_quantile(.025,a,b),beta_quantile(.975,a,b)],
        'assumption':'stationary independent Bernoulli wins with Beta(1,1) prior; not empirically verified',
        'meaning':'win-frequency parameter only, not chance of profit on the next trade or expected dollar return'}

def win_confidence_sequence(wins:int,n:int,threshold:float=100)->dict:
    if n<0 or not 0<=wins<=n or threshold<=1:raise ValueError('invalid confidence sequence inputs')
    norm=math.lgamma(wins+1)+math.lgamma(n-wins+1)-math.lgamma(n+2)
    def log_m(p):
        if p<=0:return math.inf if wins else norm
        if p>=1:return math.inf if n>wins else norm
        return norm-wins*math.log(p)-(n-wins)*math.log1p(-p)
    lower,upper=0.,1.
    if n:
        center=wins/n;boundary=math.log(threshold)
        if wins:
            lo,hi=0.,center
            for _ in range(70):
                mid=(lo+hi)/2
                if log_m(mid)>boundary:lo=mid
                else:hi=mid
            lower=(lo+hi)/2
        if wins<n:
            lo,hi=center,1.
            for _ in range(70):
                mid=(lo+hi)/2
                if log_m(mid)>boundary:hi=mid
                else:lo=mid
            upper=(lo+hi)/2
    return {'interval':[lower,upper],'per_model_alpha':1/threshold,
        'assumption':'constant conditional Bernoulli win probability, not verified',
        'family_note':'separate descriptive diagnostic from bounded-profit-score tests; no combined 5% claim',
        'raw_profit_test':False}

def prequential_scores(forecasts:list[tuple[float,bool]])->dict:
    if not forecasts:return {'count':0,'brier':None,'log_loss':None,'calibration_proven':False}
    if any(not 0<p<1 for p,y in forecasts):raise ValueError('probabilities must be in (0,1)')
    brier=sum((p-int(y))**2 for p,y in forecasts)/len(forecasts)
    loss=sum(-math.log(p if y else 1-p) for p,y in forecasts)/len(forecasts)
    return {'count':len(forecasts),'brier':brier,'brier_reference_50_percent':.25,
        'log_loss':loss,'log_loss_reference_50_percent':math.log(2),
        'forecast_rule':'Beta(1,1) mean recorded at OPEN, before that trade outcome',
        'calibration_proven':False,'note':'proper scores assess probabilistic performance; small sample and nonstationarity preclude a reliability claim'}

def bounded_score(r:float)->float:return r/(1+abs(r))
def log_mixture(logs)->float:
    top=max(logs)
    return top+math.log(sum(math.exp(x-top) for x in logs)/len(logs))
def evidence_from_returns(net_rs)->dict:
    logs=[0.,0.,0.]
    for r in net_rs:
        z=bounded_score(r)
        for i,lam in enumerate((.1,.25,.5)):logs[i]+=math.log1p(lam*z)
    log_e=log_mixture(logs)
    return {'log_e':log_e,'e':math.exp(log_e) if log_e<690 else None,'lambdas':[.1,.25,.5],
        'null':'conditional mean of R/(1+abs(R)) <= 0 at every observation',
        'raw_profit_mean_test':False,'strategy_superiority_test':False,'family_threshold':60}

def read_rows(path:Path)->list[dict]:
    with path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    if any(None in r or any(v is None for v in r.values()) for r in rows):raise ValueError('incomplete CSV write or damaged row')
    return rows

def moving_block_intervals(calendar_rows:list[dict],seed:int=20261012,repetitions:int=2000)->dict:
    # Preserve the first sample at a boundary; a restart must not select a more favorable mark.
    unique={}
    for row in calendar_rows:unique.setdefault(int(row['bar_server']),row)
    rows=sorted(unique.values(),key=lambda r:int(r['bar_server']))
    pairs=[]
    for left,right in zip(rows,rows[1:]):
        if left['complete']!='1' or right['complete']!='1' or int(right['bar_server'])-int(left['bar_server'])!=300:continue
        pairs.append((int(right['bar_server']),np.array([float(right[k])-float(left[k]) for k in
            ('h1_equity','m15_equity','agree_equity','h1_stress_equity','m15_stress_equity','agree_stress_equity')])))
    n=len(pairs)
    result={'eligible_calendar_increments':n,'minimum_increments':60,'intervals_available':False,
        'assumption':'approximately stationary weakly dependent increments; fixed analysis; bootstrap is approximate and not anytime-valid',
        'selection_rule':'all contiguous windows, first mark per boundary, no crossing data gaps; do not choose the favorable block length',
        'automatic_promotion':False}
    if n<60:return result
    values=np.array([p[1] for p in pairs]);stamps=np.array([p[0] for p in pairs])
    diffs=np.column_stack((values[:,1]-values[:,0],values[:,2]-values[:,0],values[:,4]-values[:,3],values[:,5]-values[:,3]))
    sensitivity=[]
    for block in (3,6):
        windows=[diffs[i:i+block] for i in range(n-block+1) if stamps[i+block-1]-stamps[i]==300*(block-1)]
        if len(windows)<20:continue
        pool=np.array(windows);rng=np.random.default_rng(seed+block);count=math.ceil(n/block)
        choices=rng.integers(0,len(pool),size=(repetitions,count))
        sampled=pool[choices].reshape(repetitions,count*block,4)[:,:n,:].mean(axis=1)
        sensitivity.append({'block_bars':block,'usable_windows':len(pool),'repetitions':repetitions,
            'paired_mean_delta_usd_per_5m':diffs.mean(axis=0).tolist(),
            'bootstrap_percentile_97_5_intervals':np.quantile(sampled,[.0125,.9875],axis=0).T.tolist(),
            'columns':['M15 minus H1','AGREE minus H1','M15 stressed minus H1 stressed','AGREE stressed minus H1 stressed']})
    result.update({'intervals_available':bool(sensitivity),'block_length_sensitivity':sensitivity})
    return result

def analyze(directory:Path)->dict:
    meta=directory/'lab-v06-campaign.csv'
    if not meta.exists():return {'status':'campaign_not_started','automatic_promotion':False}
    with meta.open(encoding='utf-8-sig',newline='') as f:record=next(csv.reader(f))
    if len(record)!=4 or record[0]!='FWD06.R1':raise ValueError('campaign identity mismatch')
    campaign=record[2];ledger=read_rows(directory/f'lab-v06-{campaign}-ledger.csv')
    latest={};returns={i:[] for i in range(3)};previous_seq={i:0 for i in range(3)}
    pending={};scoring={i:[] for i in range(3)}
    for row in ledger:
        model=int(row['model']);seq=int(row['seq'])
        if row['campaign']!=campaign or row['parameter_signature']!=record[1] or seq!=previous_seq[model]+1:raise ValueError('mixed campaign or sequence gap')
        previous_seq[model]=seq;latest[model]=row
        if row['action']=='OPEN':
            if model in pending:raise ValueError('overlapping virtual positions')
            pending[model]=(int(row['wins'])+1)/(int(row['closed_count'])+2)
        if row['action']=='CLOSE':
            returns[model].append(float(row['event_net'])/float(row['reserved_r']))
            if model not in pending:raise ValueError('close without earlier causal forecast')
            scoring[model].append((pending.pop(model),float(row['event_net'])>0))
    models=[]
    for model,row in sorted(latest.items()):
        evidence=evidence_from_returns(returns[model]);n=int(row['closed_count']);wins=int(row['wins'])
        if n!=len(returns[model]):raise ValueError('closed count disagrees with ledger')
        if abs(evidence['log_e']-log_mixture([float(row[k]) for k in ('log_e_010','log_e_025','log_e_050')]))>1e-8:raise ValueError('native evidence disagrees with independent calculation')
        models.append({'model':('H1_BASE','M15_FAST','H1_M15_AGREE')[model],'closed_count':n,'wins':wins,
            'net_usd':float(row['cash'])-float(row['starting_cash']),'stress_net_usd':float(row['stress_sum']),
            'bayesian_descriptive_posterior':posterior(wins,n),'sequential_bounded_score_evidence':evidence})
        models[-1]['win_rate_confidence_sequence']=win_confidence_sequence(wins,n)
        models[-1]['prequential_probability_scores']=prequential_scores(scoring[model])
    calendar_file=directory/f'lab-v06-{campaign}-calendar.csv'
    calendar=moving_block_intervals(read_rows(calendar_file)) if calendar_file.exists() else moving_block_intervals([])
    return {'status':'prospective_research','campaign':campaign,'automatic_promotion':False,
        'actual_order_operations':0,'models':models,'calendar_comparison':calendar}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=analyze(args.directory)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'automatic_promotion':False,'models':len(result.get('models',[]))}))
