"""Native no-order tests for aligned cost scenarios and measurement hooks."""
from build_upgrade_v0_11 import ROOT,LIVE,STAGE,BACKUP,body
source=(STAGE/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(BACKUP/'Scripts/Codex/UpgradeReviewV010.mq4').read_text(encoding='utf-8-sig')
test=test.replace('version "2.000"','version "2.100"').replace('v010-','v011-')
for name in ['SafeClose','Manage','Cycle','CheckOutcome']:
    test=test.replace(body(test,name),body(source,name))
test=test.replace(body(test,'TestProductionTryEntry'),body(source,'TryEntry').replace('void TryEntry(','void TestProductionTryEntry(',1))
test=test.replace('void LabCycle(){}','void LabCycle(){}\nvoid AlignedCycle(){}')
test=test.replace('bool mock_connected=true,mock_silver=false;','bool mock_connected=true,mock_silver=false,mock_aligned_signal=false;')
test=test.replace('double FakeAccountBalance(){return 10000;}', 'double mock_balance=10000;\ndouble FakeAccountBalance(){return mock_balance;}')
test=test.replace('double FakeiClose(const string symbol,const int frame,const int shift){return 100;}',
    'double FakeiClose(const string symbol,const int frame,const int shift){return mock_aligned_signal&&frame==PERIOD_M5&&shift==2?99.9:100;}')
test=test.replace('double FakeiOpen(const string symbol,const int frame,const int shift){return 100;}',
    'double FakeiOpen(const string symbol,const int frame,const int shift){return mock_aligned_signal?99.8:100;}')
test=test.replace('double FakeiMA(const string symbol,const int frame,const int period,const int shift,const int method,const int price,const int bar){return 99;}',
    'double FakeiMA(const string symbol,const int frame,const int period,const int shift,const int method,const int price,const int bar){return !mock_aligned_signal?99:frame==PERIOD_M5?99.95:frame==PERIOD_M15?(bar==1?99.5:99.4):99;}')
test=test.replace('double FakeMarketInfo(const string symbol,const int item){return item==MODE_TRADEALLOWED?1:0;}',
    'double FakeMarketInfo(const string symbol,const int item){return item==MODE_TRADEALLOWED?1:(mock_aligned_signal&&item==MODE_MARGINREQUIRED?1000:0);}')
test=test.replace('void FakeResetLastError()', 'double FakeOrderClosePrice(){return mock_side==OP_BUY?mock_bid:mock_ask;}\nvoid FakeResetLastError()',1)
test=test.replace('#define OrderClose FakeOrderClose','#define OrderClose FakeOrderClose\n#define OrderClosePrice FakeOrderClosePrice\n#include <Codex/ExecutionQuality.mqh>')
test=test.replace('mock_side=OP_BUY;vars=0;', 'mock_balance=10000;mock_aligned_signal=false;mock_side=OP_BUY;vars=0;',1)
new=r'''
void ResetAligned(const bool fresh=true)
{
   af_campaign=0;af_started=0;af_initial_cash=0;af_last_cycle=0;af_last_status=0;af_checkpoint=0;af_calendar=0;
   af_initialized=false;af_fault=false;af_signature="";af_error="";
   for(int i=0;i<6;i++){FLInit(af_books[i],10000);af_reasons[i]="test";}
   if(fresh)af_root="DemoAutopilot\\test-v011-aligned-"+IntegerToString(GetTickCount())+"-";
}
void RunAlignedTests()
{
   ResetScenario();RoundTripFeePerLotUSD=7;
   ECheck(Near(AFBudget(10000),5)&&Near(AFBudget(11000),5),"aligned risk never compounds above authorized five dollars");
   ECheck(Near(AFBudget(450),4.5)&&AFBudget(0)==0,"low virtual cash reduces aligned risk");
   Spec a,b;ReadSpec(0,a);b=a;AFStressSpec(0,a);AFStressSpec(3,b);
   ECheck(Near(b.spread,2*a.spread)&&Near((a.bid+a.ask)/2,(b.bid+b.ask)/2)&&Near(b.slip,2*a.slip),"stress widens executable quotes at same midpoint and doubles slip");
   ECheck(Near(AFFee(0),7)&&Near(AFFee(3),14),"stress doubles fee before lot admission");
   ECheck(AFName(0)!=AFName(3)&&FLDirection(4%3,-1,1)==1,"direction and cost dimensions kept distinct");
   ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_bid=100;mock_ask=100.02;
   ResetAligned();ECheck(AFInitialize()&&!af_fault&&af_books[5].start==10000,"new campaign starts six cash books from broker balance and capped risk reference");
   mock_now=2420;
   for(int i=0;i<6;i++)
   {
      Spec s;AFReadSpec(0,i,s);FLBook p=af_books[i];
      ECheck(AFPlan(i,0,s,p)&&p.r<=5.0000001&&p.active,"all six future plans honor risk cap");
      ECheck(AFSave(i,p,"OPEN"),"six-arm native ledger persists planned virtual fills");af_books[i]=p;
      ECheck(!AFPlan(i,0,s,p),"same model and symbol never reuse the same consumed bar");
   }
   double fill=af_books[0].fill;AFCalendarSnapshot();ulong calendar_size=0;
   int cf=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);if(cf!=INVALID_HANDLE){calendar_size=FileSize(cf);FileClose(cf);}
   ResetAligned(false);ECheck(AFInitialize()&&!af_fault&&af_books[0].active&&Near(af_books[0].fill,fill)&&af_books[5].active,
      "six-arm native restore retains active fills and protocol");
   AFCalendarSnapshot();cf=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   ulong after_size=0;if(cf!=INVALID_HANDLE){after_size=FileSize(cf);FileClose(cf);}
   ECheck(calendar_size>0&&after_size==calendar_size,"restart does not duplicate the same calendar bar");
   // In a constructed wider-spread market, base cost fits while stressed cost does not.
   FLBook p;FLInit(p,10000);Spec wide;ReadSpec(0,wide);wide.bid=100;wide.ask=100.60;wide.spread=.60;
   double old_drift=EntryDriftATR;EntryDriftATR=.5;
   ECheck(AFPlan(0,0,wide,p)&&p.r<=5,"base execution costs can admit constructed wide-spread signal");
   FLInit(p,10000);AFStressSpec(3,wide);
   ECheck(!AFPlan(3,0,wide,p)&&!p.active,"doubled costs reject before opening instead of only subtracting profit afterward");
   EntryDriftATR=old_drift;
   mock_now=2421;mock_bid=101;mock_ask=101.02;double initial=af_books[0].sl;AFManageBook(0);
   ECheck(af_books[0].active&&af_books[0].sl>initial,"new virtual baseline uses current early profit protection");
   mock_now=2422;mock_bid=95;mock_ask=95.02;AFManageBook(0);
   ECheck(!af_books[0].active&&af_books[0].n==1&&af_books[0].cash<9996,"sampled gap never invents a fill at protected stop");
   AFManageBook(0);ECheck(af_books[0].n==1,"closed virtual position cannot be counted twice");
   AFShutdown();double saved_cash=af_books[0].cash;ResetAligned(false);
   ECheck(AFInitialize()&&!af_fault&&Near(af_books[0].cash,saved_cash)&&af_books[0].n==1,"realized net survives native ledger replay");
   mock_balance=20000;ResetAligned(false);
   ECheck(AFInitialize()&&Near(af_initial_cash,10000)&&Near(af_books[5].start,10000),"broker balance change cannot rebase an existing campaign");
   mock_balance=10000;
   RoundTripFeePerLotUSD=8;af_initialized=false;
   ECheck(!AFInitialize()&&af_fault,"changed assumptions cannot reuse prior evidence");
   ResetScenario();RoundTripFeePerLotUSD=7;ResetAligned();mock_identity=false;
   ECheck(!AFInitialize()&&!af_initialized,"wrong account cannot create aligned campaign");
   mock_identity=true;mock_owner=false;ECheck(!AFInitialize(),"duplicate owner cannot create aligned campaign");
   ResetScenario();RoundTripFeePerLotUSD=7;ResetAligned();
   af_root="DemoAutopilot\\test-v011-isolation-"+IntegerToString(GetTickCount())+"-";
   mock_aligned_signal=true;mock_now=2420;mock_bid=100;mock_ask=100.02;TestAlignedCycle();
   mock_now=2720;TestAlignedCycle();
   ECheck(mock_sends==0&&mock_closes==0&&mock_tightens==0,"complete new comparison cycle has zero broker order calls");
   // The new study must also decline new virtual entries while program inputs are paused.
   mock_now=3000;for(int i=0;i<6;i++)af_books[i].active=false;
   GlobalVariableSet(K("pause"),1);TestAlignedCycle();bool any=false;
   for(int i=0;i<6;i++)if(af_books[i].active)any=true;
   ECheck(!any,"paused entries also pause new virtual entries");
}
void RunQualityTests()
{
   ECheck(Near(EQAdversePrice(true,1,100,100.2),.2)&&Near(EQAdversePrice(true,-1,100,99.8),.2),"adverse entry slip sign is correct for buy and sell");
   ECheck(Near(EQAdversePrice(false,1,100,99.8),.2)&&Near(EQAdversePrice(false,-1,100,100.2),.2),"adverse exit slip sign is correct for buy and sell");
   ECheck(Near(EQAdversePrice(true,1,100,99.8),-.2)&&Near(EQAdversePrice(false,-1,100,99.8),-.2),"favorable fills are retained as negative adverse slip");
   ECheck(EQAdversePrice(true,0,100,100)==EMPTY_VALUE&&EQAdversePrice(true,1,100,0)==EMPTY_VALUE,"unknown fill is not recorded as zero slippage");
   uint before=4294967290,after=5;ECheck((uint)(after-before)==11,"elapsed milliseconds survive unsigned counter rollover");
   ResetScenario();eq_calls=0;eq_failures=0;eq_fills=0;eq_ms_sum=0;eq_ms_max=0;eq_adverse_sum=0;eq_adverse_max=0;
   eq_path="DemoAutopilot\\test-v011-quality-"+IntegerToString(GetTickCount())+".csv";
   EQRecord(true,"XAUUSD",123,1,.01,100,100.2,true,0,250,.4,1);
   EQRecord(false,"XAUUSD",123,1,.01,100,0,false,138,400,.4,1);
   ECheck(eq_calls==2&&eq_failures==1&&eq_fills==1&&Near(eq_ms_sum,650)&&Near(eq_adverse_sum,.2),"native quality accounting excludes failed fill while including call duration");
   int f=FileOpen(eq_path,FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);int rows=0,bad=0;
   if(f!=INVALID_HANDLE){while(!FileIsEnding(f)){int n=0;while(!FileIsEnding(f)){string cell=FileReadString(f);n++;if(FileIsLineEnding(f))break;}if(n>1){rows++;if(n!=17)bad++;}}FileClose(f);}
   ECheck(rows==3&&bad==0,"native measurement CSV has header and two complete records");
   mock_identity=false;EQRecord(true,"XAUUSD",123,1,.01,100,100.2,true,0,250,.4,1);
   ECheck(eq_calls==2,"wrong account cannot contribute execution measurements");
   f=FileOpen("DemoAutopilot\\v011-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"new_research_model_count\":6}");FileClose(f);}
}
'''
test=test.replace('#undef OrderModify','#define AlignedCycle TestAlignedCycle\n#include <Codex/AlignedForward.mqh>\n#undef AlignedCycle\n'+new+'\n#undef OrderClosePrice\n#undef OrderModify',1)
test=test.replace('RunTimingTests();Print(', 'RunTimingTests();RunAlignedTests();RunQualityTests();Print(')
test=test.replace('void OnStart(){', 'void OnStart(){eq_path="DemoAutopilot\\\\test-v011-main-quality-"+IntegerToString(GetTickCount())+".csv";',1)
(LIVE/'Scripts/Codex/UpgradeReviewV011.mq4').write_text(test,encoding='utf-8-sig')
print('Generated current production-function regression plus six-book and execution-quality tests.')
