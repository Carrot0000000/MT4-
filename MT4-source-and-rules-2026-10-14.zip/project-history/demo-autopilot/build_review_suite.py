"""Generate a native MQL4 test using production execution functions and fake trade APIs.

The mocks live only in the read-only review script, never in the installed EA.
After undefining the mocks, the audit reads actual demo history without mutations.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')

def body(name):
    m = re.search(r'(?m)^(?:bool|int|double|string|void) '+name+r'\(', source)
    start = source.index('{', m.end())
    depth = 0
    for i in range(start, len(source)):
        depth += (source[i] == '{') - (source[i] == '}')
        if depth == 0:
            return source[m.start():i+1]
    raise ValueError(name)

core_test = (ROOT / 'AutopilotSelfTest.mq4').read_text(encoding='utf-8-sig')
core_test = re.sub(r'^#(?:property|include).*\n', '', core_test, flags=re.M)
core_test = core_test.replace('void OnStart()', 'void RunCoreTests()')

mock_names = '''GlobalVariableGet GlobalVariableSet GlobalVariableCheck GlobalVariablesFlush
OrderSelect OrdersTotal OrderCloseTime OrderTicket OrderSymbol OrderType OrderLots OrderOpenTime
OrderOpenPrice OrderStopLoss OrderTakeProfit OrderCommission OrderSwap TimeCurrent TimeLocal
OrderClose RefreshRates ResetLastError GetLastError IsConnected IsTradeAllowed'''.split()

stub = r'''
struct Spec { double tick,value,point,minimum,step,maximum,spread,bid,ask,slip; int digits; };
string key="mock.",symbols[2]={"XAUUSD","XAGUSD"},mode="";
bool have_owner=true,working=false,closed_this_cycle=false,quotes_fresh[2]={false,false};
bool AutoEntries=true;int CooldownMinutes=5,MaximumHoldMinutes=20,SlippagePoints=20;
datetime last_status=0,last_sync=0,last_history_request=0,last_metrics_flush=0;
double current_spreads[2]={0,0},spread_minimum_risks[2]={0,0},RoundTripFeePerLotUSD=0,MaxSpreadFraction=.2;
string mock_names[200];double values[200];int vars=0;
bool mock_live=false,mock_visible=true,mock_mutation=true,mock_identity=true,mock_owner=true,mock_fresh=true;
bool mock_delay_history=false,mock_close_on_error=false;
int mock_error=0,mock_last_error=0,mock_closes=0,mock_entries=0,mock_tightens=0;
datetime mock_now=2200,mock_open=1000,mock_closed=0;
double mock_bid=102,mock_ask=102.02,mock_sl=95,mock_tp=110;
string K(const string field,const int ticket=0){return key+field+(ticket>0?"."+IntegerToString(ticket):"");}
int V(const string name){for(int i=0;i<vars;i++)if(mock_names[i]==name)return i;return -1;}
double FakeGlobalVariableGet(const string name){int i=V(name);return i>=0?values[i]:0;}
datetime FakeGlobalVariableSet(const string name,const double value)
{int i=V(name);if(i<0){i=vars++;mock_names[i]=name;}values[i]=value;return mock_now;}
bool FakeGlobalVariableCheck(const string name){return V(name)>=0;}
void FakeGlobalVariablesFlush(){}
bool Identity(){return mock_identity;}bool Owner(){return mock_owner;}
bool MutationAllowed(){return mock_identity&&mock_owner&&mock_mutation;}
bool Paused(){return FakeGlobalVariableGet(K("pause"))>0||FakeGlobalVariableGet(K("halt"))>0;}
int IndexOf(const string symbol){return symbol=="XAUUSD"?0:1;}
bool IsOwnedSelected(){return true;}
int OwnedCount(){return mock_live?1:0;}
bool FakeOrderSelect(const int value,const int select,const int pool=MODE_TRADES)
{return mock_live||(mock_visible&&mock_closed>0);}
int FakeOrdersTotal(){return mock_live?1:0;}
datetime FakeOrderCloseTime(){return mock_live?0:mock_closed;}
int FakeOrderTicket(){return 123;}
string FakeOrderSymbol(){return "XAUUSD";}
int FakeOrderType(){return OP_BUY;}
double FakeOrderLots(){return .01;}
datetime FakeOrderOpenTime(){return mock_open;}
double FakeOrderOpenPrice(){return 100;}
double FakeOrderStopLoss(){return mock_sl;}
double FakeOrderTakeProfit(){return mock_tp;}
double FakeOrderCommission(){return 0;}
double FakeOrderSwap(){return 0;}
datetime FakeTimeCurrent(){return mock_now;}
datetime FakeTimeLocal(){return mock_now;}
bool FakeRefreshRates(){return true;}
void FakeResetLastError(){mock_last_error=0;}
int FakeGetLastError(){return mock_last_error;}
bool FakeIsConnected(){return true;}bool FakeIsTradeAllowed(){return true;}
bool FakeOrderClose(const int ticket,const double lots,const double price,const int slippage,const color arrow)
{
   mock_closes++;mock_last_error=mock_error;
   if(mock_error==0||mock_close_on_error){mock_live=false;mock_closed=mock_now;mock_visible=!mock_delay_history;}
   return mock_error==0;
}
bool ReadSpec(const int index,Spec &s)
{s.tick=.01;s.value=1;s.point=.01;s.minimum=.01;s.step=.01;s.maximum=100;s.spread=.02;
 s.bid=mock_bid;s.ask=mock_ask;s.slip=.05;s.digits=2;return mock_fresh;}
void Event(const string action,const string symbol,const int ticket,const string details){}
void SyncClosed()
{
   if(!mock_live&&mock_visible&&mock_closed>FakeGlobalVariableGet(K("last_close")))
      FakeGlobalVariableSet(K("last_close"),(double)mock_closed);
}
bool SafeTighten(const int ticket,const double target){mock_tightens++;return true;}
void RequestHistory(){}void Display(){}void Status(){}
void LabCycle(){}
string PermissionMode(){return "mock permission unavailable";}
void TryEntry(const int index);
'''

test = r'''
void TryEntry(const int index){if(EntryGate())mock_entries++;}
void ResetScenario()
{
   vars=0;mock_live=true;mock_visible=true;mock_mutation=true;mock_identity=true;mock_owner=true;mock_fresh=true;
   mock_delay_history=false;mock_close_on_error=false;mock_error=0;mock_last_error=0;
   mock_closes=0;mock_entries=0;mock_tightens=0;mock_now=2200;mock_open=1000;mock_closed=0;
   mock_bid=102;mock_ask=102.02;mock_sl=95;mock_tp=110;working=false;closed_this_cycle=false;last_sync=0;last_status=0;
   last_history_request=0;last_metrics_flush=0;CooldownMinutes=5;MaximumHoldMinutes=20;AutoEntries=true;
   GlobalVariableSet(K("initial_R",123),6);GlobalVariableSet(K("peak",123),0);
}
int exec_passed=0,exec_failed=0;
void ECheck(const bool okay,const string label)
{if(okay)exec_passed++;else{exec_failed++;Print("Execution regression FAILED: ",label);}}
void RunExecutionTests()
{
   ResetScenario();Cycle();
   ECheck(mock_closes==1&&!mock_live&&mock_entries==0,"time exit plus eligible new signal does not reopen same cycle");
   ECheck(GlobalVariableGet(K("last_close"))==2200,"accepted close writes cooldown immediately");
   mock_now=2499;Cycle();ECheck(mock_entries==0,"one second before cooldown remains blocked");
   mock_now=2500;Cycle();ECheck(mock_entries>0,"new entries eligible at 300 seconds");

   ResetScenario();mock_delay_history=true;Cycle();
   mock_now=2600;Cycle();ECheck(mock_entries==0,"missing history blocks reopening beyond nominal cooldown");
   mock_visible=true;Cycle();ECheck(mock_entries==0,"confirmation cycle cannot reopen");
   Cycle();ECheck(mock_entries>0,"confirmed earlier close permits later cycle");

   ResetScenario();MaximumHoldMinutes=0;mock_open=2100;Manage();
   mock_live=false;mock_closed=2210;mock_now=2210;mock_visible=false;Cycle();
   ECheck(mock_entries==0,"server stop with delayed history blocks new signal");
   mock_visible=true;Cycle();ECheck(GlobalVariableGet(K("last_close"))==2210&&mock_entries==0,"server exit starts cooldown");

   ResetScenario();MaximumHoldMinutes=0;mock_bid=107;mock_ask=107.02;
   GlobalVariableSet(K("peak",123),10);mock_error=138;Cycle();
   ECheck(mock_closes==1&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,"requote retains giveback intent");
   mock_bid=108;mock_ask=108.02;mock_error=0;Cycle();
   ECheck(mock_closes==1,"retry not sent before backoff");
   mock_now++;Cycle();ECheck(mock_closes==2&&!mock_live&&mock_entries==0,"rebound cannot cancel pending exit");

   ResetScenario();mock_mutation=false;Manage();
   ECheck(mock_closes==0&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_TIME,"closed trade context still saves intent");
   mock_mutation=true;mock_fresh=false;Manage();ECheck(mock_closes==0,"stale quote blocks close request");
   mock_fresh=true;Manage();ECheck(mock_closes==1,"fresh quote completes saved request");

   ResetScenario();mock_identity=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"wrong account no mutations");
   ResetScenario();mock_owner=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"duplicate owner no mutations");
   ResetScenario();GlobalVariableSet(K("pause"),1);Cycle();
   ECheck(mock_closes==1&&mock_entries==0,"paused entries retain position management");
   ResetScenario();mock_error=128;mock_close_on_error=true;Cycle();
   ECheck(mock_closes==1&&mock_entries==0&&!mock_live,"ambiguous accepted close reconciles without duplicate send");
   ResetScenario();MaximumHoldMinutes=0;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==0,"first protection observation not mislabeled as outside edit");
   mock_sl=96;mock_tp=109;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==1&&mock_closes==0,"outside tightening and TP edit flagged without overriding user");

   int f=FileOpen("DemoAutopilot\\execution-regression.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
      ",\"actual_order_operations\":0,\"production_functions_under_mock_environment\":[\"SafeClose\",\"Manage\",\"ReconcileFlat\",\"EntryGate\",\"Cycle\"]}");FileClose(f);}
}
'''

audit = r'''
void RunAudit()
{
   if(!APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())||AccountCurrency()!="USD")
   {Print("Audit blocked: demo identity mismatch");return;}
   int f=FileOpen("DemoAutopilot\\audit-history.csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   if(f==INVALID_HANDLE)return;
   FileWrite(f,"ticket","symbol","side","lots","open_server","close_server","open_price","close_price","final_sl","final_tp",
      "profit","commission","swap","net","magic","comment","reserved_r","observed_peak_estimate");
   int exported=0;
   for(int i=0;i<OrdersHistoryTotal();i++)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)||OrderMagicNumber()!=2026101217||OrderCloseTime()==0)continue;
      int ticket=OrderTicket();
      FileWrite(f,ticket,OrderSymbol(),OrderType()==OP_BUY?1:-1,DoubleToString(OrderLots(),8),
         TimeToString(OrderOpenTime(),TIME_DATE|TIME_SECONDS),TimeToString(OrderCloseTime(),TIME_DATE|TIME_SECONDS),
         DoubleToString(OrderOpenPrice(),8),DoubleToString(OrderClosePrice(),8),DoubleToString(OrderStopLoss(),8),DoubleToString(OrderTakeProfit(),8),
         DoubleToString(OrderProfit(),4),DoubleToString(OrderCommission(),4),DoubleToString(OrderSwap(),4),
         DoubleToString(OrderProfit()+OrderCommission()+OrderSwap(),4),OrderMagicNumber(),OrderComment(),
         DoubleToString(GlobalVariableGet("AP02.176318407.initial_R."+IntegerToString(ticket)),4),
         DoubleToString(GlobalVariableGet("AP02.176318407.peak."+IntegerToString(ticket)),4));
      exported++;
   }
   FileFlush(f);FileClose(f);
   string names_audit[2]={"XAUUSD","XAGUSD"};ENUM_TIMEFRAMES frames[2]={PERIOD_M5,PERIOD_H1};
   for(int s=0;s<2;s++)for(int t=0;t<2;t++)
   {
      MqlRates rates[];int copied=CopyRates(names_audit[s],frames[t],1,2200,rates);
      int rfile=FileOpen("DemoAutopilot\\audit-"+names_audit[s]+"-"+IntegerToString((int)frames[t])+".csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
      if(rfile==INVALID_HANDLE)continue;
      FileWrite(rfile,"bar_open_server","open","high","low","close","tick_volume","spread_points");
      for(int k=0;k<copied;k++)FileWrite(rfile,TimeToString(rates[k].time,TIME_DATE|TIME_SECONDS),DoubleToString(rates[k].open,8),
         DoubleToString(rates[k].high,8),DoubleToString(rates[k].low,8),DoubleToString(rates[k].close,8),rates[k].tick_volume,rates[k].spread);
      FileFlush(rfile);FileClose(rfile);
   }
   int status_file=FileOpen("DemoAutopilot\\audit-summary.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(status_file!=INVALID_HANDLE){FileWriteString(status_file,"{\"expected_demo\":true,\"history_trades_exported\":"+IntegerToString(exported)+
      ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+",\"actual_order_operations\":0}");FileClose(status_file);}
}
void OnStart(){RunCoreTests();RunExecutionTests();RunAudit();}
'''

out = '#property strict\n#property version "1.700"\n#include "AutopilotCore.mqh"\n'+core_test+'\n'+stub
out += '\n'.join('#define '+name+' Fake'+name for name in mock_names)+'\n'
out += '\n\n'.join(body(n) for n in ['ReconcileFlat','EntryGate','SafeClose','ObserveProtectionSelected','Manage','Cycle'])+'\n'+test
out += '\n'.join('#undef '+name for name in mock_names)+'\n'+audit
(ROOT / 'AutopilotReviewSuite.mq4').write_text(out, encoding='utf-8-sig')
print('Generated actual-function execution tests and read-only audit suite.')
