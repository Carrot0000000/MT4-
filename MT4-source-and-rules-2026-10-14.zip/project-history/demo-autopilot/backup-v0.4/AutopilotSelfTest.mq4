#property strict
#property version "1.400"
#include <Codex/AutopilotCore.mqh>
int passed=0,failed=0;
void Check(const bool condition,const string label)
{ if(condition)passed++;else{failed++;Print("AP self-test FAILED: ",label);} }
bool Near(const double a,const double b){return MathAbs(a-b)<1e-7;}
void OnStart()
{
   Check(APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",false),"expected demo allowed");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_REAL,176318407,"MetaQuotes-Demo",false),"real blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_CONTEST,176318407,"MetaQuotes-Demo",false),"contest blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,1,"MetaQuotes-Demo",false),"other login blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"FPMarketsLtd-Live5",false),"other server blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",true),"tester isolated");
   Check(Near(APLots(2.5,19.16,.02,.01,1,.01,.01,100,0),0),"minimum not forced up");
   Check(Near(APLots(10,4.99,.02,.01,1,.01,.01,100,0),.01),"floor under budget");
   Check(Near(APLots(10,5,.02,0,1,.01,.01,100,0),0),"zero tick blocks");
   Check(Near(APLots(10,5,.02,.01,1,.01,.01,100,-1),0),"negative cost blocks");
   Check(Near(APPrice(4185.951,.01,2,false),4185.95),"buy stop outward");
   Check(Near(APPrice(4185.951,.01,2,true),4185.96),"sell stop outward");
   Check(Near(APStop(100,5,-1,.3,.01,2),101.3),"Bid pivot to Ask stop");
   Check(Near(APStop(100,5,1,.3,.01,2),99),"buy structure");
   Check(Near(APNet(1,4205.11,4200.12,1,0),-4.99),"spread not charged twice");
   for(int side=-1;side<=1;side+=2)
   {
      double level=APBreakEven(100,10,.5,.02,.01,2,side);
      Check(APNet(side,100,level-side*.02,10,.5)>=.1-1e-7,"economic BE fees and reserve");
   }
   Check(!APGiveback(1.49,1,1),"profit gate not reached");
   Check(!APGiveback(1.7,1.21,1),"not enough giveback");
   Check(APGiveback(1.7,1.2,1),"giveback exit");
   double silver_floor=APMinimumRiskForSpread(.03,.1,.02,.01,10,.01,0);
   Check(Near(silver_floor,3.2),"spread and slip minimum risk");
   Check(silver_floor>495.01*.005,"0.5 percent incompatible at this spread");
   Check(silver_floor<495.01*.01,"1 percent removes this necessary-condition conflict");
   Check(Near(APLots(495.01*.01,.45,.02,.01,10,.01,.01,.01,0),.01),"silver minimum fits new budget");
   Check(Near(APLots(495.01*.005,.45,.02,.01,10,.01,.01,.01,0),0),"same structure rejected at old budget");
   Check(APMinimumRiskForSpread(.03,0,.02,.01,10,.01,0)<0,"invalid spread fraction marked unknown");
   Check(APEntryWindow(1000,1060)&&!APEntryWindow(1000,1061)&&!APEntryWindow(1000,999),"entry window boundaries");
   Check(!APEntryWindow(0,30),"unknown bar never eligible");
   Check(APRecordChanged(0,0,1000,AP_TRIGGER),"first refusal recorded");
   Check(!APRecordChanged(1000,AP_TRIGGER,1000,AP_TRIGGER),"same refusal not flooded per tick");
   Check(APRecordChanged(1000,AP_TRIGGER,1000,AP_BUDGET),"changed refusal within bar recorded");
   Check(APRecordChanged(1000,AP_TRIGGER,1900,AP_TRIGGER),"same refusal on new bar recorded");
   Check(APCheckText(AP_BUDGET)!=""&&APCheckText(AP_QUOTE)!=APCheckText(AP_BUDGET),"quote and budget causes distinguished");
   Check(APBias(101,100)==1,"simple H1 long bias");
   Check(APBias(99,100)==-1,"simple H1 short bias");
   Check(APBias(100,100)==0,"flat H1 has no forced direction");
   Check(APBias(0,100)==0,"missing H1 price blocked");
   Check(APMomentum(1,100,100.8,100.5,100.4),"buy momentum without requiring high breakout");
   Check(APMomentum(-1,100,99.2,99.5,99.6),"sell momentum");
   Check(!APMomentum(-1,100,100.8,100.5,100.4),"counter-direction momentum rejected");
   Check(!APMomentum(1,100,100,99,99),"doji not forced into a trade");
   Check(Near(APRangeExtreme(99,98,97,1),97),"closed-bar low extreme");
   Check(Near(APRangeExtreme(101,102,103,-1),103),"closed-bar high extreme");
   Check(APRangeExtreme(0,98,97,1)==0,"missing stop structure blocked");
   Check(Near(APDriftLimit(.05,.01,.25),.02),"drift limit respects quote ticks");
   Check(Near(APDriftLimit(4,.01,.25),1),"drift limit uses ATR for larger ranges");
   Check(APDriftLimit(0,.01,.25)==0,"invalid ATR drift blocked");
   Check(APEntryWindow(1000,1120,120)&&!APEntryWindow(1000,1121,120),"M5 two-minute window boundary");
   Check(!APEntryWindow(1000,1300,120),"expired M5 signal blocked");
   Check(Near(APMinimumRiskForSpread(.03,.2,.02,.01,10,.01,0),1.7),"M5 spread-cost lower bound");
   Check(Near(APCostAwareInitialStop(99.95,100,.02,.2,.01,2,1),99.89),"initial buy stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(100.05,100,.02,.2,.01,2,-1),100.11),"initial sell stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(99,100,.02,.2,.01,2,1),99),"already wider structural stop is preserved");
   Check(APCostAwareInitialStop(99,100,.02,0,.01,2,1)==0,"invalid cost ratio blocks stop calculation");
   for(int wait_index=0;wait_index<75;wait_index++)
   {
      if(IsConnected()&&APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())&&APFinitePositive(AccountBalance()))break;
      Sleep(200);
   }
   bool history_ready=false;
   for(int history_wait=0;history_wait<75;history_wait++)
   {
      MqlRates rates[];
      CopyRates("XAUUSD",PERIOD_M5,0,120,rates);CopyRates("XAGUSD",PERIOD_M5,0,120,rates);
      history_ready=iBars("XAUUSD",PERIOD_M5)>=101&&iBars("XAGUSD",PERIOD_M5)>=101;
      if(history_ready)break;
      Sleep(200);
   }
   FolderCreate("DemoAutopilot");
   int f=FileOpen("DemoAutopilot\\self-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"passed\":"+IntegerToString(passed)+",\"failed\":"+IntegerToString(failed)+
         ",\"order_operations\":0,\"connected\":"+(IsConnected()?"true":"false")+
         ",\"expected_demo\":"+(APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())?"true":"false")+
         ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+"}");
      FileClose(f);
   }
   int data_file=FileOpen("DemoAutopilot\\m5-preflight.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(data_file!=INVALID_HANDLE)
   {
      string json="{\"m5_history_ready\":"+(history_ready?"true":"false")+",\"order_operations\":0,\"symbols\":[";
      string names[2]={"XAUUSD","XAGUSD"};
      for(int i=0;i<2;i++)
      {
         string symbol=names[i];if(i>0)json+=",";
         double h1_close=iClose(symbol,PERIOD_H1,1),h1_ema=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1);
         int side=APBias(h1_close,h1_ema);
         bool momentum=APMomentum(side,iOpen(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,2),iMA(symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE,1));
         json+="{\"symbol\":\""+symbol+"\",\"m5_bars\":"+IntegerToString(iBars(symbol,PERIOD_M5))+
            ",\"h1_bars\":"+IntegerToString(iBars(symbol,PERIOD_H1))+",\"h1_direction\":"+IntegerToString(side)+
            ",\"last_closed_m5_momentum_matches\":"+(momentum?"true":"false")+"}";
      }
      FileWriteString(data_file,json+"]}");FileClose(data_file);
   }
   Print("AP self-test: passed=",passed," failed=",failed,"; no order operations.");
}
