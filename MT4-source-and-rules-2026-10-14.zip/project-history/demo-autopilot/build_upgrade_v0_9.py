"""Stage the next authorized demo trial from the deployed FP v0.8 branch."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal'/'MQL4'
STAGE=ROOT/'staging-v0.9'
BACKUP=ROOT/'backup-fp-v0.8'
STAGE.mkdir(exist_ok=True)
BACKUP.mkdir(exist_ok=True)
for relative in ['Experts/Codex/DemoPracticeAutopilot.mq4','Experts/Codex/DemoPracticeAutopilot.ex4',
                 'Scripts/Codex/UpgradeReviewV08.mq4','Presets/continuous-demo.set']:
    target=BACKUP/relative;target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():shutil.copy2(LIVE/relative,target)
before=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
source=before

def body(text,name):
    match=re.search(r'(?m)^(?:bool|int|double|string|void) '+re.escape(name)+r'\(',text)
    assert match,name
    opening=text.index('{',match.end());depth=0
    for at in range(opening,len(text)):
        depth+=(text[at]=='{')-(text[at]=='}')
        if depth==0:return text[match.start():at+1]
    raise ValueError(name)

def change(old,new,count=1):
    global source
    assert source.count(old)==count,(old[:90],source.count(old),count)
    source=source.replace(old,new)

change('version "1.800"','version "1.900"')
change('#include <Codex/BudgetAdmission.mqh>','#include <Codex/BudgetAdmission.mqh>\n#include <Codex/ForwardCore.mqh>\n#include <Codex/ProfitProtection.mqh>')
source=source.replace('v0.8','v0.9').replace('\\"version\\":\\"0.8\\"','\\"version\\":\\"0.9\\"')
change('FileWrite(f,"0.8",ticket>0?', 'FileWrite(f,"0.9",ticket>0?')
change('if(APGiveback(peak,net,r))','if(APProtectedGiveback(peak,net,r))')
change('''      if(net>=r)
      {
         double be=APBreakEven(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side);''','''      if(APProtectedNet(peak,r)>=0)
      {
         double be=APProtectedStop(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side,peak,r);''')
# Only accepted, verified entries are enrolled; failed or over-budget fills are excluded.
change('''   CheckOutcome(index,AP_FILLED,minimum_risk,true);''','''   if(GlobalVariableGet(K("halt"))==0)EPStart(ticket,index,s);
   CheckOutcome(index,AP_FILLED,minimum_risk,true);''')
change('''   LabCycle();
   if(TimeLocal()''','''   LabCycle();EPCycle();
   if(TimeLocal()''')
change('''   FLShutdown();''','''   EPShutdown();FLShutdown();''')
source+='\n#include <Codex/ExitComparison.mqh>\n'
change('''   if(reasons[index]=="等待下一次M5收盘触发"''','''   if(last_codes[index]==AP_FILLED)
   {
      int wait=(int)((datetime)GlobalVariableGet(K("last_close"))+CooldownMinutes*60-TimeCurrent());
      return wait>0?"上一笔已平仓；冷却剩 "+IntegerToString(wait)+" 秒":"上一笔已平仓；等待新信号";
   }
   if(reasons[index]=="等待下一次M5收盘触发"''')
change('''   Label("research",FLDisplay(),158);''','''   Label("research","浮盈0.6R尝试保本；达到1R后逐步保护",158);''')
change('''void Status()
{''','''string PositionsJson()
{
   string out="[";int count=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      if(count++>0)out+=",";
      int ticket=OrderTicket();double r=GlobalVariableGet(K("initial_R",ticket)),peak=GlobalVariableGet(K("peak",ticket));
      double cost=APConservativeCost(OrderLots(),RoundTripFeePerLotUSD,OrderCommission(),OrderSwap());
      out+="{\\\"ticket\\\":"+IntegerToString(ticket)+",\\\"symbol\\\":\\\""+OrderSymbol()+"\\\",\\\"side\\\":\\\""+(OrderType()==OP_BUY?"buy":"sell")+"\\\""+
         ",\\\"lots\\\":"+DoubleToString(OrderLots(),8)+",\\\"open_price\\\":"+DoubleToString(OrderOpenPrice(),8)+
         ",\\\"stop_loss\\\":"+DoubleToString(OrderStopLoss(),8)+",\\\"take_profit\\\":"+DoubleToString(OrderTakeProfit(),8)+
         ",\\\"broker_net_floating_usd\\\":"+DoubleToString(OrderProfit()+OrderCommission()+OrderSwap(),4)+
         ",\\\"management_estimated_net_usd\\\":"+DoubleToString(OrderProfit()-cost,4)+",\\\"initial_planned_risk_usd\\\":"+Metric(r)+
         ",\\\"observed_peak_estimated_net_usd\\\":"+Metric(peak)+",\\\"desired_protected_net_usd\\\":"+Metric(APProtectedNet(peak,r))+
         ",\\\"held_seconds\\\":"+IntegerToString((int)(TimeCurrent()-OrderOpenTime()))+"}";
   }
   return out+"]";
}

void Status()
{''')
change('''      "\\\"entry_checks\\\":{\\\"XAUUSD\\\":"''','''      "\\\"experimental_exit_policy\\\":true,\\\"break_even_trigger_r\\\":0.6,\\\"profit_trail_activation_r\\\":1.0,"+
      "\\\"positions\\\":"+PositionsJson()+",\\\"exit_comparison_enabled\\\":"+(EnableForwardResearch?"true":"false")+","+
      "\\\"entry_checks\\\":{\\\"XAUUSD\\\":"''')
change('v0.9 budget admission, fresh diagnostics and round-trip cost reserve;', 'v0.9 early protection demo trial; paired prospective exit comparison;')
(STAGE/'DemoPracticeAutopilot.mq4').write_text(source,encoding='utf-8-sig')
for name in ['ProfitProtection.mqh','ExitComparison.mqh']:shutil.copy2(ROOT/name,STAGE/name)
protected=['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','SafeClose','SafeTighten','ReconcileFlat','Direction','RecentStructure','OnChartEvent']
guard={name:body(before,name)==body(source,name) for name in protected}
assert all(guard.values())
old_entry=body(before,'TryEntry');new_entry=body(source,'TryEntry')
# Entry signal and sizing stay exact after stripping version labels and research enrollment.
normalized=new_entry.replace('v0.9','v0.8').replace('   if(GlobalVariableGet(K("halt"))==0)EPStart(ticket,index,s);\n','')
assert normalized==old_entry
result={'protected_functions':guard,'entry_signal_and_sizing_unchanged':True,'risk_budget_usd':5,
        'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'profitability_validated':False}
(STAGE/'guard-review.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'stage':str(STAGE),'protected_functions':len(guard),'risk_budget_usd':5,'live_binary_modified':False}))
