$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName UIAutomationClient
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public static class FpDemoUi {
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint msg,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h,uint flags);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr extra);
}
'@
$fpDemoProcess=Get-Process terminal | Where-Object Path -eq 'D:\Organized\Projects\codex_project\MT4\demo-autopilot\fp-demo-terminal\terminal.exe' | Select-Object -First 1
if(-not $fpDemoProcess){throw 'Isolated FP demo terminal missing'}
function Assert-FpDemoWindow {
 $fpDemoProcess.Refresh()
 $cond=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$fpDemoProcess.Id)
 $windows=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children,$cond)
 $main=$windows | Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Window -and $_.Current.Name -match '^MetaTrader 4$|^48530368: FPMarketsLtd-Demo2' -and $_.Current.NativeWindowHandle -ne 0} | Select-Object -First 1
 if(-not $main){throw 'Expected account window not found in isolated terminal'}
 $script:fpDemoHandle=[IntPtr]$main.Current.NativeWindowHandle
}
function Get-FpDemoElements {
 Assert-FpDemoWindow
 $cond=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$fpDemoProcess.Id)
 $roots=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children,$cond)
 foreach($root in $roots){
  $root
  $root.FindAll([Windows.Automation.TreeScope]::Descendants,$cond)
 }
}
function Activate-FpDemo {
 Assert-FpDemoWindow
 $handle=$script:fpDemoHandle
 $mainElement=[Windows.Automation.AutomationElement]::FromHandle($handle)
 $mainPattern=$mainElement.GetCurrentPattern([Windows.Automation.WindowPattern]::Pattern)
 if($mainPattern.Current.WindowVisualState -eq [Windows.Automation.WindowVisualState]::Minimized){
  $mainPattern.SetWindowVisualState([Windows.Automation.WindowVisualState]::Normal)
  Start-Sleep -Milliseconds 150
 }
 $mainPattern.SetWindowVisualState([Windows.Automation.WindowVisualState]::Maximized)
 Start-Sleep -Milliseconds 150
 $modal=Get-FpDemoElements | Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Window -and $_.Current.NativeWindowHandle -ne $handle.ToInt64() -and $_.Current.NativeWindowHandle -ne 0 -and [FpDemoUi]::GetAncestor([IntPtr]$_.Current.NativeWindowHandle,2).ToInt64() -eq $_.Current.NativeWindowHandle -and $_.Current.IsEnabled} | Select-Object -First 1
 if($modal){$handle=[IntPtr]$modal.Current.NativeWindowHandle}
 $check=[uint32]0
 $fgThread=[FpDemoUi]::GetWindowThreadProcessId([FpDemoUi]::GetForegroundWindow(),[ref]$check)
 $own=[FpDemoUi]::GetCurrentThreadId();$attached=$false
 if($fgThread -ne $own){$attached=[FpDemoUi]::AttachThreadInput($own,$fgThread,$true)}
 try{[FpDemoUi]::BringWindowToTop($handle)|Out-Null;[FpDemoUi]::SetForegroundWindow($handle)|Out-Null}finally{if($attached){[FpDemoUi]::AttachThreadInput($own,$fgThread,$false)|Out-Null}}
 Start-Sleep -Milliseconds 100
 [FpDemoUi]::GetWindowThreadProcessId([FpDemoUi]::GetForegroundWindow(),[ref]$check)|Out-Null
 if($check -ne $fpDemoProcess.Id){throw 'Isolated demo terminal not foreground'}
}
function Click-FpDemo([int]$x,[int]$y) {
 Activate-FpDemo
 [FpDemoUi]::SetCursorPos($x,$y)|Out-Null
 [FpDemoUi]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
 [FpDemoUi]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 150
}
