"""Build from the deployed FP demo branch; never overwrite a running EA binary."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
LIVE = ROOT / 'fp-demo-terminal' / 'MQL4'
deployed=LIVE/'Experts/Codex/DemoPracticeAutopilot.mq4'
if deployed.exists() and 'version "1.900"' in deployed.read_text(encoding='utf-8-sig'):
    raise SystemExit('v0.9 is deployed; use build_upgrade_v0_9.py. Refusing to stage an accidental downgrade.')
STAGE = ROOT / 'staging-v0.8'
BACKUP = ROOT / 'backup-fp-v0.7'
STAGE.mkdir(exist_ok=True)
BACKUP.mkdir(exist_ok=True)
for relative in ['Experts/Codex/DemoPracticeAutopilot.mq4', 'Experts/Codex/DemoPracticeAutopilot.ex4',
                 'Scripts/Codex/AutopilotReviewSuite.mq4', 'Presets/continuous-demo.set']:
    dest = BACKUP / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        shutil.copy2(LIVE / relative, dest)

before = (BACKUP / 'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
source = before

def change(old, new, count=1):
    global source
    assert source.count(old) == count, (old[:100], source.count(old), count)
    source = source.replace(old, new)

def body(text, name):
    match = re.search(r'(?m)^(?:bool|int|double|string|void) '+re.escape(name)+r'\(', text)
    assert match, name
    start = text.index('{', match.end())
    depth = 0
    for pos in range(start, len(text)):
        depth += (text[pos] == '{') - (text[pos] == '}')
        if depth == 0:
            return text[match.start():pos+1]
    raise ValueError(name)

def replace_function(name, new):
    change(body(source, name), new)

change('version "1.701"', 'version "1.800"')
change('#include <Codex/AutopilotCore.mqh>', '#include <Codex/AutopilotCore.mqh>\n#include <Codex/BudgetAdmission.mqh>')
source = source.replace('APCheckText(', 'AP08CheckText(')
source = source.replace('v0.7', 'v0.8').replace('\\"version\\":\\"0.7\\"', '\\"version\\":\\"0.8\\"')
change('FileWrite(f,"0.5",ticket>0?', 'FileWrite(f,"0.8",ticket>0?')
change('bool quotes_fresh[2]={false,false};', '''bool quotes_fresh[2]={false,false};
double admission_floors[2]={-1,-1},minimum_lots[2]={-1,-1};
int admission_codes[2]={AP_SPEC_INVALID,AP_SPEC_INVALID};
datetime last_draw=0;''')

# Diagnostic refresh must be independent of event de-duplication.
change('''   if(!APRecordChanged(last_bars[index],last_codes[index],bar,code))return;
   last_bars[index]=bar;last_codes[index]=code;check_counts[index]++;''', '''   bool changed=APRecordChanged(last_bars[index],last_codes[index],bar,code);
   last_bars[index]=bar;last_codes[index]=code;''')
change('''   last_minimum_risks[index]=minimum_risk;
   GlobalVariableSet''', '''   last_minimum_risks[index]=minimum_risk;
   if(!changed)return;
   check_counts[index]++;
   GlobalVariableSet''')

replace_function('VisibleReason', '''string VisibleReason(const int index)
{
   for(int oi=OrdersTotal()-1;oi>=0;oi--)
      if(OrderSelect(oi,SELECT_BY_POS,MODE_TRADES)&&IsOwnedSelected()&&OrderSymbol()==symbols[index])
         return quotes_fresh[index]?"本程序持仓中；报价更新中":"本程序持仓中；等待新鲜报价";
   if(!quotes_fresh[index])return "等待新鲜报价";
   if(admission_codes[index]==AP_COST_BUDGET)
      return "暂不可入场：最小单风险至少 $"+DoubleToString(admission_floors[index],2)+
         " > $"+DoubleToString(APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),2);
   if(admission_codes[index]!=0)return AP08CheckText(admission_codes[index]);
   if(reasons[index]=="等待下一次M5收盘触发" && last_codes[index]>0)
      return "等新K线；上次 "+AP08CheckText(last_codes[index]);
   return reasons[index];
}''')
change('void Status()\n{', '''void Status()
{
   // Persist fresh measurements at the existing five-second snapshot cadence.
   if(Identity()&&Owner())
   {
      for(int i=0;i<2;i++)if(last_local_checks[i]>0)
      {
         GlobalVariableSet(DK(i,"local"),(double)last_local_checks[i]);
         GlobalVariableSet(DK(i,"server"),(double)last_server_checks[i]);
         GlobalVariableSet(DK(i,"budget"),last_budgets[i]);
         GlobalVariableSet(DK(i,"min_risk"),last_minimum_risks[i]);
      }
      GlobalVariablesFlush();
   }''')

change('''      ",\\\"current_spread_price\\\":"''', '''      ",\\\"admission_code\\\":"+IntegerToString(quotes_fresh[index]?admission_codes[index]:AP_QUOTE)+
      ",\\\"admission_preflight_passes\\\":"+(quotes_fresh[index]&&admission_codes[index]==0?"true":"false")+
      ",\\\"admission_risk_floor_usd\\\":"+(quotes_fresh[index]?Metric(admission_floors[index]):"null")+
      ",\\\"minimum_lots\\\":"+(quotes_fresh[index]?Metric(minimum_lots[index]):"null")+
      ",\\\"current_explanation\\\":\\\""+Escape(VisibleReason(index))+"\\\""+
      ",\\\"current_spread_price\\\":"''')

# The preflight uses a necessary lower bound. Never shrink a structural stop to fit.
change('''   if(attempted[index]==bar ||''', '''   RefreshAdmission(index,s);
   if(admission_codes[index]!=0){CheckOutcome(index,admission_codes[index]);return;}
   if(attempted[index]==bar ||''')
change('void TryEntry(const int index)\n{', '''void RefreshAdmission(const int index,const Spec &s)
{
   minimum_lots[index]=s.minimum;
   admission_floors[index]=APAdmissionRiskFloor(s.spread,MaxSpreadFraction,s.slip,s.tick,s.value,s.minimum,
      RoundTripFeePerLotUSD,MarketInfo(symbols[index],MODE_STOPLEVEL),s.point);
   admission_codes[index]=APAdmissionCode(admission_floors[index],
      APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),s.minimum,MathMin(s.maximum,MaximumLots));
}

void TryEntry(const int index)
{''')
change('''            current_spreads[i]=tmp.spread;''', '''            RefreshAdmission(i,tmp);
            current_spreads[i]=tmp.spread;''')
change('''   if(working)return;working=true;closed_this_cycle=false;''', '''   if(working)return;working=true;closed_this_cycle=false;
   if(!Identity()||!Owner()||!IsConnected())
      for(int qi=0;qi<2;qi++){quotes_fresh[qi]=false;admission_codes[qi]=AP_SPEC_INVALID;admission_floors[qi]=-1;}''')
change('''   LabCycle();Display();if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}''', '''   LabCycle();
   if(TimeLocal()!=last_draw){Display();last_draw=TimeLocal();}
   if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}''')

change('''      double cost=MathMax(0,-OrderCommission())+MathMax(0,-OrderSwap());''', '''      double cost=APConservativeCost(OrderLots(),RoundTripFeePerLotUSD,OrderCommission(),OrderSwap());
      if(cost<0){GlobalVariableSet(K("halt"),1);mode="费用数据异常，暂停新单";continue;}''')

# Keep the two-button interface, add an explicit live timestamp/countdown.
change('OBJPROP_YSIZE,200)', 'OBJPROP_YSIZE,226)')
change('OBJPROP_YDISTANCE,178)', 'OBJPROP_YDISTANCE,204)')
change('OBJPROP_XSIZE,510)', 'OBJPROP_XSIZE,590)')
change('" |  单笔风险≤"', '" |  计划风险≤"')
change('''   Label("rule","每5分钟检查；同时一笔；累计亏损不限",137);''', '''   int next=APNextBarSeconds(iTime(symbols[0],ENTRY_TF,0),TimeCurrent(),ENTRY_SECONDS);
   Label("rule","M5收盘找机会；逐秒管理；同时一笔",137);
   Label("heartbeat","更新 "+TimeToString(TimeLocal(),TIME_SECONDS)+"  |  "+
      (IsConnected()&&quotes_fresh[0]&&next>=0?"下根M5约 "+IntegerToString(next/60)+":"+(next%60<10?"0":"")+IntegerToString(next%60):"等待行情恢复"),181);''')
change('''      "\\\"gold_reason\\\":\\\""+Escape(reasons[0])+"\\\",\\\"silver_reason\\\":\\\""+Escape(reasons[1])+"\\\","+''', '''      "\\\"management_cost_basis\\\":\\\"max(estimated_round_trip_fee,observed_commission)+negative_swap\\\","+
      "\\\"gold_reason\\\":\\\""+Escape(VisibleReason(0))+"\\\",\\\"silver_reason\\\":\\\""+Escape(VisibleReason(1))+"\\\","+''')
change('v0.8 inference and portfolio research; unchanged broker rule;', 'v0.8 budget admission, fresh diagnostics and round-trip cost reserve;')

(STAGE / 'DemoPracticeAutopilot.mq4').write_text(source, encoding='utf-8-sig')
shutil.copy2(ROOT / 'BudgetAdmission.mqh', STAGE / 'BudgetAdmission.mqh')

protected = ['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','SafeClose','SafeTighten',
             'ReconcileFlat','ObserveProtectionSelected','Direction','RecentStructure','OnChartEvent']
guard = {'functions': {name: body(before,name)==body(source,name) for name in protected},
         'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
         'authorized_risk_budget_usd':5,'strategy_signal_changed':False,'minimum_volume_forced':False}
assert all(guard['functions'].values())
(STAGE / 'guard-review.json').write_text(json.dumps(guard,indent=2),encoding='utf-8')
print(json.dumps({'stage':str(STAGE),'unchanged_guards':len(protected),'live_binary_modified':False}))
