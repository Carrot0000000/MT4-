"""Verify the authorized higher demo budget, silver admission, and unchanged small lot cap."""
from build_upgrade_v0_13 import ROOT,LIVE,STAGE,BACKUP,body
src=(STAGE/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(BACKUP/'Scripts/Codex/UpgradeReviewV012.mq4').read_text(encoding='utf-8-sig')
test=test.replace('version "2.200"','version "2.300"').replace('v012-','v013-')
test=test.replace('APPracticeBudget(10000,10000,500,1.01)==0,"risk percent above one rejected"',
                  'APPracticeBudget(10000,10000,500,3.01)==0,"risk percent above three rejected"')
for n in ['Cycle','CheckOutcome','RefreshAdmission']:
    test=test.replace(body(test,n),body(src,n))
test=test.replace(body(test,'TestProductionTryEntry'),body(src,'TryEntry').replace('void TryEntry(','void TestProductionTryEntry(',1))
test=test.replace('void AlignedCycle12(){}','void AlignedCycle12(){}\nvoid AlignedCycle13(){}')
new=r'''
void RunAuthorizedBudgetTests()
{
   ECheck(Near(APPracticeBudget(10000,10000,500,3),15),"large broker balance never enlarges authorized fifteen dollar risk");
   ECheck(Near(APPracticeBudget(10000,450,500,3),13.5),"low real equity reduces higher practice budget");
   ECheck(APPracticeBudget(10000,10000,501,3)==0&&APPracticeBudget(10000,10000,500,10)==0,"capital inflation and superseded fifty dollar setting rejected");
   ECheck(APPracticeBudget(10000,10000,500,3.001)==0&&APPracticeBudget(10000,10000,500,-3)==0,"above authorized percent and negative risk rejected");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==1&&Near(last_budgets[1],15)&&Near(last_minimum_risks[1],14.97),"production silver buy and sell can reach send within fifteen dollars");
      ResetScenario();RiskPercent=1;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_COST_BUDGET,"same silver setup remains correctly blocked under original five dollars");
      ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.5:100.5;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_BUDGET,"over-fifteen dollar structural risk remains blocked for both silver sides");
   }
   ECheck(Near(APLots(15,.1,.04,.001,5,.01,.01,.01,7),.01),"larger risk budget cannot bypass maximum 0.01 lot cap");
   ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;
   cf_root="DemoAutopilot\\test-v013-userbudget-"+IntegerToString(GetTickCount())+"-";
   ECheck(CF_PROTOCOL!=BF_PROTOCOL&&CFInitialize()&&!cf_fault,"authorized risk experiment receives independent protocol");
   ECheck(Near(CFBudget(10000),15)&&Near(CFBudget(500),15)&&Near(CFBudget(400),12),"new research follows static practice capital and lower-cash limits");
   int f=FileOpen("DemoAutopilot\\v013-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"authorized_risk_usd\":15,\"silver_production_entry_checked\":true}");FileClose(f);}
   RiskPercent=1;
}
'''
test=test.replace('#undef OrderClosePrice','#define AlignedCycle13 TestAlignedCycle13\n#include <Codex/AlignedForward13.mqh>\n#undef AlignedCycle13\n'+new+'\n#undef OrderClosePrice',1)
test=test.replace('RunEntryReserveTests();Print(', 'RunEntryReserveTests();RunAuthorizedBudgetTests();Print(')
(LIVE/'Scripts/Codex/UpgradeReviewV013.mq4').write_text(test,encoding='utf-8-sig')
print('Generated v0.13 native budget and silver eligibility regression; fake trade APIs only.')
