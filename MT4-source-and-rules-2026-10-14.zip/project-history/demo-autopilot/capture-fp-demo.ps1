$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName UIAutomationClient
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class MtDemoReviewCapture {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int Left,Top,Right,Bottom;}
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd,out RECT rect);
 [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr hWnd,IntPtr hdc,uint flags);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd,int command);
}
'@
$mtReviewProc=Get-Process terminal | Where-Object Path -eq 'D:\Organized\Projects\codex_project\MT4\demo-autopilot\fp-demo-terminal\terminal.exe' | Select-Object -First 1
if(-not $mtReviewProc){throw 'MT4 not running'}
$mtCaptureCondition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ProcessIdProperty,$mtReviewProc.Id)
$mtCaptureItems=[Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Children,$mtCaptureCondition)
$mtCaptureMain=$mtCaptureItems|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Window -and $_.Current.Name -match '^48530368: FPMarketsLtd-Demo2'}|Select-Object -First 1
if(-not $mtCaptureMain){throw 'The expected demo account is not active'}
$mtCaptureHandle=[IntPtr]$mtCaptureMain.Current.NativeWindowHandle
$mtCapturePattern=$mtCaptureMain.GetCurrentPattern([Windows.Automation.WindowPattern]::Pattern)
if($mtCapturePattern.Current.WindowVisualState -eq [Windows.Automation.WindowVisualState]::Minimized){
 $mtCapturePattern.SetWindowVisualState([Windows.Automation.WindowVisualState]::Normal)
 $mtCapturePattern.SetWindowVisualState([Windows.Automation.WindowVisualState]::Maximized)
}
Start-Sleep -Milliseconds 200
$mtReviewRect=[MtDemoReviewCapture+RECT]::new()
[MtDemoReviewCapture]::GetWindowRect($mtCaptureHandle,[ref]$mtReviewRect)|Out-Null
$mtReviewBitmap=[Drawing.Bitmap]::new($mtReviewRect.Right-$mtReviewRect.Left,$mtReviewRect.Bottom-$mtReviewRect.Top)
$mtReviewGraphics=[Drawing.Graphics]::FromImage($mtReviewBitmap)
$mtReviewHdc=$mtReviewGraphics.GetHdc()
try{$mtReviewSucceeded=[MtDemoReviewCapture]::PrintWindow($mtCaptureHandle,$mtReviewHdc,2)}finally{$mtReviewGraphics.ReleaseHdc($mtReviewHdc)}
$mtReviewBitmap.Save('C:\Users\96259\AppData\Local\Temp\codex-fp-demo-review.png',[Drawing.Imaging.ImageFormat]::Png)
$mtReviewGraphics.Dispose()
$mtReviewBitmap.Dispose()
[pscustomobject]@{Captured=$mtReviewSucceeded;Title=$mtCaptureMain.Current.Name;At=(Get-Date -Format o)} | ConvertTo-Json

