﻿#property strict
#property version "1.200"
#property description "Continuous practice; hard locked to one MetaQuotes DEMO login. Unvalidated strategy."
#include <Codex/AutopilotCore.mqh>

input bool AutoEntries=false;
input double RiskPercent=0.5;
input double MaximumLots=0.01;
input int CooldownMinutes=30;
input int MaximumHoldMinutes=60;
input double RoundTripFeePerLotUSD=0;
input int SlippagePoints=20;
// There is deliberately no cumulative loss or daily trade-count limit in this demo-only version.
const int MAGIC=2026101217;
const string PREFIX="DAP_";
string symbols[2]={"XAUUSD","XAGUSD"};
string reasons[2]={"等待报价和已完成K线","等待报价和已完成K线"};
datetime attempted[2]={0,0},last_quote_time[2]={0,0},last_arrival[2]={0,0};
bool seen_new_quote[2]={false,false},working=false,have_owner=false;
string key="AP02.176318407.",mode="初始化";
datetime last_status=0,last_sync=0;

struct Spec
{
   double tick,value,point,minimum,step,maximum,spread,bid,ask,slip;
   int digits;
};

string Escape(string s)
{ StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");StringReplace(s,"\r"," ");StringReplace(s,"\n"," ");return s; }
string K(const string field,const int ticket=0)
{return key+field+(ticket>0?"."+IntegerToString(ticket):"");}
bool Identity()
{return APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting()) && AccountCurrency()=="USD";}
string OwnerMarker(){return K("owner_chart_"+IntegerToString(ChartID()));}
bool Owner()
{
   // Chart IDs exceed double's exact integer range; store the exact ID in the variable NAME.
   return have_owner && GlobalVariableCheck(K("owner")) && GlobalVariableGet(K("owner"))==1 &&
      GlobalVariableCheck(OwnerMarker()) && GlobalVariableGet(OwnerMarker())==1;
}
bool MutationAllowed()
{
   return Identity() && Owner() && IsConnected() && IsTradeAllowed() && !IsTradeContextBusy() &&
      (bool)AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) && (bool)AccountInfoInteger(ACCOUNT_TRADE_EXPERT);
}
bool Paused(){return GlobalVariableGet(K("pause"))>0 || GlobalVariableGet(K("halt"))>0;}
int IndexOf(const string symbol){for(int i=0;i<2;i++)if(symbols[i]==symbol)return i;return -1;}

void Event(const string action,const string symbol,const int ticket,const string details)
{
   int f=FileOpen("DemoAutopilot\\events.csv",FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);mode="暂停：无法写入交易记录";return;}
   if(FileSize(f)==0)FileWrite(f,"server_time","local_time","action","symbol","ticket","details");
   FileSeek(f,0,SEEK_END);
   FileWrite(f,TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS),TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS),action,symbol,ticket,details);
   FileFlush(f);FileClose(f);
   Print("DemoAutopilot: ",action," ",symbol," #",ticket," ",details);
}

bool ReadSpec(const int index,Spec &s)
{
   string symbol=symbols[index];MqlTick q;
   if(!SymbolInfoTick(symbol,q)||!APFinitePositive(q.bid)||!APFinitePositive(q.ask)||q.ask<q.bid)return false;
   if(q.time!=last_quote_time[index])
   {
      if(last_quote_time[index]!=0)seen_new_quote[index]=true;
      last_quote_time[index]=q.time;last_arrival[index]=TimeLocal();
   }
   if(!seen_new_quote[index] || TimeLocal()-last_arrival[index]>5 || TimeCurrent()-q.time>5 || q.time>TimeCurrent()+2)return false;
   s.bid=q.bid;s.ask=q.ask;s.spread=q.ask-q.bid;
   s.tick=SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
   s.value=MarketInfo(symbol,MODE_TICKVALUE);s.point=MarketInfo(symbol,MODE_POINT);
   s.minimum=MarketInfo(symbol,MODE_MINLOT);s.step=MarketInfo(symbol,MODE_LOTSTEP);
   s.maximum=MarketInfo(symbol,MODE_MAXLOT);s.digits=(int)MarketInfo(symbol,MODE_DIGITS);
   s.slip=index==0?0.05:0.02;
   return APFinitePositive(s.tick)&&APFinitePositive(s.value)&&APFinitePositive(s.point)&&
          APFinitePositive(s.minimum)&&APFinitePositive(s.step)&&APFinitePositive(s.maximum);
}

bool IsOwnedSelected()
{return OrderMagicNumber()==MAGIC && IndexOf(OrderSymbol())>=0 && (OrderType()==OP_BUY||OrderType()==OP_SELL);}
int OwnedCount()
{
   int count=0;for(int i=OrdersTotal()-1;i>=0;i--)if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)&&IsOwnedSelected())count++;
   return count;
}

void SyncClosed()
{
   datetime latest=(datetime)GlobalVariableGet(K("last_close"));
   for(int i=OrdersHistoryTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)||!IsOwnedSelected()||OrderCloseTime()==0)continue;
      if(OrderCloseTime()>latest)latest=OrderCloseTime();
      int ticket=OrderTicket();
      if(!GlobalVariableCheck(K("closed_logged",ticket)))
      {
         double net=OrderProfit()+OrderCommission()+OrderSwap();
         Event("CLOSED",OrderSymbol(),ticket,"net_usd="+DoubleToString(net,2)+" exit="+DoubleToString(OrderClosePrice(),(int)MarketInfo(OrderSymbol(),MODE_DIGITS)));
         GlobalVariableSet(K("closed_logged",ticket),1);
      }
   }
   GlobalVariableSet(K("last_close"),(double)latest);
}

bool SafeClose(const int ticket,const string why)
{
   if(!MutationAllowed()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   string symbol=OrderSymbol();int index=IndexOf(symbol);Spec s;
   if(!ReadSpec(index,s))return false;
   double lots=OrderLots(),price=OrderType()==OP_BUY?s.bid:s.ask;
   // The same account and ownership guards are rechecked immediately before every mutation.
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();
   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,why+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:5)));
   return ok;
}

bool SafeTighten(const int ticket,const double target)
{
   if(!MutationAllowed()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());Spec s;
   if(!ReadSpec(index,s)||!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))return false;
   double old=OrderStopLoss();
   if((side==1&&target<=old+s.tick*.5)||(side==-1&&target>=old-s.tick*.5))return false;
   double minimum=(MathMax(MarketInfo(OrderSymbol(),MODE_STOPLEVEL),MarketInfo(OrderSymbol(),MODE_FREEZELEVEL))+1)*s.point;
   if((side==1&&target>=s.bid-minimum)||(side==-1&&target<=s.ask+minimum))return false;
   string symbol=OrderSymbol();double open=OrderOpenPrice(),tp=OrderTakeProfit();
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderModify(ticket,open,target,tp,0,clrNONE);int error=GetLastError();
   Event(ok?"SL_TIGHTEN_ACCEPTED":"SL_TIGHTEN_FAILED",symbol,ticket,"sl="+DoubleToString(target,s.digits)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:5)));
   return ok;
}

void Manage()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      int ticket=OrderTicket(),side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());
      Spec s;if(!ReadSpec(index,s))continue;
      if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))continue;
      if(GlobalVariableGet(K("flatten"))>0){SafeClose(ticket,"USER_FLATTEN_AND_PAUSE");continue;}
      if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,"MISSING_SERVER_PROTECTION");continue;}
      if(!GlobalVariableCheck(K("initial_R",ticket)))
      {
         // A crash immediately after OrderSend can recover the prior persisted plan.
         double pending=GlobalVariableGet(K("pending_R"));
         if(APFinitePositive(pending))GlobalVariableSet(K("initial_R",ticket),pending);
         else{GlobalVariableSet(K("halt"),1);mode="暂停：持仓初始风险状态缺失";continue;}
      }
      double r=GlobalVariableGet(K("initial_R",ticket));
      double units=OrderLots()*s.value/s.tick;
      double cost=MathMax(0,-OrderCommission())+MathMax(0,-OrderSwap());
      double remaining_risk=MathMax(0,side*(OrderOpenPrice()-OrderStopLoss()))*units+s.slip*units+cost;
      if(remaining_risk>r+0.01)
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,"STOP_RISK_EXPANDED");continue;}
      double price=side==1?s.bid:s.ask;
      double net=APNet(side,OrderOpenPrice(),price,units,cost);
      double peak=MathMax(net,GlobalVariableGet(K("peak",ticket)));
      GlobalVariableSet(K("peak",ticket),peak);
      if(APGiveback(peak,net,r)){SafeClose(ticket,"PROFIT_GIVEBACK_0.5R_AFTER_1.5R");continue;}
      if(MaximumHoldMinutes>0 && TimeCurrent()-OrderOpenTime()>=MaximumHoldMinutes*60)
      {SafeClose(ticket,"TIME_EXIT_60_MINUTES");continue;}
      if(net>=r)
      {
         double be=APBreakEven(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side);
         if(APFinitePositive(be))SafeTighten(ticket,be);
      }
   }
   if(OwnedCount()==0 && GlobalVariableGet(K("flatten"))>0)GlobalVariableSet(K("flatten"),0);
}

int Direction(const string symbol)
{
   double close=iClose(symbol,PERIOD_H1,1),fast=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1);
   double slow=iMA(symbol,PERIOD_H1,200,0,MODE_EMA,PRICE_CLOSE,1),before=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,4);
   if(close>fast&&fast>slow&&fast>before)return 1;
   if(close<fast&&fast<slow&&fast<before)return -1;
   return 0;
}

double Pivot(const string symbol,const int side)
{
   // center shift>=3 ensures that shifts 1 and 2 on its right have closed.
   for(int j=3;j<=32;j++)
   {
      double value=side==1?iLow(symbol,PERIOD_M15,j):iHigh(symbol,PERIOD_M15,j);
      bool good=APFinitePositive(value);
      for(int delta=-2;delta<=2;delta++)
      {
         if(delta==0)continue;
         double neighbor=side==1?iLow(symbol,PERIOD_M15,j+delta):iHigh(symbol,PERIOD_M15,j+delta);
         if(!APFinitePositive(neighbor)||(side==1&&value>=neighbor)||(side==-1&&value<=neighbor))good=false;
      }
      if(good)return value;
   }
   return 0;
}

void TryEntry(const int index)
{
   string symbol=symbols[index];Spec s;
   if(!ReadSpec(index,s)){reasons[index]="等待新鲜报价";return;}
   if(iBars(symbol,PERIOD_H1)<401||iBars(symbol,PERIOD_M15)<101){reasons[index]="等待历史数据";return;}
   datetime bar=iTime(symbol,PERIOD_M15,0),previous=iTime(symbol,PERIOD_M15,1);
   if(bar==0||previous+900!=bar||TimeCurrent()<bar||TimeCurrent()-bar>60){reasons[index]="等待下一次M15收盘触发";return;}
   if(attempted[index]==bar || (datetime)GlobalVariableGet(K("bar_"+symbol))==bar){reasons[index]="本根K线已检查，等待新信号";return;}
   datetime h1_end=iTime(symbol,PERIOD_H1,1)+3600;
   if(h1_end>TimeCurrent()||TimeCurrent()-h1_end>=3600){reasons[index]="H1数据未完成或过期";return;}
   for(int j=1;j<5;j++)if(iTime(symbol,PERIOD_M15,j)-iTime(symbol,PERIOD_M15,j+1)!=900)
   {reasons[index]="休市缺口后等待连续K线";return;}
   int side=Direction(symbol);
   if(side==0){reasons[index]="H1方向不一致，空仓等待";return;}
   bool pullback=false;
   for(int j=2;j<=4;j++)
   {
      double e=iMA(symbol,PERIOD_M15,20,0,MODE_EMA,PRICE_CLOSE,j);
      if(iLow(symbol,PERIOD_M15,j)<=e && e<=iHigh(symbol,PERIOD_M15,j))pullback=true;
   }
   double close=iClose(symbol,PERIOD_M15,1),open=iOpen(symbol,PERIOD_M15,1);
   double ema=iMA(symbol,PERIOD_M15,20,0,MODE_EMA,PRICE_CLOSE,1);
   bool trigger=side==1?(close>iHigh(symbol,PERIOD_M15,2)&&close>open&&close>ema):
                              (close<iLow(symbol,PERIOD_M15,2)&&close<open&&close<ema);
   if(!pullback||!trigger){reasons[index]="没有回调后的收盘突破";return;}
   double atr=iATR(symbol,PERIOD_M15,14,1),structure=Pivot(symbol,side);
   if(!APFinitePositive(atr)||!APFinitePositive(structure)){reasons[index]="没有已确认结构";return;}
   if(MathAbs(s.bid-close)>0.1*atr){reasons[index]="价格已走远，不追单";return;}
   double sl=APStop(structure,atr,side,s.spread,s.tick,s.digits),fill=side==1?s.ask:s.bid;
   double distance=side*(fill-sl);
   if(!APFinitePositive(sl)||!APFinitePositive(distance)){reasons[index]="止损方向无效";return;}
   if(s.spread>0.1*distance){reasons[index]="点差相对止损过大";return;}
   double budget=MathMin(AccountBalance(),AccountEquity())*RiskPercent/100;
   double lots=APLots(budget,distance,s.slip,s.tick,s.value,s.minimum,s.step,MathMin(s.maximum,MaximumLots),RoundTripFeePerLotUSD);
   if(lots==0){reasons[index]="最小手数超单笔预算，跳过";return;}
   double tp=APPrice(fill+side*2*distance,s.tick,s.digits,side==1);
   double stop_distance=(MarketInfo(symbol,MODE_STOPLEVEL)+1)*s.point;
   if((side==1&&(s.bid-sl<stop_distance||tp-s.bid<stop_distance)) ||
      (side==-1&&(sl-s.ask<stop_distance||s.ask-tp<stop_distance)))
   {reasons[index]="服务器止损距离不允许";return;}
   int type=side==1?OP_BUY:OP_SELL;ResetLastError();
   double free=AccountFreeMarginCheck(symbol,type,lots);int margin_error=GetLastError();
   if(margin_error!=0||free<=0||MarketInfo(symbol,MODE_TRADEALLOWED)==0){reasons[index]="保证金或品种权限不足";return;}
   if(!MutationAllowed()||OrdersTotal()!=0||Paused()){reasons[index]="交易权限、暂停或账户持仓拦截";return;}
   // Persist signal consumption before sending. Unknown execution errors NEVER trigger an immediate duplicate resend.
   attempted[index]=bar;GlobalVariableSet(K("bar_"+symbol),(double)bar);
   double risk=(distance+s.slip)/s.tick*s.value*lots+RoundTripFeePerLotUSD*lots;
   GlobalVariableSet(K("pending_R"),risk);GlobalVariablesFlush();
   Event("ENTRY_PLAN",symbol,0,"side="+IntegerToString(side)+" lots="+DoubleToString(lots,8)+" risk_usd="+DoubleToString(risk,4)+" sl="+DoubleToString(sl,s.digits)+" tp="+DoubleToString(tp,s.digits));
   if(!MutationAllowed()||OrdersTotal()!=0||Paused())return;
   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.2",MAGIC,0,clrNONE);
   int error=GetLastError();
   if(ticket<0)
   {
      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));
      if(error==128||error==6){GlobalVariableSet(K("halt"),1);Event("HALT",symbol,0,"uncertain execution; inspect account before manual recovery");}
      reasons[index]="入场失败，已记录；不会重复发送";return;
   }
   GlobalVariableSet(K("initial_R",ticket),risk);GlobalVariableSet(K("peak",ticket),0);GlobalVariablesFlush();
   Event("ENTRY_ACCEPTED",symbol,ticket,"server returned ticket");
   if(!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())
   {GlobalVariableSet(K("halt"),1);Event("HALT",symbol,ticket,"cannot verify accepted ticket");return;}
   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)/s.tick*s.value*OrderLots()+RoundTripFeePerLotUSD*OrderLots();
   GlobalVariableSet(K("initial_R",ticket),actual);GlobalVariablesFlush();
   if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit())||actual>budget+0.01)
   {GlobalVariableSet(K("halt"),1);SafeClose(ticket,"FILLED_RISK_OR_PROTECTION_MISMATCH");}
   reasons[index]="已成交；实时保本与回撤管理";
}

void Label(const string name,const string text,const int y)
{
   string obj=PREFIX+name;if(ObjectFind(0,obj)<0)ObjectCreate(0,obj,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,obj,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,obj,OBJPROP_XDISTANCE,24);
   ObjectSetInteger(0,obj,OBJPROP_YDISTANCE,y);ObjectSetInteger(0,obj,OBJPROP_COLOR,clrDarkSlateGray);
   ObjectSetInteger(0,obj,OBJPROP_FONTSIZE,10);ObjectSetInteger(0,obj,OBJPROP_SELECTABLE,false);
   ObjectSetString(0,obj,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,obj,OBJPROP_TEXT,text);
}
void Button(const string name,const string text,const int x)
{
   string obj=PREFIX+name;if(ObjectFind(0,obj)<0)ObjectCreate(0,obj,OBJ_BUTTON,0,0,0);
   ObjectSetInteger(0,obj,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,obj,OBJPROP_XDISTANCE,x);
   ObjectSetInteger(0,obj,OBJPROP_YDISTANCE,178);ObjectSetInteger(0,obj,OBJPROP_XSIZE,235);ObjectSetInteger(0,obj,OBJPROP_YSIZE,30);
   ObjectSetInteger(0,obj,OBJPROP_COLOR,clrDarkSlateGray);ObjectSetInteger(0,obj,OBJPROP_BGCOLOR,clrWhiteSmoke);
   ObjectSetInteger(0,obj,OBJPROP_FONTSIZE,10);ObjectSetString(0,obj,OBJPROP_FONT,"Microsoft YaHei");ObjectSetString(0,obj,OBJPROP_TEXT,text);
}
void Display()
{
   string bg=PREFIX+"bg";if(ObjectFind(0,bg)<0)ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,12);
   ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,20);ObjectSetInteger(0,bg,OBJPROP_XSIZE,510);ObjectSetInteger(0,bg,OBJPROP_YSIZE,200);
   ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,clrWhite);ObjectSetInteger(0,bg,OBJPROP_COLOR,clrSilver);
   ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   Label("title","连续模拟练习 v0.2  |  "+mode,30);
   Label("balance",Identity()?"余额 "+DoubleToString(AccountBalance(),2)+" USD  |  单笔风险 "+DoubleToString(RiskPercent,2)+"%":"账户不匹配：禁止任何交易",57);
   Label("gold","黄金："+reasons[0],84);Label("silver","白银："+reasons[1],109);
   Label("rule","累计亏损不封顶；同时一笔；无信号空仓",137);
   Button("pause",Paused()?"继续模拟入场":"暂停新单（继续管理持仓）",24);
   Button("flatten","平仓并停止（本程序订单）",270);ChartRedraw();
}

void Status()
{
   int f=FileOpen("DemoAutopilot\\status.json",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){GlobalVariableSet(K("halt"),1);return;}
   string json="{\"version\":\"0.2\",\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+
      "\",\"server_time\":\""+TimeToString(TimeCurrent(),TIME_DATE|TIME_SECONDS)+"\",\"expected_demo\":"+(Identity()?"true":"false")+
      ",\"connected\":"+(IsConnected()?"true":"false")+",\"trade_allowed\":"+(IsTradeAllowed()?"true":"false")+
      ",\"auto_entries_input\":"+(AutoEntries?"true":"false")+",\"paused\":"+(Paused()?"true":"false")+
      ",\"halt\":"+(GlobalVariableGet(K("halt"))>0?"true":"false")+",\"owner\":"+(Owner()?"true":"false")+
      ",\"mode\":\""+Escape(mode)+"\",\"balance\":"+DoubleToString(Identity()?AccountBalance():0,2)+
      ",\"equity\":"+DoubleToString(Identity()?AccountEquity():0,2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+
      ",\"owned_open_orders\":"+IntegerToString(OwnedCount())+",\"risk_percent\":"+DoubleToString(RiskPercent,3)+
      ",\"cumulative_loss_cap\":null,\"profitability_validated\":false,\"news_filter_installed\":false,"+
      "\"gold_reason\":\""+Escape(reasons[0])+"\",\"silver_reason\":\""+Escape(reasons[1])+"\"}";
   FileWriteString(f,json);FileFlush(f);FileClose(f);
}

void Cycle()
{
   if(working)return;working=true;
   if(!Identity())mode="账户不匹配，禁止交易";
   else if(!Owner())mode="重复实例，禁止交易";
   else if(!IsConnected())mode="断线；等待连接";
   else
   {
      Spec tmp;for(int i=0;i<2;i++)ReadSpec(i,tmp);
      if(TimeLocal()-last_sync>=5){SyncClosed();last_sync=TimeLocal();}
      Manage();
      if(GlobalVariableGet(K("halt"))>0)mode="异常暂停，检查记录";
      else if(!AutoEntries||Paused())mode="暂停新单";
      else if(!IsTradeAllowed())mode="自动交易权限关闭";
      else if(OrdersTotal()>0)mode=OwnedCount()>0?"持仓实时管理":"已有其他订单，暂停新单";
      else if(TimeCurrent()-(datetime)GlobalVariableGet(K("last_close"))<CooldownMinutes*60)mode="平仓后冷却，继续观察";
      else
      {
         mode="持续观察，条件满足才入场";
         for(int i=0;i<2;i++){TryEntry(i);if(OrdersTotal()>0)break;}
      }
   }
   Display();if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}
   working=false;
}

int OnInit()
{
   if(RiskPercent<=0||RiskPercent>1||MaximumLots<=0||MaximumLots>0.01||CooldownMinutes<0||MaximumHoldMinutes<0||RoundTripFeePerLotUSD<0||SlippagePoints<0)
      return INIT_PARAMETERS_INCORRECT;
   FolderCreate("DemoAutopilot");
   if(!GlobalVariableCheck(K("owner"))&&!GlobalVariableTemp(K("owner")))return INIT_FAILED;
   have_owner=GlobalVariableCheck(OwnerMarker())&&GlobalVariableGet(OwnerMarker())==1&&GlobalVariableGet(K("owner"))==1;
   if(!have_owner)
   {
      have_owner=GlobalVariableSetOnCondition(K("owner"),1,0);
      if(have_owner)
      {
         if(!GlobalVariableCheck(OwnerMarker())&&!GlobalVariableTemp(OwnerMarker()))
         {GlobalVariableSet(K("owner"),0);have_owner=false;return INIT_FAILED;}
         GlobalVariableSet(OwnerMarker(),1);
      }
   }
   if(!have_owner){Print("DemoAutopilot duplicate instance rejected.");return INIT_FAILED;}
   if(!GlobalVariableCheck(K("pause")))GlobalVariableSet(K("pause"),0);
   if(!GlobalVariableCheck(K("halt")))GlobalVariableSet(K("halt"),0);
   if(!GlobalVariableCheck(K("flatten")))GlobalVariableSet(K("flatten"),0);
   for(int i=0;i<2;i++){SymbolSelect(symbols[i],true);attempted[i]=(datetime)GlobalVariableGet(K("bar_"+symbols[i]));}
   if(!EventSetTimer(1))return INIT_FAILED;
   Event("START","",0,"demo login locked; cumulative loss unlimited; risk="+DoubleToString(RiskPercent,2)+"%; auto_entries="+(AutoEntries?"true":"false"));
   Cycle();return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   EventKillTimer();
   if(Owner())
   {
      Event("STOP","",0,"deinit_reason="+IntegerToString(reason));
      GlobalVariableSetOnCondition(K("owner"),0,1);GlobalVariableDel(OwnerMarker());
   }
   ObjectsDeleteAll(0,PREFIX);ChartRedraw();
}
void OnTick(){Cycle();}
void OnTimer(){Cycle();}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
{
   if(id!=CHARTEVENT_OBJECT_CLICK||!Identity()||!Owner())return;
   if(sparam==PREFIX+"pause")
   {
      // Operational faults are not cleared by the ordinary resume button.
      if(GlobalVariableGet(K("halt"))>0){mode="异常仍在，请先检查交易记录";return;}
      GlobalVariableSet(K("pause"),GlobalVariableGet(K("pause"))>0?0:1);
      Event("PAUSE_TOGGLE","",0,GlobalVariableGet(K("pause"))>0?"paused":"resumed");
   }
   if(sparam==PREFIX+"flatten")
   {GlobalVariableSet(K("pause"),1);GlobalVariableSet(K("flatten"),1);Event("USER_FLATTEN","",0,"close only this program's demo orders and remain paused");}
   ObjectSetInteger(0,sparam,OBJPROP_STATE,false);GlobalVariablesFlush();Cycle();
}
