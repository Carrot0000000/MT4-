﻿#ifndef CODEX_DEMO_AUTOPILOT_CORE
#define CODEX_DEMO_AUTOPILOT_CORE
// Pure calculations shared by the EA and the no-order self-test script.
bool APIdentity(const long account_mode,const long login,const string server,const bool testing)
{ return !testing && account_mode==ACCOUNT_TRADE_MODE_DEMO && login==176318407 && server=="MetaQuotes-Demo"; }
bool APFinitePositive(const double x){ return MathIsValidNumber(x) && x>0; }
double APPrice(const double value,const double tick,const int digits,const bool round_up)
{
   if(!APFinitePositive(value)||!APFinitePositive(tick))return 0;
   double units=value/tick;
   return NormalizeDouble((round_up?MathCeil(units-1e-8):MathFloor(units+1e-8))*tick,digits);
}
double APLots(const double budget,const double distance,const double slip,const double tick,
              const double tick_value,const double minimum,const double step,const double maximum,const double fee)
{
   if(!APFinitePositive(budget)||!APFinitePositive(distance)||!APFinitePositive(tick)||
      !APFinitePositive(tick_value)||!APFinitePositive(minimum)||!APFinitePositive(step)||
      !APFinitePositive(maximum)||!MathIsValidNumber(slip)||slip<0||!MathIsValidNumber(fee)||fee<0)return 0;
   double loss_per_lot=(distance+slip)/tick*tick_value+fee;
   double raw=MathMin(maximum,budget/loss_per_lot);
   if(raw<minimum-1e-10)return 0;
   double result=NormalizeDouble(minimum+MathFloor((raw-minimum)/step+1e-9)*step,8);
   // A floating point epsilon must never produce an above-budget position.
   if(result*loss_per_lot>budget+1e-7)result=NormalizeDouble(result-step,8);
   return result>=minimum-1e-10?result:0;
}
double APStop(const double structure,const double atr,const int side,const double spread,
              const double tick,const int digits)
{
   if(!APFinitePositive(structure)||!APFinitePositive(atr)||(side!=1&&side!=-1)||spread<0)return 0;
   return APPrice(structure-side*0.2*atr+(side==-1?spread:0),tick,digits,side==-1);
}
double APBreakEven(const double fill,const double units,const double cost,const double slip,
                   const double tick,const int digits,const int side)
{
   if(!APFinitePositive(fill)||!APFinitePositive(units)||cost<0||slip<0||(side!=1&&side!=-1))return 0;
   return APPrice(fill+side*(cost/units+slip+tick),tick,digits,side==1);
}
double APNet(const int side,const double entry,const double exit,const double units,const double cost)
{ return side*(exit-entry)*units-cost; }
bool APGiveback(const double peak,const double current,const double initial_r)
{ return APFinitePositive(initial_r) && peak>=1.5*initial_r && current<=peak-0.5*initial_r; }
#endif
