"""Native MQL regression suite, with production functions under fake order APIs."""
from pathlib import Path
import re
from build_upgrade_v0_8 import body

ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal'/'MQL4'
source=(ROOT/'staging-v0.8'/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(ROOT/'backup-fp-v0.7'/'Scripts/Codex/AutopilotReviewSuite.mq4').read_text(encoding='utf-8-sig')
test=test.replace('#include <Codex/AutopilotCore.mqh>', '#include <Codex/AutopilotCore.mqh>\n#include <Codex/BudgetAdmission.mqh>')
for name in ['Manage','Cycle']:
    test=test.replace(body(test,name),body(source,name))
test=test.replace('void OnStart(){RunCoreTests();RunExecutionTests();RunAudit();}', '')
test=test.replace('version "1.700"','version "1.800"')
test=test.replace('int exec_passed=0,exec_failed=0;', 'int exec_passed=0,exec_failed=0;string failure_labels="";')
test=test.replace('else{exec_failed++;Print("Execution regression FAILED: ",label);}',
                  'else{exec_failed++;failure_labels+=(failure_labels==""?"":",")+"\\\""+label+"\\\"";Print("Execution regression FAILED: ",label);}')
test=test.replace('"DemoAutopilot\\\\execution-regression.json"','"DemoAutopilot\\\\v08-execution-regression.json"')
test=test.replace('"DemoAutopilot\\\\self-test.json"','"DemoAutopilot\\\\v08-core-test.json"')
test=test.replace('"DemoAutopilot\\\\m5-preflight.json"','"DemoAutopilot\\\\v08-m5-preflight.json"')
stub=r'''
double PracticeCapitalUSD=500,RiskPercent=1,MaximumLots=.01,EntryDriftATR=.25;
const ENUM_TIMEFRAMES ENTRY_TF=PERIOD_M5;
const int ENTRY_SECONDS=300,MAGIC=2026101217;
int EntryWindowSeconds=120,mock_leverage=500,mock_event_count=0,mock_sends=0;
datetime last_draw=0,attempted[2]={0,0};
int admission_codes[2]={0,0},last_codes[2]={0,0},check_counts[2]={0,0};
double admission_floors[2]={-1,-1},minimum_lots[2]={-1,-1};
double last_budgets[2]={-1,-1},last_minimum_risks[2]={-1,-1};
datetime last_bars[2]={0,0},last_local_checks[2]={0,0},last_server_checks[2]={0,0};
string reasons[2]={"",""};
bool mock_connected=true,mock_silver=false;
double mock_commission=0,mock_swap=0,mock_last_tighten=0;
int FakeAccountLeverage(){return mock_leverage;}
double FakeAccountBalance(){return 10000;}
double FakeAccountEquity(){return 10000;}
datetime FakeiTime(const string symbol,const int frame,const int shift)
{return (datetime)((mock_now/(frame*60))*frame*60-shift*frame*60);}
int FakeiBars(const string symbol,const int frame){return 101;}
double FakeiClose(const string symbol,const int frame,const int shift){return 100;}
double FakeiOpen(const string symbol,const int frame,const int shift){return 100;}
double FakeiMA(const string symbol,const int frame,const int period,const int shift,const int method,const int price,const int bar){return 99;}
double FakeiATR(const string symbol,const int frame,const int period,const int bar){return 1;}
double FakeMarketInfo(const string symbol,const int item){return item==MODE_TRADEALLOWED?1:0;}
double FakeAccountFreeMarginCheck(const string symbol,const int type,const double lots){return 500;}
int FakeOrderSend(const string symbol,const int type,const double lots,const double price,const int slip,const double sl,const double tp,const string note,const int magic,const datetime expiry,const color arrow)
{mock_sends++;return -1;}
int Direction(const string symbol){return 1;}
double RecentStructure(const string symbol,const int side){return 99;}
bool EntryJournal(const int index,const int ticket,const int side,const Spec &s,const double lots,const double fill,const double sl,const double tp,const double risk,const double budget){return true;}
'''
test=test.replace('#define GlobalVariableGet',stub+'\n#define GlobalVariableGet',1)
test=test.replace('bool FakeIsConnected(){return true;}', 'bool FakeIsConnected(){return mock_connected;}')
test=test.replace('void Event(const string action,const string symbol,const int ticket,const string details){}',
                  'void Event(const string action,const string symbol,const int ticket,const string details){mock_event_count++;}')
test=test.replace('double FakeOrderCommission(){return 0;}', 'double FakeOrderCommission(){return mock_commission;}')
test=test.replace('double FakeOrderSwap(){return 0;}', 'double FakeOrderSwap(){return mock_swap;}')
test=test.replace('mock_tightens++;return true;', 'mock_tightens++;mock_last_tighten=target;return true;')
test=test.replace('s.bid=mock_bid;s.ask=mock_ask;s.slip=.05;s.digits=2;return mock_fresh;',
                  's.bid=mock_bid;s.ask=mock_ask;s.slip=.05;s.digits=2;\n if(mock_silver){s.tick=.001;s.value=5;s.point=.001;s.spread=.048;s.slip=.02;s.digits=3;}return mock_fresh;')
test=test.replace('vars=0;mock_live=true;', 'vars=0;RoundTripFeePerLotUSD=0;mock_leverage=500;mock_connected=true;mock_silver=false;mock_event_count=0;mock_sends=0;mock_commission=0;mock_swap=0;mock_last_tighten=0;last_draw=0;mock_live=true;')
names='AccountLeverage AccountBalance AccountEquity iTime iBars iClose iOpen iMA iATR MarketInfo AccountFreeMarginCheck OrderSend'.split()
extra='\n'.join('#define '+n+' Fake'+n for n in names)+'\n'
extra+='\n\n'.join(body(source,n) for n in ['DK','CheckOutcome','RefreshAdmission'])+'\n'
test=test.replace('bool ReconcileFlat()\n{',extra+'\nbool ReconcileFlat()\n{',1)
full_entry=body(source,'TryEntry').replace('void TryEntry(', 'void TestProductionTryEntry(',1)
extra_tests=r'''
void RunUpgradeTests()
{
   ResetScenario();RoundTripFeePerLotUSD=7;mock_now=1000;mock_live=false;
   CheckOutcome(0,AP_BUDGET,12.1);
   int events_before=mock_event_count,count_before=check_counts[0];
   mock_now=1001;CheckOutcome(0,AP_BUDGET,15.2);
   ECheck(last_local_checks[0]==1001&&Near(last_minimum_risks[0],15.2),"same refusal refreshes time and risk");
   ECheck(mock_event_count==events_before&&check_counts[0]==count_before,"same refusal does not duplicate event");
   mock_now=1002;CheckOutcome(0,AP_DRIFT);
   ECheck(last_minimum_risks[0]<0&&mock_event_count==events_before+1,"different reason clears obsolete risk and records change");
   ResetScenario();mock_live=false;mock_now=100000;RoundTripFeePerLotUSD=7;mock_silver=true;
   TestProductionTryEntry(1);
   ECheck(last_codes[1]==AP_COST_BUDGET&&mock_sends==0,"real TryEntry blocks unaffordable silver before indicator checks");
   ECheck(Near(admission_floors[1],13.12),"FP silver contract produces correct cost floor");
   mock_silver=false;TestProductionTryEntry(0);
   ECheck(last_codes[0]==AP_TRIGGER&&mock_sends==0,"affordable gold still requires closed-bar momentum signal");
   ResetScenario();quotes_fresh[0]=true;quotes_fresh[1]=true;mock_connected=false;Cycle();
   ECheck(!quotes_fresh[0]&&!quotes_fresh[1]&&mock_sends==0,"disconnect clears stale quote eligibility");
   ResetScenario();mock_leverage=100;Cycle();
   ECheck(mock_closes==1&&mock_entries==0,"unexpected leverage blocks entries but still manages exit");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;mock_commission=-.035;
   mock_bid=106.10;mock_ask=106.12;Manage();
   ECheck(mock_tightens==1&&Near(mock_last_tighten,100.13),"production break-even reserves full round-trip fees");
   ResetScenario();mock_live=false;mock_now=100000;mock_identity=false;
   TestProductionTryEntry(0);ECheck(mock_sends==0,"production entry cannot send on wrong identity");

   ECheck(Near(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,0,.01),2.13),"gold exact cost floor includes tick buffer");
   ECheck(Near(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,500,.01),5.53),"server stop distance contributes to floor");
   ECheck(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,-1,.01)<0,"negative server stop data invalid");
   ECheck(APAdmissionCode(5,5,.01,.01)==0,"budget equality passes necessary condition");
   ECheck(APAdmissionCode(5.0001,5,.01,.01)==AP_COST_BUDGET,"above budget blocked");
   ECheck(APAdmissionCode(1,5,.1,.01)==AP_MINIMUM_VOLUME,"broker minimum cannot override lot cap");
   ECheck(APAdmissionCode(-1,5,.01,.01)==AP_SPEC_INVALID,"unknown risk does not pass");
   ECheck(Near(APConservativeCost(.01,7,-.035,0),.07),"opening-only fee does not understate round trip");
   ECheck(Near(APConservativeCost(.01,7,-.07,0),.07),"posted round-trip fee not double counted");
   ECheck(Near(APConservativeCost(.01,7,-.1,-.02),.12),"higher observed fee plus negative swap respected");
   ECheck(Near(APConservativeCost(.01,7,.01,.02),.07),"rebates do not consume risk reserve");
   ECheck(APConservativeCost(.01,-1,0,0)<0,"invalid fee estimate blocks calculation");
   ECheck(APNextBarSeconds(900,1021,300)==179&&APNextBarSeconds(900,1200,300)==-1,"countdown expires rather than wrapping stale bar");
   ECheck(APNextBarSeconds(900,899,300)==-1,"future bar is not a live countdown");

   // Vary side, structure, spread, and broker stops. A necessary lower bound must
   // never reject a plan accepted by the original sizing + server-distance rules.
   int cases=0,bad=0,admissible=0;
   for(int side=-1;side<=1;side+=2)for(int sp=0;sp<20;sp++)for(int st=0;st<10;st++)for(int bs=0;bs<4;bs++)
   {
      double spread=sp*.03,fill=100,structural=100-side*(.05+st*.4);
      double sl=APCostAwareInitialStop(structural,fill,spread,.2,.01,2,side);
      double distance=side*(fill-sl),server_distance=(bs*100+1)*.01;
      double risk=((distance+.05)/.01+7)*.01;
      double floor=APAdmissionRiskFloor(spread,.2,.05,.01,1,.01,7,bs*100,.01);
      bool old_accept=APLots(5,distance,.05,.01,1,.01,.01,.01,7)>0&&distance-spread>=server_distance-1e-7;
      if(old_accept){admissible++;if(APAdmissionCode(floor,5,.01,.01)!=0)bad++;}
      if(distance-spread>=server_distance-1e-7&&floor>risk+1e-7)bad++;
      cases++;
   }
   ECheck(cases==1600&&admissible>0&&bad==0,"1600 plan cases: preflight preserves all originally admissible plans");
   int f=FileOpen("DemoAutopilot\\v08-upgrade-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"version\":\"0.8\",\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
         ",\"failures\":["+failure_labels+"],\"property_scenarios\":"+IntegerToString(cases)+",\"originally_admissible_scenarios\":"+IntegerToString(admissible)+
         ",\"actual_order_operations\":0}");FileClose(f);
   }
}
'''
test=test.replace('#undef GlobalVariableGet',full_entry+'\n'+extra_tests+'\n'+'\n'.join('#undef '+n for n in names)+'\n#undef GlobalVariableGet',1)
test+='\nvoid OnStart(){RunCoreTests();RunExecutionTests();RunUpgradeTests();Print("V08 native checks finished: ",passed+exec_passed," passed / ",failed+exec_failed," failed; zero real Order APIs invoked.");}\n'
(LIVE/'Scripts/Codex/UpgradeReviewV08.mq4').write_text(test,encoding='utf-8-sig')
print('Generated native tests, all mutation APIs mocked; no live EA replaced.')
