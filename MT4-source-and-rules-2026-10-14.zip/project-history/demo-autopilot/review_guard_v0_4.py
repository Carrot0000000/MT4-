"""Check account isolation, order operations and risk math against v0.3."""
import hashlib
import json
import re
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def body(source, name):
    m = re.search(r"(?m)^(?:bool|int|double|string|void) " + re.escape(name) + r"\(", source)
    if not m:
        raise ValueError(name)
    start = source.index("{", m.end())
    depth = 0
    for i in range(start, len(source)):
        depth += (source[i] == "{") - (source[i] == "}")
        if depth == 0:
            return source[m.start():i+1].replace("\r\n", "\n")
    raise ValueError(name)

functions = {
    "DemoPracticeAutopilot.mq4": ["Identity", "OwnerMarker", "Owner", "MutationAllowed", "ReadSpec",
        "IsOwnedSelected", "OwnedCount", "SyncClosed", "SafeClose", "SafeTighten", "Manage", "OnDeinit", "OnChartEvent"],
    "AutopilotCore.mqh": ["APIdentity", "APFinitePositive", "APPrice", "APLots", "APStop", "APBreakEven", "APNet", "APGiveback"],
}
checks = []
for filename, names in functions.items():
    old = (ROOT / "backup-v0.3" / filename).read_text(encoding="utf-8-sig")
    new = (ROOT / filename).read_text(encoding="utf-8-sig")
    for name in names:
        previous, current = body(old, name), body(new, name)
        allowed = "none"
        if name == "Manage":
            previous = previous.replace('"TIME_EXIT_60_MINUTES"', '"TIME_EXIT_"+IntegerToString(MaximumHoldMinutes)+"_MINUTES"')
            allowed = "log label reports configured timeout; comparison still uses MaximumHoldMinutes"
        checks.append({"file": filename, "function": name, "matches_after_declared_log_change": previous == current,
                       "allowed_change": allowed, "sha256": hashlib.sha256(current.encode()).hexdigest()})
result = {"checks": checks, "all_passed": all(x["matches_after_declared_log_change"] for x in checks),
          "entry_and_initial_stop_changes": "intentional M5 experiment; outside unchanged management/risk-math comparison"}
(ROOT / "guard-review-v0.4.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"checked": len(checks), "all_passed": result["all_passed"]}))
if not result["all_passed"]:
    raise SystemExit("Guard review failed")
