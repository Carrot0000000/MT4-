"""v0.6 adds isolated research; execution functions must match v0.5 exactly."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def body(source,name):
    m=re.search(r'(?m)^(?:bool|int|double|string|void) '+re.escape(name)+r'\(',source)
    start=source.index('{',m.end());depth=0
    for i in range(start,len(source)):
        depth+=(source[i]=='{')-(source[i]=='}')
        if depth==0:return source[m.start():i+1]
    raise ValueError(name)
checks=[]
for filename,names in {
    'DemoPracticeAutopilot.mq4':['Identity','OwnerMarker','Owner','MutationAllowed','ReadSpec','IsOwnedSelected','OwnedCount',
        'ClosedJournalSelected','SyncClosed','ReconcileFlat','EntryGate','SafeClose','SafeTighten','ObserveProtectionSelected','Manage',
        'Direction','RecentStructure','RequestHistory','EntryJournal','TryEntry','OnChartEvent','OnDeinit'],
    'AutopilotCore.mqh':['APIdentity','APFinitePositive','APPrice','APLots','APStop','APBreakEven','APNet','APGiveback',
        'APCooldownReady','APEntryCycleReady','APRetrySeconds','APStickyExit','APBias','APMomentum','APDriftLimit','APCostAwareInitialStop']
}.items():
    old=(ROOT/'backup-v0.5'/filename).read_text(encoding='utf-8-sig');new=(ROOT/filename).read_text(encoding='utf-8-sig')
    for name in names:
        a,b=body(old,name),body(new,name);allow='none'
        if name=='TryEntry':a=a.replace('DemoAutopilot-v0.5','DemoAutopilot-v0.6');allow='order comment version only'
        if name=='OnDeinit':b=b.replace('   FLShutdown();\n','');allow='flush virtual research ledger before shutdown'
        checks.append({'function':name,'passed':a==b,'declared_change':allow})
lab=(ROOT/'ForwardLab.mqh').read_text(encoding='utf-8-sig')+(ROOT/'ForwardCore.mqh').read_text(encoding='utf-8-sig')
checks.append({'function':'research has no order mutation API','passed':re.search(r'\b(?:OrderSend|OrderModify|OrderClose)\s*\(',lab) is None})
ea=(ROOT/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig');cycle=body(ea,'Cycle')
checks.append({'function':'research executes after broker management and entry','passed':cycle.index('Manage();')<cycle.index('TryEntry(i)')<cycle.index('LabCycle();')})
checks.append({'function':'closed-bar inputs and strictly prospective campaign','passed':'bar<=fl_started' in lab and
    re.search(r'\bi(?:Close|Open|Low|High|MA|ATR)\([^;\n]*,0\)',lab) is None})
result={'all_passed':all(c['passed'] for c in checks),'checks':checks,'profitability_validated':False}
(ROOT/'guard-review-v0.6.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checked':len(checks),'all_passed':result['all_passed']}))
if not result['all_passed']:raise SystemExit('Execution isolation regression failed')
