$ErrorActionPreference='Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public static class DemoPortalUi {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr extra);
}
'@
$taskPortalProcess=Get-Process Doubao | Where-Object {$_.MainWindowTitle -match 'FP Markets 中文门户'} | Select-Object -First 1
if(-not $taskPortalProcess){throw 'Expected logged-in portal window missing'}
function Get-DemoPortalRoot {
 $root=[Windows.Automation.AutomationElement]::FromHandle($taskPortalProcess.MainWindowHandle)
 $address=$root.FindFirst([Windows.Automation.TreeScope]::Descendants,[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty,'地址和搜索栏'))
 $url=$address.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern).Current.Value
 if($url -notmatch '^[a-z]+://'){$url='https://'+$url}
 if(([Uri]$url).Host -ne 'portal-cn.fpmarkets.com'){throw 'Unexpected portal host'}
 return $root
}
function Click-DemoPortalElement($element) {
 $null=Get-DemoPortalRoot
 if(-not $element -or $element.Current.IsOffscreen){throw 'Target unavailable'}
 $rect=$element.Current.BoundingRectangle
 if($rect.Width -le 0 -or $rect.Height -le 0){throw 'Empty target bounds'}
 $handle=$taskPortalProcess.MainWindowHandle
 [DemoPortalUi]::ShowWindow($handle,3)|Out-Null
 $pidCheck=[uint32]0
 $fgThread=[DemoPortalUi]::GetWindowThreadProcessId([DemoPortalUi]::GetForegroundWindow(),[ref]$pidCheck)
 $ownThread=[DemoPortalUi]::GetCurrentThreadId()
 $attached=$false
 if($fgThread -ne $ownThread){$attached=[DemoPortalUi]::AttachThreadInput($ownThread,$fgThread,$true)}
 try{[DemoPortalUi]::SetForegroundWindow($handle)|Out-Null}finally{if($attached){[DemoPortalUi]::AttachThreadInput($ownThread,$fgThread,$false)|Out-Null}}
 Start-Sleep -Milliseconds 100
 [DemoPortalUi]::GetWindowThreadProcessId([DemoPortalUi]::GetForegroundWindow(),[ref]$pidCheck)|Out-Null
 if($pidCheck -ne $taskPortalProcess.Id){throw 'Portal not foreground'}
 [DemoPortalUi]::SetCursorPos([int]($rect.X+$rect.Width/2),[int]($rect.Y+$rect.Height/2))|Out-Null
 [DemoPortalUi]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
 [DemoPortalUi]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 250
}
