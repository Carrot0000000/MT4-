"""Reuse the proven virtual journal format; isolate a matched single/dual experiment."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
source=(ROOT/'ForwardLab.mqh').read_text(encoding='utf-8-sig')
def body(name):
    m=re.search(r'(?m)^(?:bool|int|double|string|void) '+name+r'\(',source)
    start=source.index('{',m.end());depth=0
    for i in range(start,len(source)):
        depth+=(source[i]=='{')-(source[i]=='}')
        if depth==0:return source[m.start():i+1]
    raise ValueError(name)
head=r'''
#ifndef CODEX_PORTFOLIO_LAB
#define CODEX_PORTFOLIO_LAB
// Entirely virtual; server order controller retains its one-position limit.
const string PL_PROTOCOL="DUAL07.R1";
const int PL_COLUMNS=53;
FLBook pl_books[3];long pl_campaign=0;
datetime pl_started=0,pl_last_cycle=0,pl_last_status=0,pl_checkpoint=0,pl_calendar=0;
bool pl_initialized=false,pl_fault=false;
string pl_signature="",pl_error="",pl_reasons[3]={"待初始化","待初始化","待初始化"};
string PLPath(const string suffix){return "DemoAutopilot\\dual-v07-"+IntegerToString(pl_campaign)+"-"+suffix;}
string PLParams(){return PL_PROTOCOL+"|shared_total_risk|max_two|h1|"+FLParams();}
void PLFault(const string why){pl_fault=true;pl_error=why;Print("PortfolioLab paused: ",why);}
'''
renames={'FLSave':'PLSave','FLRestore':'PLRestore','FLInitialize':'PLInitialize','FLPath':'PLPath','FLParams':'PLParams','FLFault':'PLFault',
    'FL_PROTOCOL':'PL_PROTOCOL','FL_COLUMNS':'PL_COLUMNS','fl_books':'pl_books','fl_campaign':'pl_campaign','fl_started':'pl_started',
    'fl_initialized':'pl_initialized','fl_fault':'pl_fault','fl_signature':'pl_signature','fl_error':'pl_error','fl_reasons':'pl_reasons'}
copied=[]
for name in ['FLSave','FLRestore','FLInitialize','FLPlan']:
    text=body(name)
    for old,new in renames.items():text=re.sub(r'\b'+old+r'\b',new,text)
    text=text.replace('APL06.176318407.','PPL07.176318407.').replace('lab-v06-campaign.csv','dual-v07-campaign.csv')
    if name=='FLPlan':
        text=text.replace('bool FLPlan(const int model,const int index,const Spec &s,FLBook &p)',
            'bool PLPlan(const int model,const int index,const Spec &s,FLBook &p,const double remaining)')
        text=text.replace('FLDirection(model,','FLDirection(0,')
        text=text.replace('budget=p.cash*RiskPercent/100;','budget=MathMin(p.cash*RiskPercent/100,remaining);')
    copied.append(text)
tail=r'''
double PLDualCash(){return pl_books[0].start+(pl_books[0].cash-pl_books[0].start)+(pl_books[1].cash-pl_books[1].start);}
bool PLMarkPortfolio(const bool dual,double &equity,double &reserved,double &margin)
{
   equity=dual?PLDualCash():pl_books[2].cash;reserved=0;margin=0;
   for(int i=dual?0:2;i<(dual?2:3);i++)if(pl_books[i].active)
   {
      FLBook p=pl_books[i];Spec s;if(!ReadSpec(p.index,s))return false;
      equity+=APNet(p.side,p.fill,p.side==1?s.bid:s.ask,p.units,p.fee)-p.slip*p.units;
      reserved+=p.r;margin+=MarketInfo(symbols[p.index],MODE_MARGINREQUIRED)*p.lots;
   }
   return MathIsValidNumber(equity)&&MathIsValidNumber(reserved)&&MathIsValidNumber(margin);
}
void PLManage(const int slot)
{
   if(!pl_books[slot].active)return;
   FLBook next=pl_books[slot];Spec s;if(!ReadSpec(next.index,s))return;
   FLMark(next,s.bid,s.ask);int why=FLExitChoice(next,s.bid,s.ask,TimeCurrent(),MaximumHoldMinutes);
   if(why!=FL_NONE)
   {
      double exit=FLExitPrice(next,s.bid,s.ask,why),extra=(next.spread+next.slip)*next.units;
      double net=FLFinalize(next,exit,TimeCurrent());
      if(PLSave(slot,next,"CLOSE",net,net-extra,exit,FLExitName(why)))pl_books[slot]=next;
      return;
   }
   double minimum=(MathMax(MarketInfo(symbols[next.index],MODE_STOPLEVEL),MarketInfo(symbols[next.index],MODE_FREEZELEVEL))+1)*s.point;
   bool tightened=FLTighten(next,s.bid,s.ask,s.tick,s.digits,minimum);
   if(tightened&&!PLSave(slot,next,"BE"))return;
   pl_books[slot]=next;
}
bool PLTry(const int slot,const int index,const double cash,const double equity,const double reserved,const double margin_used)
{
   double remaining=PLFreeBudget(cash,equity,RiskPercent,reserved);if(remaining<=0)return false;
   Spec s;if(!ReadSpec(index,s))return false;
   FLBook next=pl_books[slot];double slot_cash=next.cash;next.cash=cash;
   bool okay=PLPlan(slot,index,s,next,remaining);next.cash=slot_cash;
   if(!okay||next.r>remaining+1e-7)return false;
   double new_margin=MarketInfo(symbols[index],MODE_MARGINREQUIRED)*next.lots;
   if(!APFinitePositive(new_margin)||margin_used+new_margin>=equity)return false;
   string context="cash="+FF(cash)+"|equity="+FF(equity)+"|reserved_before="+FF(reserved)+"|remaining="+FF(remaining);
   if(!PLSave(slot,next,"OPEN",0,0,0,context))return false;
   pl_books[slot]=next;return true;
}
void PLPublish()
{
   double dual_eq=0,used=0,margin=0,single_eq=0,single_used=0,single_margin=0;
   bool fresh=PLMarkPortfolio(true,dual_eq,used,margin),single_fresh=PLMarkPortfolio(false,single_eq,single_used,single_margin);
   int positions=(pl_books[0].active?1:0)+(pl_books[1].active?1:0);
   double cash=PLDualCash(),stress=pl_books[0].stress_sum+pl_books[1].stress_sum;
   string json="{\"version\":\"0.7\",\"protocol\":\"DUAL07.R1\",\"campaign\":"+IntegerToString(pl_campaign)+
      ",\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+"\",\"fault\":"+(pl_fault?"true":"false")+
      ",\"error\":\""+Escape(pl_error)+"\",\"actual_order_operations\":0,\"automatic_promotion\":false,"+
      "\"maximum_virtual_positions\":2,\"total_reserved_risk_percent\":"+FF(RiskPercent)+
      ",\"dual_active\":"+IntegerToString(positions)+",\"dual_closed\":"+IntegerToString(pl_books[0].n+pl_books[1].n)+
      ",\"dual_cash\":"+FF(cash)+",\"dual_net\":"+FF(cash-pl_books[0].start)+",\"dual_stress_net\":"+FF(stress)+
      ",\"dual_equity\":"+(fresh?FF(dual_eq):"null")+",\"dual_reserved_risk\":"+(fresh?FF(used):"null")+
      ",\"single_active\":"+(pl_books[2].active?"true":"false")+",\"single_closed\":"+IntegerToString(pl_books[2].n)+
      ",\"single_net\":"+FF(pl_books[2].cash-pl_books[2].start)+",\"single_stress_net\":"+FF(pl_books[2].stress_sum)+
      ",\"single_equity\":"+(single_fresh?FF(single_eq):"null")+"}";
   if(!WriteSnapshot("DemoAutopilot\\portfolio-status.json",json))Print("Portfolio snapshot publish failed; inspect freshness.");
   datetime bar=iTime("XAUUSD",PERIOD_M5,0);
   if(bar<=pl_started||bar==pl_calendar)return;
   int f=FileOpen(PLPath("calendar.csv"),FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE){PLFault("calendar unavailable");return;}
   if(FileSize(f)==0)FileWrite(f,"campaign","bar_server","sample_local","complete","dual_equity","single_equity","dual_active","dual_reserved_risk");
   FileSeek(f,0,SEEK_END);FileWrite(f,pl_campaign,(long)bar,TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS),fresh&&single_fresh?1:0,
      FF(dual_eq),FF(single_eq),positions,FF(used));FileFlush(f);FileClose(f);pl_calendar=bar;
}
void PLShutdown()
{
   if(!pl_initialized||pl_fault||!Identity()||!Owner())return;
   for(int i=0;i<3&&!pl_fault;i++){FLBook next=pl_books[i];if(PLSave(i,next,"SHUTDOWN"))pl_books[i]=next;}
}
void PortfolioCycle()
{
   if(!EnableForwardResearch||!Identity()||!Owner()||!IsConnected()||TimeLocal()==pl_last_cycle)return;
   pl_last_cycle=TimeLocal();if(!pl_initialized&&!pl_fault)PLInitialize();
   if(pl_initialized&&!pl_fault)
   {
      if(pl_signature!=PLParams())PLFault("portfolio parameters changed; registered campaign required");
      else
      {
         bool was_dual=pl_books[0].active||pl_books[1].active,was_single=pl_books[2].active;
         int before=(pl_books[0].active?1:0)+(pl_books[1].active?1:0);
         for(int i=0;i<3&&!pl_fault;i++)PLManage(i);
         int after=(pl_books[0].active?1:0)+(pl_books[1].active?1:0);
         if(!Paused()&&AutoEntries&&!pl_fault)
         {
            datetime last=(datetime)MathMax(pl_books[0].last_close,pl_books[1].last_close);
            if(before==after&&APCooldownReady(TimeCurrent(),last,CooldownMinutes))
            {
               for(int slot=0;slot<2&&!pl_fault;slot++)if(!pl_books[slot].active)
               {
                  double equity=0,used=0,margin=0;
                  if(PLMarkPortfolio(true,equity,used,margin))PLTry(slot,slot,PLDualCash(),equity,used,margin);
               }
            }
            if(!was_single&&!pl_books[2].active&&APCooldownReady(TimeCurrent(),pl_books[2].last_close,CooldownMinutes))
            {
               for(int symbol=0;symbol<2;symbol++)if(PLTry(2,symbol,pl_books[2].cash,pl_books[2].cash,0,0))break;
            }
         }
         if(TimeLocal()-pl_checkpoint>=15)
         {
            for(int i=0;i<3&&!pl_fault;i++)if(pl_books[i].active){FLBook next=pl_books[i];if(PLSave(i,next,"CHECKPOINT"))pl_books[i]=next;}
            pl_checkpoint=TimeLocal();
         }
      }
   }
   if(TimeLocal()-pl_last_status>=5){PLPublish();pl_last_status=TimeLocal();}
}
#endif
'''
(ROOT/'PortfolioLab.mqh').write_text(head+'\n\n'.join(copied)+tail,encoding='utf-8-sig')
print('Generated isolated matched single/dual virtual portfolio experiment.')
