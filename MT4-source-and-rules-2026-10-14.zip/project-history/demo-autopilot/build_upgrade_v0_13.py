"""Apply the latest explicit demo authorization: USD 500 practice base, 3%, USD 15 cap."""
from pathlib import Path
import re,json,shutil,hashlib
from build_upgrade_v0_10 import body
ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal/MQL4'
STAGE=ROOT/'staging-v0.13'
BACKUP=ROOT/'backup-fp-v0.12'

def main():
    STAGE.mkdir(exist_ok=True)
    deployed=(LIVE/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    if 'version "2.200"' not in deployed and not (BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').exists():raise RuntimeError('Expected v0.12')
    for rel in ['Experts/Codex/DemoPracticeAutopilot.mq4','Experts/Codex/DemoPracticeAutopilot.ex4','Include/Codex/AutopilotCore.mqh','Include/Codex/AlignedForward12.mqh','Scripts/Codex/UpgradeReviewV012.mq4','Presets/continuous-demo.set']:
        dest=BACKUP/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copy2(LIVE/rel,dest)
    old=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    src=old.replace('version "2.200"','version "2.300"').replace('v0.12','v0.13').replace('\\"version\\":\\"0.12\\"','\\"version\\":\\"0.13\\"').replace('FileWrite(f,"0.12",ticket>0?','FileWrite(f,"0.13",ticket>0?')
    assert src.count('input double RiskPercent=1;')==1
    src=src.replace('input double RiskPercent=1;','input double RiskPercent=3;')
    src=src.replace('RiskPercent>1||MaximumLots','RiskPercent>3||MaximumLots')
    # Existing experiments continue under their registered 1% budget.
    marker='#include <Codex/ForwardLab.mqh>'
    assert src.count(marker)==1
    src=src.replace(marker,'const double LegacyResearchRiskPercent=1;\n#define RiskPercent LegacyResearchRiskPercent\n'+marker,1)
    src+='\n#undef RiskPercent\n#include <Codex/AlignedForward13.mqh>\n'
    src=src.replace('AlignedCycle12();','AlignedCycle12();AlignedCycle13();')
    src=src.replace('BFShutdown();AFShutdown();','CFShutdown();BFShutdown();AFShutdown();')
    src=src.replace('BFHealthJson()+",\\\"legacy_aligned_forward_health', 'CFHealthJson()+",\\\"previous_admission_forward_health\\\":"+BFHealthJson()+",\\\"legacy_aligned_forward_health')
    src=src.replace('"\\\"risk_percent_basis\\\":\\\"practice_risk_capital\\\",', '"\\\"maximum_lots\\\":"+DoubleToString(MaximumLots,8)+",\\\"risk_percent_basis\\\":\\\"practice_risk_capital\\\",')
    core=(BACKUP/'Include/Codex/AutopilotCore.mqh').read_text(encoding='utf-8-sig')
    assert core.count('percent>1)return 0;')==1
    core=core.replace('percent>1)return 0;','percent>3)return 0;')
    cf=(BACKUP/'Include/Codex/AlignedForward12.mqh').read_text(encoding='utf-8-sig')
    cf=re.sub(r'\bBF(?=[A-Z_])','CF',cf);cf=re.sub(r'\bbf_','cf_',cf)
    cf=cf.replace('AlignedCycle12','AlignedCycle13').replace('CODEX_ALIGNED_FORWARD_V012','CODEX_ALIGNED_FORWARD_V013').replace('ALIGN12.R1','ALIGN13.R1').replace('aligned-v012-','aligned-v013-').replace('AAF12.','AAF13.').replace('\\"version\\":\\"0.12\\"','\\"version\\":\\"0.13\\"')
    preset=(BACKUP/'Presets/continuous-demo.set').read_text(encoding='utf-8-sig')
    assert 'RiskPercent=1' in preset
    preset=preset.replace('RiskPercent=1','RiskPercent=3')
    for name,contents in [('DemoPracticeAutopilot.mq4',src),('AutopilotCore.mqh',core),('AlignedForward13.mqh',cf),('continuous-demo.set',preset)]:
        (STAGE/name).write_text(contents,encoding='ascii' if name.endswith('.set') else 'utf-8-sig')
    # Adding/changing includes cannot alter the already loaded EA executable.
    for name in ['AutopilotCore.mqh','AlignedForward13.mqh']:
        shutil.copy2(STAGE/name,LIVE/'Include/Codex'/name)
    unchanged=['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','SafeClose','SafeTighten','Manage','ReconcileFlat','Direction','RecentStructure','OnChartEvent','RefreshAdmission']
    checks={n:body(old,n)==body(src,n) for n in unchanged}
    checks['TryEntry_only_version_changed']=body(old,'TryEntry').replace('v0.12','v0.13')==body(src,'TryEntry')
    assert all(checks.values()),checks
    (STAGE/'guard-review.json').write_text(json.dumps({'checks':checks,'authorized_maximum_practice_capital_usd':500,'authorized_maximum_risk_percent':3,'maximum_planned_risk_usd':15,'maximum_lots_unchanged':0.01,'actual_single_position_unchanged':True,'legacy_research_percent':1,'latest_user_choice_overrides_50_usd':True},indent=2),encoding='utf-8')
    print('Staged authorized USD 15 demo budget; old research stays at 1%; 14 guards preserved.')
if __name__=='__main__':main()
