"""Prepare the user-requested USD 150 capital; do not deploy before broker reset is verified."""
from pathlib import Path
import re,json,shutil
from build_upgrade_v0_10 import body
ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal/MQL4'
STAGE=ROOT/'staging-v0.14'
BACKUP=ROOT/'backup-fp-v0.13'

def main():
    STAGE.mkdir(exist_ok=True)
    current=(LIVE/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    if 'version "2.300"' not in current and not (BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').exists():raise RuntimeError('Expected current v0.13')
    for rel in ['Experts/Codex/DemoPracticeAutopilot.mq4','Experts/Codex/DemoPracticeAutopilot.ex4','Include/Codex/AlignedForward13.mqh','Scripts/Codex/UpgradeReviewV013.mq4','Presets/continuous-demo.set']:
        target=BACKUP/rel;target.parent.mkdir(parents=True,exist_ok=True)
        if not target.exists():shutil.copy2(LIVE/rel,target)
    old=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    src=old.replace('version "2.300"','version "2.400"').replace('v0.13','v0.14').replace('\\"version\\":\\"0.13\\"','\\"version\\":\\"0.14\\"').replace('FileWrite(f,"0.13",ticket>0?','FileWrite(f,"0.14",ticket>0?')
    src=src.replace('#include <Codex/EntrySlippage.mqh>','#include <Codex/EntrySlippage.mqh>\n#include <Codex/Capital150.mqh>')
    src=src.replace('input double RiskPercent=3;','input double RiskPercent=10;').replace('input double PracticeCapitalUSD=500;','input double PracticeCapitalUSD=150;')
    src=src.replace('PracticeCapitalUSD>500||RiskPercent<=0||RiskPercent>3','PracticeCapitalUSD>150||RiskPercent<=0||RiskPercent>10')
    src=src.replace('APPracticeBudget(', 'APCapital150Budget(')
    # Preserve all historical campaign parameters: 500/1% older books and 500/3% v0.13 books.
    src=src.replace('const double LegacyResearchRiskPercent=1;', 'const double LegacyResearchRiskPercent=1;\nconst double LegacyResearchCapitalUSD=500;\n#define PracticeCapitalUSD LegacyResearchCapitalUSD')
    tail='#undef RiskPercent\n#include <Codex/AlignedForward13.mqh>'
    assert tail in src
    src=src.replace(tail,'#undef RiskPercent\nconst double PreviousResearchRiskPercent=3;\n#define RiskPercent PreviousResearchRiskPercent\n#include <Codex/AlignedForward13.mqh>\n#undef RiskPercent\n#undef PracticeCapitalUSD\n#include <Codex/AlignedForward14.mqh>')
    src=src.replace('AlignedCycle13();','AlignedCycle13();AlignedCycle14();')
    src=src.replace('CFShutdown();BFShutdown();','DFShutdown();CFShutdown();BFShutdown();')
    src=src.replace('CFHealthJson()+",\\\"previous_admission_forward_health', 'DFHealthJson()+",\\\"previous_budget_forward_health\\\":"+CFHealthJson()+",\\\"previous_admission_forward_health')
    src=src.replace('maximum USD 500 practice risk basis','maximum USD 150 practice risk basis')
    df=(BACKUP/'Include/Codex/AlignedForward13.mqh').read_text(encoding='utf-8-sig')
    df=re.sub(r'\bCF(?=[A-Z_])','DF',df);df=re.sub(r'\bcf_','df_',df)
    df=df.replace('AlignedCycle13','AlignedCycle14').replace('CODEX_ALIGNED_FORWARD_V013','CODEX_ALIGNED_FORWARD_V014').replace('ALIGN13.R1','ALIGN14.R1').replace('aligned-v013-','aligned-v014-').replace('AAF13.','AAF14.').replace('\\"version\\":\\"0.13\\"','\\"version\\":\\"0.14\\"')
    df=df.replace('APPracticeBudget(', 'APCapital150Budget(').replace('risk_basis=fixed_cap500','risk_basis=fixed_cap150')
    preset=(BACKUP/'Presets/continuous-demo.set').read_text(encoding='utf-8-sig').replace('RiskPercent=3','RiskPercent=10').replace('PracticeCapitalUSD=500','PracticeCapitalUSD=150')
    checks={n:body(old,n).replace('APPracticeBudget(', 'APCapital150Budget(')==body(src,n) for n in ['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','SafeClose','SafeTighten','Manage','ReconcileFlat','Direction','RecentStructure','OnChartEvent','RefreshAdmission']}
    checks['TryEntry_only_budget_basis_changed']=body(old,'TryEntry').replace('v0.13','v0.14').replace('APPracticeBudget(', 'APCapital150Budget(')==body(src,'TryEntry')
    assert all(checks.values()),checks
    for name,text in [('DemoPracticeAutopilot.mq4',src),('AlignedForward14.mqh',df),('continuous-demo.set',preset)]:
        (STAGE/name).write_text(text,encoding='ascii' if name.endswith('.set') else 'utf-8-sig')
    shutil.copy2(ROOT/'Capital150.mqh',STAGE/'Capital150.mqh')
    # New includes only; the old core, old binary and loaded account inputs remain untouched.
    for name in ['Capital150.mqh','AlignedForward14.mqh']:shutil.copy2(STAGE/name,LIVE/'Include/Codex'/name)
    (STAGE/'guard-review.json').write_text(json.dumps({'checks':checks,'target_server_balance_usd':150,'maximum_planned_risk_usd':15,'practice_capital_usd':150,'risk_percent':10,'deployment_requires_verified_broker_reset':True,'deployed':False},indent=2),encoding='utf-8')
    print('Prepared only: USD 150 capital, unchanged USD 15 risk. Broker reset still required before deployment.')
if __name__=='__main__':main()
