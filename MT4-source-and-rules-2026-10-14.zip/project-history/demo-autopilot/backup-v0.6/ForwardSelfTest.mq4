#property strict
#property version "1.600"
#include <Codex/AutopilotCore.mqh>
#include <Codex/ForwardCore.mqh>
// Read-only script: fake books and isolated fixture file; never executes terminal orders.
bool AutoEntries=false,EnableForwardResearch=true;
double RiskPercent=1,MaximumLots=.01,RoundTripFeePerLotUSD=0,MaxSpreadFraction=.2,EntryDriftATR=.25;
int MaximumHoldMinutes=20,CooldownMinutes=5,EntryWindowSeconds=120;
string symbols[2]={"XAUUSD","XAGUSD"};
struct Spec{double tick,value,point,minimum,step,maximum,spread,bid,ask,slip;int digits;};
bool Identity(){return APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())&&AccountCurrency()=="USD";}
bool Owner(){return true;}
bool Paused(){return true;}
bool ReadSpec(const int index,Spec &s){return false;}
double RecentStructure(const string symbol,const int side){return 0;}
string Escape(string s){StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");return s;}
#include <Codex/ForwardLab.mqh>
int fl_test_passed=0,fl_test_failed=0;
void FC(const bool okay,const string label)
{if(okay)fl_test_passed++;else{fl_test_failed++;Print("Forward test FAILED: ",label);}}
bool FN(const double a,const double b){return MathAbs(a-b)<1e-8;}
void TestPosition(FLBook &p,const int side=1)
{
   FLInit(p,500);p.active=true;p.index=0;p.side=side;p.opened=1000;p.fill=100;
   p.sl=side==1?95:105;p.initial_sl=p.sl;p.tp=side==1?110:90;p.lots=.01;p.units=1;p.r=5.05;p.slip=.05;p.spread=.20;
}
void OnStart()
{
   for(int wait=0;wait<75;wait++){if(Identity()&&IsConnected()&&APFinitePositive(AccountBalance()))break;Sleep(200);}
   FC(FLFastBias(101,100,99)==1,"closed M15 rising long");
   FC(FLFastBias(99,100,101)==-1,"closed M15 falling short");
   FC(FLFastBias(101,100,101)==0,"price above falling EMA not forced long");
   FC(FLFastBias(0,100,99)==0,"missing M15 data blocked");
   FC(FLDirection(0,-1,1)==-1&&FLDirection(1,-1,1)==1,"baseline and candidate separated");
   FC(FLDirection(2,-1,1)==0&&FLDirection(2,1,1)==1,"consensus rejects disagreement");
   FC(FN(FLScore(1),.5)&&FN(FLScore(-1),-.5),"symmetric bounded score");
   FC(FLScore(-1000)>-1&&FLScore(-1000)<-.99,"large gap loss retained with bounded statistic");
   FC(FN(FLLogMixture(0,0,0),0),"empty evidence starts at one");
   FC(FN(FLLogMixture(1000,1000,1000),1000),"log mixture stable beyond exponential overflow");
   FC(FN(FLPosteriorMean(0,0),.5),"no data remains a prior");
   FC(FN(FLPosteriorMean(2,8),.3),"Beta prior shrinkage");
   FC(FLPosteriorMean(9,8)<0,"invalid win counts rejected");
   FLBook p;TestPosition(p);FC(FLStateValid(p),"valid virtual protected position");
   FC(FLExitChoice(p,94,94.2,1001,20)==FL_STOP,"stop uses executable Bid");
   FC(FN(FLExitPrice(p,94,94.2,FL_STOP),93.95),"gap never invents fill at old stop");
   FC(FLExitChoice(p,115,115.2,1001,20)==FL_TARGET,"target trigger");
   FC(FN(FLExitPrice(p,115,115.2,FL_TARGET),110),"limit target caps favorable gap");
   FC(FLExitChoice(p,101,101.2,2199,20)==FL_NONE,"hold before boundary");
   FC(FLExitChoice(p,101,101.2,2200,20)==FL_TIME,"20 minute boundary");
   p.peak=8;FC(FLExitChoice(p,105.4,105.6,1001,20)==FL_GIVEBACK,"same giveback threshold as active EA");
   TestPosition(p);FC(FLTighten(p,106,106.2,.01,2,.02)&&FN(p.sl,100.06),"economic buy breakeven");
   FC(!FLTighten(p,106,106.2,.01,2,.02),"existing stop never widened or resent unchanged");
   TestPosition(p,-1);FC(FLTighten(p,93.8,94,.01,2,.02)&&FN(p.sl,99.94),"economic short breakeven");
   TestPosition(p);p.r=.01;FC(!FLTighten(p,100.07,100.09,.01,2,.02),"broker distance blocks invalid tightening");
   TestPosition(p);double net=FLFinalize(p,93.95,1001);
   FC(FN(net,-6.05)&&FN(p.cash,493.95)&&p.n==1&&p.wins==0,"gap loss not clipped in cash or counts");
   FC(FN(p.stress_sum,-6.30),"stress adds one spread and one slip reserve");
   FC(p.log0<0&&p.log1<0&&p.log2<0,"loss reduces evidence");
   FC(!p.active&&p.last_close==1001,"close state and cooldown retained");
   TestPosition(p);FLMark(p,94,94.2);FC(p.max_drawdown>=6.05-1e-8,"observed mark drawdown includes exit reserve");
   TestPosition(p);p.r=0;FC(!FLStateValid(p),"missing reserved risk invalid");
   TestPosition(p);p.wins=2;p.n=1;FC(!FLStateValid(p),"corrupt counts invalid");
   FC(FLNumberToken("-0.125")&&FLNumberToken("123456"),"numeric restore tokens");
   FC(!FLNumberToken("NaN")&&!FLNumberToken("1..2")&&!FLNumberToken(""),"corrupt numeric tokens blocked");

   // Actual FileWrite/FileReadString round trip exercises the production journal recovery.
   fl_campaign=9000000000+(long)TimeLocal();fl_signature=FLParams();fl_fault=false;
   for(int m=0;m<3;m++)FLInit(fl_books[m],500);
   TestPosition(p);p.m15_close=101;p.m15_ema=100;p.m15_previous_ema=99;
   bool write_open=FLSave(0,p,"OPEN");FLFinalize(p,102,1100);bool write_close=FLSave(0,p,"CLOSE",2.00,1.75,102,"TIME");
   FC(write_open&&write_close,"native fixture writes completed");
   for(int m=0;m<3;m++)FLInit(fl_books[m],500);
   FC(FLRestore()&&!fl_fault,"native ledger restored without order operations");
   FC(fl_books[0].seq==2&&fl_books[0].n==1&&fl_books[0].wins==1&&FN(fl_books[0].cash,502),"cash and counts recover exactly");
   FC(FN(fl_books[0].log1,p.log1)&&FN(fl_books[0].m15_ema,100),"evidence and causal features recover");
   fl_signature+="|changed";fl_fault=false;FC(!FLRestore()&&fl_fault,"parameter change cannot mix campaigns");
   fl_signature=FLParams();fl_fault=false;for(int m=0;m<3;m++)FLInit(fl_books[m],500);
   int broken=FileOpen(FLPath("ledger.csv"),FILE_READ|FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(broken!=INVALID_HANDLE){FileSeek(broken,0,SEEK_END);FileWriteString(broken,"partial,row\r\n");FileClose(broken);}
   FC(!FLRestore()&&fl_fault,"partial crash row stops research rather than resetting losses");
   FileDelete(FLPath("ledger.csv"));
   int f=FileOpen("DemoAutopilot\\forward-self-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(fl_test_passed)+",\"failed\":"+IntegerToString(fl_test_failed)+
      ",\"actual_order_operations\":0,\"native_ledger_roundtrip_tested\":true,\"expected_demo\":"+(Identity()?"true":"false")+"}");FileClose(f);}
}
