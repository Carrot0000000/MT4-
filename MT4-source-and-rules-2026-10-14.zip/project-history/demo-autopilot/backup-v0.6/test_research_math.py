import itertools,math,unittest
import numpy as np
from research_math import beta_cdf_integer,beta_quantile,posterior,bounded_score,evidence_from_returns,log_mixture,moving_block_intervals

class ResearchMathTests(unittest.TestCase):
    def test_beta_analytic_uniform(self):
        for x in (.01,.2,.5,.9):self.assertAlmostEqual(beta_cdf_integer(x,1,1),x,places=12)
        self.assertAlmostEqual(beta_quantile(.025,1,1),.025,places=12)
    def test_beta_analytic_polynomial(self):
        for x in (.1,.3,.8):self.assertAlmostEqual(beta_cdf_integer(x,2,2),3*x*x-2*x*x*x,places=12)
    def test_small_sample_uncertainty(self):
        p=posterior(2,8);self.assertAlmostEqual(p['mean'],.3)
        self.assertLess(p['credible_interval_95'][0],.1);self.assertGreater(p['credible_interval_95'][1],.55)
    def test_corrupt_counts(self):
        with self.assertRaises(ValueError):posterior(5,4)
    def test_utility_does_not_imply_profit(self):
        returns=[.5]*9+[-10]
        self.assertLess(sum(returns),0);self.assertGreater(sum(map(bounded_score,returns)),0)
        self.assertFalse(evidence_from_returns(returns)['raw_profit_mean_test'])
    def test_log_mixture_overflow_stability(self):self.assertAlmostEqual(log_mixture([1000]*3),1000)
    def test_wealth_equals_direct_product(self):
        r=[-1,2,.5,-2,1];expected=np.mean([np.prod([1+lam*bounded_score(x) for x in r]) for lam in (.1,.25,.5)])
        self.assertAlmostEqual(evidence_from_returns(r)['e'],expected,places=12)
    def test_exact_fair_null_and_optional_peeking(self):
        # Exhaust all 2^12 bounded fair-score paths; verify E_n expectation and crossing probability.
        finals=[];crossings=0
        for path in itertools.product((-1.,1.),repeat=12):
            wealth=np.ones(3);cross=False
            for z in path:
                wealth*=1+np.array((.1,.25,.5))*z
                cross|=wealth.mean()>=60
            finals.append(wealth.mean());crossings+=cross
        self.assertAlmostEqual(np.mean(finals),1,places=12)
        self.assertLessEqual(crossings/len(finals),1/60)
    def test_small_calendar_not_certified(self):self.assertFalse(moving_block_intervals([])['intervals_available'])
    def rows(self,n):
        rows=[]
        for i in range(n):
            r={'bar_server':str(1000+300*i),'complete':'1'}
            for k in ('h1_equity','m15_equity','agree_equity','h1_stress_equity','m15_stress_equity','agree_stress_equity'):r[k]=str(500+i*.1)
            rows.append(r)
        return rows
    def test_identical_policies_no_fake_superiority(self):
        r=moving_block_intervals(self.rows(65),repetitions=200)
        self.assertTrue(r['intervals_available'])
        for trial in r['block_length_sensitivity']:self.assertTrue(np.allclose(trial['bootstrap_percentile_97_5_intervals'],0))
    def test_data_gaps_and_incomplete_quotes_not_imputed(self):
        rows=self.rows(62);rows[2]['complete']='0';rows[30]['bar_server']=str(int(rows[30]['bar_server'])+20)
        self.assertFalse(moving_block_intervals(rows)['intervals_available'])
    def test_restart_duplicate_does_not_choose_favorable_mark(self):
        rows=self.rows(65);extra=dict(rows[20]);extra['m15_equity']='1000000'
        r=moving_block_intervals(rows+[extra],repetitions=100)
        for t in r['block_length_sensitivity']:self.assertTrue(np.allclose(t['paired_mean_delta_usd_per_5m'],0))

if __name__=='__main__':unittest.main()
