"""Retain v0.13 tests and directly exercise the prepared USD 150 production entry functions."""
from prepare_capital150_v0_14 import ROOT,LIVE,STAGE,BACKUP,body
src=(STAGE/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
test=(BACKUP/'Scripts/Codex/UpgradeReviewV013.mq4').read_text(encoding='utf-8-sig')
test=test.replace('version "2.300"','version "2.400"').replace('v013-','v014-')
test=test.replace('#include <Codex/EntrySlippage.mqh>','#include <Codex/EntrySlippage.mqh>\n#include <Codex/Capital150.mqh>')
helpers=body(src,'CheckOutcome').replace('void CheckOutcome(', 'void CheckOutcome150(',1)+'\n'+body(src,'RefreshAdmission').replace('void RefreshAdmission(', 'void RefreshAdmission150(',1)
entry=body(src,'TryEntry').replace('void TryEntry(', 'void TestProductionTryEntry150(',1).replace('CheckOutcome(', 'CheckOutcome150(').replace('RefreshAdmission(', 'RefreshAdmission150(')
new=r'''
void RunCapital150Tests()
{
   ECheck(Near(APCapital150Budget(150,150,150,10),15),"150 broker cash preserves requested fifteen dollar ceiling");
   ECheck(Near(APCapital150Budget(10000,10000,150,10),15),"large broker account cannot inflate a 150 dollar practice budget");
   ECheck(Near(APCapital150Budget(135,130,150,10),13),"lower broker equity reduces risk after losses");
   ECheck(APCapital150Budget(150,150,500,10)==0&&APCapital150Budget(150,150,150,10.01)==0,"wrong capital and higher percent cannot exceed fifteen dollars");
   ECheck(APCapital150Budget(0,150,150,10)==0&&APCapital150Budget(150,0,150,10)==0,"depleted capital or equity blocks new entry");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();PracticeCapitalUSD=150;RiskPercent=10;RoundTripFeePerLotUSD=7;mock_balance=150;mock_aligned_signal=true;
      mock_now=2420;mock_live=false;mock_closed=0;mock_silver=true;mock_bid=100;mock_ask=100.048;
      mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry150(1);
      ECheck(mock_sends==1&&Near(last_budgets[1],15)&&Near(last_minimum_risks[1],14.97),"prepared silver buy and sell preserve fifteen dollar admission with 150 cash");
      ResetScenario();PracticeCapitalUSD=150;RiskPercent=10;RoundTripFeePerLotUSD=7;mock_balance=150;mock_aligned_signal=true;
      mock_now=2420;mock_live=false;mock_closed=0;mock_silver=true;mock_bid=100;mock_ask=100.048;
      mock_direction=side;mock_structure=side==1?99.5:100.5;attempted[1]=0;
      TestProductionTryEntry150(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_BUDGET,"prepared larger structural silver risk remains blocked");
   }
   int f=FileOpen("DemoAutopilot\\v014-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"prepared_capital_usd\":150,\"maximum_risk_usd\":15,\"deployed\":false}");FileClose(f);}
   PracticeCapitalUSD=500;RiskPercent=1;
}
'''
test=test.replace('#undef OrderClosePrice',helpers+'\n'+entry+'\n'+new+'\n#undef OrderClosePrice',1)
test=test.replace('RunAuthorizedBudgetTests();Print(', 'RunAuthorizedBudgetTests();RunCapital150Tests();Print(')
(LIVE/'Scripts/Codex/UpgradeReviewV014.mq4').write_text(test,encoding='utf-8-sig')
print('Prepared native capital-150 regression; no broker or account balance mutations.')
