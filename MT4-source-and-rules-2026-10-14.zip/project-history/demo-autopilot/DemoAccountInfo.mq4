#property strict
#property version "1.000"
#include <Codex/AutopilotCore.mqh>
#include <Codex/SnapshotWriter.mqh>
// Read-only account inspection. No order, account switch, or leverage mutation.
void OnStart()
{
   if(!APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())||AccountCurrency()!="USD"||!IsConnected())return;
   string json="{\"login\":"+IntegerToString(AccountNumber())+",\"server\":\""+AccountServer()+"\",\"demo\":true,"+
      "\"leverage\":"+IntegerToString(AccountLeverage())+",\"balance\":"+DoubleToString(AccountBalance(),2)+
      ",\"margin\":"+DoubleToString(AccountMargin(),2)+",\"free_margin\":"+DoubleToString(AccountFreeMargin(),2)+
      ",\"open_orders\":"+IntegerToString(OrdersTotal())+",\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+"\",\"order_operations\":0}";
   WriteSnapshot("DemoAutopilot\\account-info.json",json);
}
