"""Prepare the authorized FP demo migration in its separate terminal data folder."""
from pathlib import Path

root = Path(__file__).resolve().parent
target = root / "fp-demo-terminal" / "MQL4"
includes = target / "Include" / "Codex"
experts = target / "Experts" / "Codex"
scripts = target / "Scripts" / "Codex"
deployed = experts / "DemoPracticeAutopilot.mq4"
if deployed.exists() and any(marker in deployed.read_text(encoding="utf-8-sig") for marker in ('version "1.800"','version "1.900"')):
    raise SystemExit("Migration already completed and upgraded; use the current upgrade builder. Refusing to overwrite it with v0.7.")
for directory in (includes, experts, scripts, target / "Presets"):
    directory.mkdir(parents=True, exist_ok=True)

def migrate(text):
    return text.replace("176318407", "48530368").replace("MetaQuotes-Demo", "FPMarketsLtd-Demo2")

for name in ("AutopilotCore.mqh", "ForwardCore.mqh", "ResearchStats.mqh", "SnapshotWriter.mqh",
             "ForwardLab.mqh", "PortfolioLab.mqh", "PortfolioAdmissionTests.mqh"):
    text = migrate((root / name).read_text(encoding="utf-8-sig"))
    if name == "AutopilotCore.mqh":
        text = text.replace("bool APFinitePositive", """// A large broker demo balance must not silently raise the agreed practice risk.
double APPracticeBudget(const double balance,const double equity,const double capital,const double percent)
{
   if(!MathIsValidNumber(balance)||!MathIsValidNumber(equity)||!MathIsValidNumber(capital)||
      !MathIsValidNumber(percent)||balance<=0||equity<=0||capital<=0||capital>500||percent<=0||percent>1)return 0;
   return MathMin(capital,MathMin(balance,equity))*percent/100;
}
bool APFinitePositive""", 1)
    if name in ("ForwardLab.mqh", "PortfolioLab.mqh"):
        text = text.replace("FLInit(fl_books[i],AccountBalance())", "FLInit(fl_books[i],MathMin(PracticeCapitalUSD,AccountBalance()))")
        text = text.replace("FLInit(pl_books[i],AccountBalance())", "FLInit(pl_books[i],MathMin(PracticeCapitalUSD,AccountBalance()))")
    if name == "ForwardLab.mqh":
        text = text.replace('return FL_PROTOCOL+"|risk="', 'return FL_PROTOCOL+"|login=48530368|server=FPMarketsLtd-Demo2|practice_capital="+DoubleToString(PracticeCapitalUSD,8)+"|risk="')
    (includes / name).write_text(text, encoding="utf-8-sig")

text = migrate((root / "DemoPracticeAutopilot.mq4").read_text(encoding="utf-8-sig"))
text = text.replace('version "1.700"', 'version "1.701"')
text = text.replace("one MetaQuotes DEMO login", "one FP Markets DEMO login; maximum USD 500 practice risk basis")
text = text.replace("input double RiskPercent=1;", "input double RiskPercent=1;\ninput double PracticeCapitalUSD=500;")
text = text.replace("input double RoundTripFeePerLotUSD=0;", "input double RoundTripFeePerLotUSD=7; // Conservative fee estimate until account costs are verified.")
old_budget = "MathMin(AccountBalance(),AccountEquity())*RiskPercent/100"
assert text.count(old_budget) == 3
text = text.replace(old_budget, "APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent)")
text = text.replace('Label("title","频繁模拟练习 v0.7  |  "+mode,30);', 'Label("title","模拟练习 v0.7  |  杠杆1:"+IntegerToString(AccountLeverage())+"  |  "+mode,30);')
old_label = 'Label("balance",Identity()?"余额 "+DoubleToString(AccountBalance(),2)+" USD  |  预留风险 "+DoubleToString(RiskPercent,2)+"% / "+DoubleToString(APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),2):"账户不匹配：禁止任何交易",57);'
new_label = 'Label("balance",Identity()?"模拟余额 "+DoubleToString(AccountBalance(),2)+" |  练习预算 "+DoubleToString(PracticeCapitalUSD,0)+" |  单笔风险≤"+DoubleToString(APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),2)+" USD":"账户不匹配：禁止任何交易",57);'
assert old_label in text
text = text.replace(old_label, new_label)
text = text.replace('else if(!AutoEntries||Paused())mode=', 'else if(AccountLeverage()!=500)mode="杠杆不是1:500，暂停新单";\n      else if(!AutoEntries||Paused())mode=')
text = text.replace('if(RiskPercent<=0||RiskPercent>1||', 'if(PracticeCapitalUSD<=0||PracticeCapitalUSD>500||RiskPercent<=0||RiskPercent>1||')
needle = '      ",\\\"cumulative_loss_cap\\\":null'
extra = '''      ",\\\"login\\\":"+IntegerToString(AccountNumber())+",\\\"server\\\":\\\""+AccountServer()+"\\\",\\\"leverage\\\":"+IntegerToString(AccountLeverage())+
      ",\\\"practice_risk_capital_usd\\\":"+DoubleToString(PracticeCapitalUSD,2)+",\\\"maximum_planned_risk_usd\\\":"+DoubleToString(APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),4)+
      ",\\\"risk_percent_basis\\\":\\\"practice_risk_capital\\\",\\\"round_trip_fee_estimate_per_lot_usd\\\":"+DoubleToString(RoundTripFeePerLotUSD,2)+
'''
assert needle in text
text = text.replace(needle, extra + needle)
(experts / "DemoPracticeAutopilot.mq4").write_text(text, encoding="utf-8-sig")

for name in ("AutopilotSelfTest.mq4", "AutopilotReviewSuite.mq4", "ForwardSelfTest.mq4"):
    text = migrate((root / name).read_text(encoding="utf-8-sig"))
    if name == "ForwardSelfTest.mq4":
        text = text.replace("double RiskPercent=1,", "double PracticeCapitalUSD=500;\ndouble RiskPercent=1,")
    text = text.replace('#include "AutopilotCore.mqh"', '#include <Codex/AutopilotCore.mqh>')
    if name != "ForwardSelfTest.mq4":
        text = text.replace('   Check(APIdentity(', '''   Check(Near(APPracticeBudget(10000,10000,500,1),5),"large broker demo balance remains at five dollar risk");
   Check(Near(APPracticeBudget(500,480,500,1),4.8),"smaller broker equity reduces risk budget");
   Check(APPracticeBudget(10000,10000,501,1)==0,"practice capital above authorized cap rejected");
   Check(APPracticeBudget(10000,10000,500,1.01)==0,"risk percent above one rejected");
   Check(APPracticeBudget(10000,0,500,1)==0,"zero equity blocks budget");
   Check(APPracticeBudget(10000,10000,0,1)==0,"zero practice capital blocks budget");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",false),"old login remains isolated");
   Check(APIdentity(''', 1)
    (scripts / name).write_text(text, encoding="utf-8-sig")

for name in ("continuous-demo.set", "observe-demo.set"):
    text = (root / name).read_text(encoding="ascii")
    text = text.replace("RiskPercent=1", "RiskPercent=1\nPracticeCapitalUSD=500")
    text = text.replace("RoundTripFeePerLotUSD=0", "RoundTripFeePerLotUSD=7")
    (target / "Presets" / name).write_text(text, encoding="ascii")

print("Prepared strict demo login 48530368; practice risk at most USD 5; no terminal started and no orders sent.")
