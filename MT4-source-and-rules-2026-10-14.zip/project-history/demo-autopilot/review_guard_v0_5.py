"""Verify isolation/risk math and signal calculations against the frozen v0.4 source.

Changed close, management and reconciliation functions are exercised separately by
the native mock execution suite; they are not claimed to be unchanged.
"""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def body(source, name):
    m = re.search(r'(?m)^(?:bool|int|double|string|void) '+re.escape(name)+r'\(', source)
    start = source.index('{', m.end())
    depth = 0
    for i in range(start, len(source)):
        depth += (source[i] == '{') - (source[i] == '}')
        if depth == 0:
            return source[m.start():i+1]
    raise ValueError(name)

checks = []
for filename, names in {
    'DemoPracticeAutopilot.mq4': ['Identity','OwnerMarker','Owner','MutationAllowed','ReadSpec',
        'IsOwnedSelected','OwnedCount','Direction','RecentStructure','RequestHistory','OnDeinit','OnChartEvent'],
    'AutopilotCore.mqh': ['APIdentity','APFinitePositive','APPrice','APLots','APStop','APBreakEven','APNet','APGiveback',
        'APEntryWindow','APBias','APMomentum','APRangeExtreme','APDriftLimit','APCostAwareInitialStop']
}.items():
    old = (ROOT/'backup-v0.4'/filename).read_text(encoding='utf-8-sig')
    new = (ROOT/filename).read_text(encoding='utf-8-sig')
    for name in names:
        previous, current = body(old,name), body(new,name)
        checks.append({'function':name,'unchanged':previous==current,'sha256':hashlib.sha256(current.encode()).hexdigest()})
old_ea = (ROOT/'backup-v0.4'/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
new_ea = (ROOT/'DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
old_entry,new_entry = body(old_ea,'TryEntry'),body(new_ea,'TryEntry')
def signal_part(text):
    return text[text.index('   string symbol='):text.index('   if(!MutationAllowed()')]
checks.append({'function':'TryEntry signal, initial SL/TP, sizing and margin calculations','unchanged':signal_part(old_entry)==signal_part(new_entry)})
checks.append({'function':'TryEntry final gate immediately before protected send','unchanged':
    'if(!MutationAllowed()||!EntryGate())return;\n   ResetLastError();int ticket=OrderSend' in new_entry
    and 'lots,fill,SlippagePoints,sl,tp,' in new_entry})
result={'all_passed':all(c['unchanged'] for c in checks),'checks':checks,
    'intentional_changes':['accepted close immediately persists cooldown','vanished ticket reconciliation',
        'sticky exit with fresh quotes and bounded retries','observed excursion and structured journal',
        'SL/TP edits outside EA separately flagged'], 'profitability_validated':False}
(ROOT/'guard-review-v0.5.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checked':len(checks),'all_passed':result['all_passed']}))
if not result['all_passed']: raise SystemExit('Guard regression failed')
