"""Stage research alignment and execution-quality instrumentation; never promote a strategy."""
from pathlib import Path
import shutil,json,re,hashlib
from build_upgrade_v0_10 import body
from build_aligned_forward_v0_11 import main as build_aligned
ROOT=Path(__file__).resolve().parent
LIVE=ROOT/'fp-demo-terminal/MQL4'
STAGE=ROOT/'staging-v0.11'
BACKUP=ROOT/'backup-fp-v0.10'

def main():
    STAGE.mkdir(exist_ok=True)
    current=(LIVE/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    if 'version "2.000"' not in current and not (BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').exists():
        raise RuntimeError('Expected deployed v0.10 before backup')
    for rel in ['Experts/Codex/DemoPracticeAutopilot.mq4','Experts/Codex/DemoPracticeAutopilot.ex4','Scripts/Codex/UpgradeReviewV010.mq4','Presets/continuous-demo.set']:
        dest=BACKUP/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copy2(LIVE/rel,dest)
    build_aligned()
    old=(BACKUP/'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    src=old.replace('version "2.000"','version "2.100"').replace('v0.10','v0.11').replace('\\"version\\":\\"0.10\\"','\\"version\\":\\"0.11\\"').replace('FileWrite(f,"0.10",ticket>0?','FileWrite(f,"0.11",ticket>0?')
    src=src.replace('#include <Codex/ExecutionTiming.mqh>','#include <Codex/ExecutionTiming.mqh>\n#include <Codex/ExecutionQuality.mqh>')
    def change(a,b):
        nonlocal src
        assert src.count(a)==1,(a[:80],src.count(a))
        src=src.replace(a,b)
    change('   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();',
           '   int eq_side=OrderType()==OP_BUY?1:-1;uint eq_started=GetTickCount();\n   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();\n   uint eq_elapsed=(uint)(GetTickCount()-eq_started);double eq_actual=0;')
    change('      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0)closed=OrderCloseTime();',
           '      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0){closed=OrderCloseTime();eq_actual=OrderClosePrice();}')
    change('   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,ExitReasonText(intent)+" error="+IntegerToString(error));',
           '   EQRecord(false,symbol,ticket,eq_side,lots,price,eq_actual,ok,error,eq_elapsed,s.spread,lots*s.value/s.tick);\n   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,ExitReasonText(intent)+" error="+IntegerToString(error));')
    change('   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.11",MAGIC,0,clrNONE);\n   int error=GetLastError();',
           '   uint eq_started=GetTickCount();\n   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.11",MAGIC,0,clrNONE);\n   int error=GetLastError();uint eq_elapsed=(uint)(GetTickCount()-eq_started);')
    change('      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));',
           '      EQRecord(true,symbol,0,side,lots,fill,0,false,error,eq_elapsed,s.spread,lots*s.value/s.tick);\n      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));')
    change('   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)',
           '   double eq_actual_fill=OrderOpenPrice(),eq_actual_lots=OrderLots();\n   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)')
    change('   CheckOutcome(index,AP_FILLED,minimum_risk,true);',
           '   EQRecord(true,symbol,ticket,side,eq_actual_lots,fill,eq_actual_fill,true,0,eq_elapsed,s.spread,eq_actual_lots*s.value/s.tick);\n   CheckOutcome(index,AP_FILLED,minimum_risk,true);')
    change('   if(working)return;working=true;closed_this_cycle=false;',
           '   if(working)return;working=true;closed_this_cycle=false;uint eq_cycle_start=GetTickCount();')
    change('   LabCycle();EPCycle();','   LabCycle();EPCycle();AlignedCycle();')
    change('   working=false;','   eq_cycle_last_ms=(uint)(GetTickCount()-eq_cycle_start);if(eq_cycle_last_ms>eq_cycle_max_ms)eq_cycle_max_ms=eq_cycle_last_ms;\n   working=false;')
    change('   EPShutdown();FLShutdown();','   AFShutdown();EPShutdown();FLShutdown();')
    change('      "\\\"execution_retry_policy\\\":', '      "\\\"aligned_forward_enabled\\\":"+(EnableForwardResearch?"true":"false")+",\\\"execution_quality\\\":"+EQJson()+","+\n      "\\\"execution_retry_policy\\\":')
    change('IntegerToString(next%60):"等待行情恢复"),181);',
           'IntegerToString(next%60):"等待行情恢复")+(EQPingMs()>0?" | 网络 "+DoubleToString(EQPingMs(),0)+"ms":""),181);')
    src+='\n#include <Codex/AlignedForward.mqh>\n'
    src=src.replace('EQJson()+","+', 'EQJson()+",\\\"aligned_forward_health\\\":"+AFHealthJson()+","+')
    def strip_instrumentation(s):
        s=s.replace('v0.10','v0.11')
        s=s.replace('if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0){closed=OrderCloseTime();eq_actual=OrderClosePrice();}',
                    'if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0)closed=OrderCloseTime();')
        s=re.sub(r';uint eq_elapsed=\(uint\)\(GetTickCount\(\)-eq_started\);',';',s)
        lines=[line for line in s.splitlines() if not any(x in line for x in ('EQRecord(', 'uint eq_started=', 'uint eq_elapsed=', 'int eq_side=', 'double eq_actual_fill='))]
        return '\n'.join(lines)
    names=['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','ReconcileFlat','SafeTighten','Manage','Direction','RecentStructure','OnChartEvent','RefreshAdmission']
    checks={name:body(old,name)==body(src,name) for name in names}
    for name in ['SafeClose','TryEntry']:checks[name+'_only_observation_hooks']=strip_instrumentation(body(old,name))==strip_instrumentation(body(src,name))
    assert all(checks.values()),checks
    (STAGE/'DemoPracticeAutopilot.mq4').write_text(src,encoding='utf-8-sig')
    for name in ['ExecutionQuality.mqh','AlignedForward.mqh']:
        shutil.copy2(ROOT/name,STAGE/name);shutil.copy2(ROOT/name,LIVE/'Include/Codex'/name)
    (STAGE/'guard-review.json').write_text(json.dumps({'checks':checks,'strategy_parameters_changed':False,'automatic_promotion':False,'source_sha256':hashlib.sha256(src.encode()).hexdigest()},indent=2),encoding='utf-8')
    print('Staged v0.11; '+str(len(checks))+' broker-guard and instrumentation-equivalence checks passed.')
if __name__=='__main__':main()
