"""Stage an execution/observability fix; preserve strategy and experiment protocols."""
from pathlib import Path
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
LIVE = ROOT / 'fp-demo-terminal/MQL4'
STAGE = ROOT / 'staging-v0.10'
BACKUP = ROOT / 'backup-fp-v0.9'

def body(text, name):
    m = re.search(r'(?m)^(?:bool|int|double|string|void|datetime) ' + re.escape(name) + r'\(', text)
    assert m, name
    opening = text.index('{', m.end())
    depth = 0
    for at in range(opening, len(text)):
        depth += (text[at] == '{') - (text[at] == '}')
        if depth == 0:
            return text[m.start():at + 1]
    raise ValueError(name)

def main():
    STAGE.mkdir(exist_ok=True)
    current = (LIVE / 'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    if 'version "1.900"' not in current and not (BACKUP / 'Experts/Codex/DemoPracticeAutopilot.mq4').exists():
        raise RuntimeError('Expected the deployed v0.9 before creating an immutable backup')
    for relative in ['Experts/Codex/DemoPracticeAutopilot.mq4', 'Experts/Codex/DemoPracticeAutopilot.ex4',
                     'Scripts/Codex/UpgradeReviewV09.mq4', 'Presets/continuous-demo.set']:
        dest = BACKUP / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists():
            shutil.copy2(LIVE / relative, dest)
    before = (BACKUP / 'Experts/Codex/DemoPracticeAutopilot.mq4').read_text(encoding='utf-8-sig')
    source = before.replace('version "1.900"', 'version "2.000"')
    source = source.replace('v0.9', 'v0.10').replace('\\"version\\":\\"0.9\\"', '\\"version\\":\\"0.10\\"')
    source = source.replace('FileWrite(f,"0.9",ticket>0?', 'FileWrite(f,"0.10",ticket>0?')
    source = source.replace('#include <Codex/SnapshotWriter.mqh>', '#include <Codex/SnapshotWriter.mqh>\n#include <Codex/ExecutionTiming.mqh>')
    helpers = r'''
datetime ActionReadyAt(const int ticket,const bool closing)
{
   return APActionReadyAt((datetime)GlobalVariableGet(K(closing?"close_after":"modify_after",ticket)),
      (datetime)GlobalVariableGet(K("channel_after",ticket)),
      (datetime)GlobalVariableGet(K("action_after",ticket))); // preserve any legacy in-flight retry deadline
}
string ExitReasonText(const int intent)
{return intent==AP_EXIT_GIVEBACK?"PROFIT_PROTECTION_GIVEBACK":APExitText(intent);}
'''
    source = source.replace('bool SafeClose(const int ticket', helpers + '\nbool SafeClose(const int ticket', 1)
    old_close = body(source, 'SafeClose')
    new_close = old_close.replace('TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket))', 'TimeLocal()<ActionReadyAt(ticket,true)')
    new_close = new_close.replace('K("action_after",ticket)', 'K("close_after",ticket)')
    new_close = new_close.replace('APExitText(intent)', 'ExitReasonText(intent)')
    # Flush the retry deadline too, so reloading cannot reset a pending close backoff.
    new_close = new_close.replace('   return ok;', '   GlobalVariablesFlush();\n   return ok;')
    source = source.replace(old_close, new_close)
    old_modify = body(source, 'SafeTighten')
    new_modify = old_modify.replace('   int side=', '   if(GlobalVariableGet(K("exit_intent",ticket))>0||TimeLocal()<ActionReadyAt(ticket,false))return false;\n   int side=', 1)
    new_modify = new_modify.replace('GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:5)));', '''GlobalVariableSet(K("modify_after",ticket),(double)(TimeLocal()+(ok?1:MathMax(5,APRetrySeconds(error)))));
   if(!ok&&APModifyBlocksClose(error))
      GlobalVariableSet(K("channel_after",ticket),(double)(TimeLocal()+APRetrySeconds(error)));
   GlobalVariablesFlush();''')
    source = source.replace(old_modify, new_modify)
    source = source.replace('if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))continue;', 'if(TimeLocal()<ActionReadyAt(ticket,false))continue;')
    source = source.replace('APExitText((int)GlobalVariableGet(K("exit_intent",ticket)))', 'ExitReasonText((int)GlobalVariableGet(K("exit_intent",ticket)))')
    # Display-only accounting uses the currently loaded MT4 history, explicitly scoped.
    source = source.replace('datetime last_draw=0;', 'datetime last_draw=0;\nint loaded_closed_count=0;double loaded_closed_net=0;')
    old_sync = body(source, 'SyncClosed')
    new_sync = old_sync.replace('   datetime latest=', '   loaded_closed_count=0;loaded_closed_net=0;\n   datetime latest=', 1)
    new_sync = new_sync.replace('      int ticket=OrderTicket();', '      loaded_closed_count++;loaded_closed_net+=OrderProfit()+OrderCommission()+OrderSwap();\n      int ticket=OrderTicket();', 1)
    source = source.replace(old_sync, new_sync)
    ui = r'''
double OwnedFloatingNet()
{
   double result=0;
   for(int i=OrdersTotal()-1;i>=0;i--)
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)&&IsOwnedSelected())result+=OrderProfit()+OrderCommission()+OrderSwap();
   return result;
}
string SignedMoney(const double value){return (value>=0?"+":"")+DoubleToString(value,2);}
string RuntimeDetail()
{
   if(!Identity()||!Owner())return "等待指定模拟账户和程序就绪";
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      int ticket=OrderTicket(),intent=(int)GlobalVariableGet(K("exit_intent",ticket));
      string pos=(OrderSymbol()==symbols[0]?"黄金":"白银")+(OrderType()==OP_BUY?"多单 ":"空单 ")+DoubleToString(OrderLots(),2)+"手";
      if(!IsConnected()||!quotes_fresh[IndexOf(OrderSymbol())])return pos+" | 行情中断；等待新报价";
      if(intent>0)return pos+" | 正在尝试平仓；重试等待 "+IntegerToString(APSecondsLeft(ActionReadyAt(ticket,true),TimeLocal()))+"秒";
      int left=APHoldSecondsLeft(OrderOpenTime(),TimeCurrent(),MaximumHoldMinutes);
      if(left==0)return pos+" | 持仓时限已到，等待平仓处理";
      return pos+(left<0?" | 实时管理":" | 最迟约 "+IntegerToString(left/60)+":"+(left%60<10?"0":"")+IntegerToString(left%60)+" 后尝试平仓");
   }
   if(!IsConnected())return "行情中断；等待连接恢复";
   if(Paused()||!AutoEntries)return "已暂停新单；持仓管理仍保留";
   int wait=APSecondsLeft((datetime)GlobalVariableGet(K("last_close"))+CooldownMinutes*60,TimeCurrent());
   return wait>0?"平仓冷却剩 "+IntegerToString(wait)+" 秒；继续观察":"空仓观察 | M5收盘找机会；同时一笔";
}
'''
    source = source.replace('void Display()', ui+'\nvoid Display()', 1)
    source = source.replace('Label("rule","M5收盘找机会；逐秒管理；同时一笔",137);', 'Label("rule",RuntimeDetail(),137);')
    source = source.replace('Label("research","浮盈0.6R尝试保本；达到1R后逐步保护",158);', 'Label("research","已平记录 "+IntegerToString(loaded_closed_count)+"笔 "+SignedMoney(loaded_closed_net)+" USD | 浮动 "+SignedMoney(OwnedFloatingNet())+" USD",158);')
    source = source.replace('      "\\\"positions\\\":"+PositionsJson()', '''      "\\\"execution_retry_policy\\\":\\\"separate_close_modify_with_shared_transport_backoff\\\","+
      "\\\"runtime_detail\\\":\\\""+Escape(RuntimeDetail())+"\\\",\\\"performance\\\":{\\\"history_scope\\\":\\\"loaded_MT4_history_owned_market_orders\\\","+
      "\\\"closed_count\\\":"+IntegerToString(loaded_closed_count)+",\\\"realized_net_usd\\\":"+DoubleToString(loaded_closed_net,4)+
      ",\\\"broker_floating_net_usd\\\":"+DoubleToString(OwnedFloatingNet(),4)+"},"+
      "\\\"positions\\\":"+PositionsJson()''')
    source = source.replace('         ",\\\"held_seconds\\\":"', '''         ",\\\"exit_intent\\\":\\\""+Escape(ExitReasonText((int)GlobalVariableGet(K("exit_intent",ticket))))+"\\\""+
         ",\\\"close_retry_in_seconds\\\":"+IntegerToString(APSecondsLeft(ActionReadyAt(ticket,true),TimeLocal()))+
         ",\\\"modify_retry_in_seconds\\\":"+IntegerToString(APSecondsLeft(ActionReadyAt(ticket,false),TimeLocal()))+
         ",\\\"hold_seconds_remaining\\\":"+IntegerToString(APHoldSecondsLeft(OrderOpenTime(),TimeCurrent(),MaximumHoldMinutes))+
         ",\\\"held_seconds\\\":"''')
    source = source.replace('early protection demo trial; paired prospective exit comparison;', 'execution retry isolation; clearer position and PnL status; unchanged v0.9 trial;')
    unchanged = ['Identity','Owner','MutationAllowed','EntryGate','ReadSpec','ReconcileFlat','Direction','RecentStructure','OnChartEvent','RefreshAdmission']
    checks = {name: body(before,name)==body(source,name) for name in unchanged}
    checks['TryEntry'] = body(before,'TryEntry').replace('v0.9','v0.10')==body(source,'TryEntry')
    checks['Manage_only_modify_timer_changed'] = body(before,'Manage').replace('TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket))','TimeLocal()<ActionReadyAt(ticket,false)')==body(source,'Manage')
    assert all(checks.values()), checks
    assert 'execution_retry_policy' in source and 'hold_seconds_remaining' in source
    (STAGE/'DemoPracticeAutopilot.mq4').write_text(source,encoding='utf-8-sig')
    shutil.copy2(ROOT/'ExecutionTiming.mqh',STAGE/'ExecutionTiming.mqh')
    # Adding a new include cannot change a running, already compiled EA.
    shutil.copy2(ROOT/'ExecutionTiming.mqh',LIVE/'Include/Codex/ExecutionTiming.mqh')
    (STAGE/'guard-review.json').write_text(json.dumps({'checks':checks,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'strategy_parameters_changed':False},indent=2),encoding='utf-8')
    print(json.dumps({'staged':str(STAGE),'guard_checks':checks}))

if __name__=='__main__':
    main()
