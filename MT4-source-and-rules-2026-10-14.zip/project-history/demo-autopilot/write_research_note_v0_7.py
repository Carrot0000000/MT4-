"""Document actual findings, mathematical assumptions and the matched portfolio experiment."""
import csv,json
from pathlib import Path
from research_math import analyze
from portfolio_analysis import analyze as portfolio_analyze
ROOT=Path(__file__).resolve().parent
DATA=Path('C:/Users/96259/AppData/Roaming/MetaQuotes/Terminal/3398008DB8784ED46E704350351E2CE1/MQL4/Files/DemoAutopilot')
direction=analyze(DATA);portfolio=portfolio_analyze(DATA)
papers=[
 {'title':'When Alpha Disappears: A One-Switch Benchmark for Decision-Time Leakage in Financial Backtests','date':'2026-05-12，v1','status':'arXiv预印本','url':'https://arxiv.org/html/2605.23959v1',
  'checked':'方法、决策时点与成交时点、单因素比较设计、限制',
  'application':'单双仓实验保持信号、成本、总风险上限一致，只改最大持仓数；只用入场前已完成K线，概率评分只用OPEN时可用记录。',
  'limitation':'这是股票日线评估研究，不提供黄金白银买卖信号，也未证明当前策略有alpha。'},
 {'title':'Taming Tail Risk in Financial Markets: Conformal Calibration for Nonstationary Portfolio VaR','date':'最新v3：2026-08-03','status':'arXiv预印本','url':'https://arxiv.org/html/2602.03903v3',
  'checked':'问题设定、状态/时间权重、覆盖假设、诊断与限制，并核对最新版',
  'application':'把市场非平稳和有效样本量列为概率解释的限制；保留风险、费用和报价质量诊断。',
  'limitation':'当前没有足够分位数预测和校准样本，没有声称复现其VaR模型或拥有分布无关的条件覆盖保证。'},
 {'title':'Learning to Bet for Horizon-Aware Anytime-Valid Testing','date':'最新v2：2026-06-02','status':'arXiv页面注明ICML 2026','url':'https://arxiv.org/html/2603.19551v2',
  'checked':'有限期限问题设定、数学下注与控制策略、最新版摘要和方法',
  'application':'分清统计证据的下注与真实仓位；继续保持预设证据规则与实际风险上限。',
  'limitation':'本任务是持续运行，没有严格固定样本截止N，不能直接套用该期限优化或把DQN下注强度当成下单手数。'},
 {'title':'Almost sure null bankruptcy of testing-by-betting strategies','date':'最新v2：2026-05-04','status':'概率论研究预印本','url':'https://arxiv.org/html/2602.08888v2',
  'checked':'摘要、零假设下财富过程的定义及最新版相关结果',
  'application':'明确e过程的数值变化是统计证据，不是账户财富；不因证据低或亏一笔而清空重试。',
  'limitation':'没有声称复现其所有证明；论文结论不能直接解释为这个模拟账户必定破产或必定赚钱。'},
 {'title':'Proper Scoring Rules for Estimation and Forecast Evaluation','date':'核对近期出版社综述页面，不以未经确认的卷期年断言最新排名','status':'Annual Review综述','url':'https://www.annualreviews.org/content/journals/10.1146/annurev-statistics-042424-050626',
  'checked':'概率预测评估、适当评分规则、对数和二次评分相关部分',
  'application':'加入Brier与log loss，保存入场前预测与之后结果，评价预测质量。',
  'limitation':'评分好不等于交易净盈利或已证明校准，当前样本仍过少。'},
 {'title':'Strictly Proper Scoring Rules, Prediction, and Estimation','date':'JASA 2007','status':'经典统计理论','url':'https://sites.stat.washington.edu/people/raftery/Research/PDF/Gneiting2007jasa.pdf',
  'checked':'评分规则的定义、二元概率与对数/二次评分的基础',
  'application':'用诚实的事前概率评分，惩罚过度自信的错误预测。',
  'limitation':'采用基础评分思想，未建立新的经过验证的金融预测模型。'},
 {'title':'Time-uniform, nonparametric, nonasymptotic confidence sequences','date':'Annals of Statistics 2021；arXiv初稿2018','status':'置信序列理论基础','url':'https://arxiv.org/pdf/1810.08240',
  'checked':'Beta-Binomial混合、Ville不等式与时间一致解释相关部分',
  'application':'加入条件Bernoulli模型下的胜率置信序列，区分它与贝叶斯后验均值。',
  'limitation':'固定条件胜率假设未验证；不把这个区间解释为净收益区间或下一单概率。'}
]
(ROOT/'research-reading-log-v0.7.json').write_text(json.dumps({'checked_on':'2026-10-13','papers':papers,
    'scope':'有针对性地核对方法、假设与最新版；不声称穷尽所有顶级资料'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
history=list(csv.DictReader((ROOT/'review-v0.7'/'audit-history.csv').open(encoding='utf-8-sig',newline='')))
net=sum(float(r['net']) for r in history)
lines=['v0.7升级：概率评估、交易权限与单双仓实时研究','资料核对及说明日期：2026-10-13。以下明确区分已安装功能、当前结果、数学假设及尚未实施的论文模型。','',
f'当前已核对{len(history)}笔自动模拟订单，合计净盈亏{net:+.2f}美元；原手动亏损4.99单独统计。账户余额488.41，累计相对最初500净亏11.59。',
'v0.6之后实际新增3笔：黄金定时退出+0.44，白银手动提前退出+0.60，白银定时退出+0.30，合计+1.34。',
'这三笔不能全部当作纯自动策略的证据；其中+0.60由用户主动平仓。早期还有一笔被修改过保护线。',
'系统仍未证明长期盈利。新增几笔小盈利不支持自动扩大仓位或宣称找到了赢家。','',
'一、同时多单是否更好',
'可能更好，也可能更差。更多持仓可以占用之前闲置的风险预算，也会增加费用和共同亏损的可能。',
'当前研究采用独立双仓虚拟组合与独立单仓虚拟组合，从同一时点、同一金额488.41开始。',
'两组都用H1方向及原M5触发、结构止损、止盈、保本、回撤退出、20分钟持有与5分钟冷却；只改变允许的同时持仓数。',
'双仓每个品种最多一笔，总共最多2笔。单仓最多1笔，黄金优先、白银其次。所有手数最多0.01。',
'两组总预留风险上限都是1%，双仓并不是每笔各1%。实际服务器账户仍保持原来的单仓限制。',
'可用新单风险=max(0,min(组合现金,可观察净值)×1%−已持仓初始预留风险之和)。保本后也不重复释放初始预留预算来叠仓。',
'例：现金500，净值500，总预算5；已持仓预留3.7，新单最多1.3。净值降到490时预算4.9，新单最多1.2，计划风险1.3就拒绝。',
'若最低0.01手的结构止损风险大于可用预算，就跳过；不把止损缩短或把手数强制抬高来凑两笔。',
'总风险上限相同并不表示实际风险使用量相同。双仓可能使用更多上限内风险，不能只用美元利润判断它更优秀，还要看暴露、费用和回撤。',
'预留是入场时的风险计划，包含设定滑移和费用；跳空与成交误差可能使真实损失偏离计划。这个上限不是保证最大实际亏损。',
'该对照只写虚拟账本，不发送、修改或关闭服务器订单，不自动切换主策略。','',
'二、避免把小样本均值误解为可靠胜率',
'Beta(1,1)后验均值在两胜零负时是3/4=75%，它只是有假设的统计描述。',
'本次加入Beta-Binomial混合反演的胜率置信序列。固定候选p，在W胜N笔下：',
'M_N(p)=B(W+1,N-W+1)/(p^W(1-p)^(N-W))。保留M_N(p)<100的p形成一个候选的99%时间一致区间。',
'两胜零负时区间下界约sqrt(1/300)=5.77%，上界100%；这显示数据支持的范围仍很宽。',
'这种解释要求每笔盈利指标的条件概率为同一个p。市场状态变化、相关性和样本选择可能违背假设，因此不把它当作已验证的金融保证。',
'新胜率区间是独立诊断：单个名义alpha=1%；三个方向模型共同最多3%的名义界需要假设成立。',
'原有变换R分数的e检验仍采用原批次阈值60。本次没有把不同检验家族拼在一起宣称“总体仍只有5%”。',
'胜率区间不是美元收益区间，更不是下一笔稳赢概率；原始净盈亏、成本压力和数据质量仍是主要经济指标。','',
'三、概率预测是否真的有用',
'逐笔在OPEN事件读取当时已知的W、N，保存p=(W+1)/(N+2)，之后CLOSE才评分。结果不能反过来改写入场前概率。',
'Brier=(p−y)^2；log loss=−[y log p+(1−y) log(1−p)]，y为是否净盈利。两者越低越好。',
'常数50%参照的Brier是0.25，log loss是log2。错误地报99%会比报50%受更大惩罚。',
'这个预测规则是简单统计基线，不是经过训练的行情预测模型；评分也不能单独证明校准或净交易收益。',
'样本太少时明确保留“不足以证明”的标记。']
for m in direction['models']:
    s=m['prequential_probability_scores'];interval=m['win_rate_confidence_sequence']['interval']
    lines.append(f"当前{m['model']}：{m['closed_count']}笔，净盈亏{m['net_usd']:+.2f}，成本压力{m['stress_net_usd']:+.2f}，Brier={s['brier'] if s['brier'] is not None else '无样本'}；条件胜率区间[{interval[0]:.2%},{interval[1]:.2%}]。")
lines += ['',
'四、权限关闭问题已经修复显示与状态核对',
'此前“自动交易权限关闭”无法告诉用户究竟是全局开关、该程序权限、服务器权限还是交易通道忙。',
'新版区分这些原因，并发布global_auto_trading、expert_auto_trading与trade_context_busy。即使主动暂停新单，也优先显示权限关闭问题。',
'此前已恢复全局自动交易，现有模拟持仓继续受管理，最终在定时条件下平仓。',
'“暂停新单”只是停止新入场，权限正常时仍管理持仓；权限关闭会阻止主动下单、平仓和改单，服务器原有止盈止损保留。',
'状态JSON改为先写完整临时文件，再替换发布文件，减少读取到半写入内容的窗口。',
'没有把FileMove说成跨文件事务或绝对的崩溃保证；读端仍核对完整性、时间和短重试。交易事件日志的强制记录规则保持不变。','',
'五、近期论文的取舍（英文题名及核对范围见reading-log JSON）']
cn=['决策时点泄漏的单因素评估','非平稳组合尾部风险的校准','有限期限下的序贯检验控制','零假设下统计下注过程的长期行为',
    '概率预测的适当评分综述','严格适当评分规则的经典理论','时间一致的置信序列基础']
for title,p in zip(cn,papers):
    lines.extend([title+'：'+p['date']+'；'+p['status'],'核对：'+p['checked'],'采用：'+p['application'],'限制：'+p['limitation'],p['url'],''])
lines += ['六、验证与当前边界',
'安装版编译0错误、0警告。63项原生研究/组合风险测试、18项独立Python统计测试通过，原68项计算和21项执行故障测试也通过。',
'新测试实际运行生产组合入场函数的风险、报价、保证金和记录门槛；报价、计划与存储由测试替身提供，不发送真实订单。',
'原实际账户的下单、关单、止损收紧和风险数学通过29项隔离/一致性检查，保持与v0.6一致。订单注释及诊断版本更新为v0.7。',
'旧方向研究批次和亏损记录保留；新单双仓批次单独建档，不能拿两个不同起点的收益硬比较。',
f"单双仓当前已平仓样本：双仓{portfolio['dual_closed']}，单仓{portfolio['single_closed']}；尚未证明哪种更好。",
'三个方向研究与新组合研究仍按可观察报价模型运行，虚拟价差/滑移与实际成交时点可能不同。没有完整服务器Tick重放、排队或拒单模型。',
'整体仍是模拟练习与前瞻研究，不使用真实资金，也没有自动选赢家、提高风险、加倍或清空输家结果。',
'运行文件：原启动入口不变。research-status.json提供方向研究；portfolio-status.json提供单双仓；两份原始ledger与calendar各自保留。',
'独立校验工具：research_math.py和portfolio_analysis.py；后者核对每笔组合入场的风险预算与共用资金没有重复计算。',
'只有后续新数据、相同时间窗口、成本与风险使用量的对照支持改进时，才有依据改变主交易规则。']
(ROOT/'单双仓与概率优化-详细说明-v0.7.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
print(json.dumps({'broker_history_trades':len(history),'broker_net':round(net,2),'papers_checked':len(papers),'dual_closed':portfolio['dual_closed']}))
