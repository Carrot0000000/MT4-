﻿#property strict
#property version "1.500"
#include "AutopilotCore.mqh"
int passed=0,failed=0;
void Check(const bool condition,const string label)
{ if(condition)passed++;else{failed++;Print("AP self-test FAILED: ",label);} }
bool Near(const double a,const double b){return MathAbs(a-b)<1e-7;}
void RunCoreTests()
{
   Check(APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",false),"expected demo allowed");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_REAL,176318407,"MetaQuotes-Demo",false),"real blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_CONTEST,176318407,"MetaQuotes-Demo",false),"contest blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,1,"MetaQuotes-Demo",false),"other login blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"FPMarketsLtd-Live5",false),"other server blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",true),"tester isolated");
   Check(Near(APLots(2.5,19.16,.02,.01,1,.01,.01,100,0),0),"minimum not forced up");
   Check(Near(APLots(10,4.99,.02,.01,1,.01,.01,100,0),.01),"floor under budget");
   Check(Near(APLots(10,5,.02,0,1,.01,.01,100,0),0),"zero tick blocks");
   Check(Near(APLots(10,5,.02,.01,1,.01,.01,100,-1),0),"negative cost blocks");
   Check(Near(APPrice(4185.951,.01,2,false),4185.95),"buy stop outward");
   Check(Near(APPrice(4185.951,.01,2,true),4185.96),"sell stop outward");
   Check(Near(APStop(100,5,-1,.3,.01,2),101.3),"Bid pivot to Ask stop");
   Check(Near(APStop(100,5,1,.3,.01,2),99),"buy structure");
   Check(Near(APNet(1,4205.11,4200.12,1,0),-4.99),"spread not charged twice");
   for(int side=-1;side<=1;side+=2)
   {
      double level=APBreakEven(100,10,.5,.02,.01,2,side);
      Check(APNet(side,100,level-side*.02,10,.5)>=.1-1e-7,"economic BE fees and reserve");
   }
   Check(!APGiveback(1.49,1,1),"profit gate not reached");
   Check(!APGiveback(1.7,1.21,1),"not enough giveback");
   Check(APGiveback(1.7,1.2,1),"giveback exit");
   double silver_floor=APMinimumRiskForSpread(.03,.1,.02,.01,10,.01,0);
   Check(Near(silver_floor,3.2),"spread and slip minimum risk");
   Check(silver_floor>495.01*.005,"0.5 percent incompatible at this spread");
   Check(silver_floor<495.01*.01,"1 percent removes this necessary-condition conflict");
   Check(Near(APLots(495.01*.01,.45,.02,.01,10,.01,.01,.01,0),.01),"silver minimum fits new budget");
   Check(Near(APLots(495.01*.005,.45,.02,.01,10,.01,.01,.01,0),0),"same structure rejected at old budget");
   Check(APMinimumRiskForSpread(.03,0,.02,.01,10,.01,0)<0,"invalid spread fraction marked unknown");
   Check(APEntryWindow(1000,1060)&&!APEntryWindow(1000,1061)&&!APEntryWindow(1000,999),"entry window boundaries");
   Check(!APEntryWindow(0,30),"unknown bar never eligible");
   Check(APRecordChanged(0,0,1000,AP_TRIGGER),"first refusal recorded");
   Check(!APRecordChanged(1000,AP_TRIGGER,1000,AP_TRIGGER),"same refusal not flooded per tick");
   Check(APRecordChanged(1000,AP_TRIGGER,1000,AP_BUDGET),"changed refusal within bar recorded");
   Check(APRecordChanged(1000,AP_TRIGGER,1900,AP_TRIGGER),"same refusal on new bar recorded");
   Check(APCheckText(AP_BUDGET)!=""&&APCheckText(AP_QUOTE)!=APCheckText(AP_BUDGET),"quote and budget causes distinguished");
   Check(APBias(101,100)==1,"simple H1 long bias");
   Check(APBias(99,100)==-1,"simple H1 short bias");
   Check(APBias(100,100)==0,"flat H1 has no forced direction");
   Check(APBias(0,100)==0,"missing H1 price blocked");
   Check(APMomentum(1,100,100.8,100.5,100.4),"buy momentum without requiring high breakout");
   Check(APMomentum(-1,100,99.2,99.5,99.6),"sell momentum");
   Check(!APMomentum(-1,100,100.8,100.5,100.4),"counter-direction momentum rejected");
   Check(!APMomentum(1,100,100,99,99),"doji not forced into a trade");
   Check(Near(APRangeExtreme(99,98,97,1),97),"closed-bar low extreme");
   Check(Near(APRangeExtreme(101,102,103,-1),103),"closed-bar high extreme");
   Check(APRangeExtreme(0,98,97,1)==0,"missing stop structure blocked");
   Check(Near(APDriftLimit(.05,.01,.25),.02),"drift limit respects quote ticks");
   Check(Near(APDriftLimit(4,.01,.25),1),"drift limit uses ATR for larger ranges");
   Check(APDriftLimit(0,.01,.25)==0,"invalid ATR drift blocked");
   Check(APEntryWindow(1000,1120,120)&&!APEntryWindow(1000,1121,120),"M5 two-minute window boundary");
   Check(!APEntryWindow(1000,1300,120),"expired M5 signal blocked");
   Check(Near(APMinimumRiskForSpread(.03,.2,.02,.01,10,.01,0),1.7),"M5 spread-cost lower bound");
   Check(Near(APCostAwareInitialStop(99.95,100,.02,.2,.01,2,1),99.89),"initial buy stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(100.05,100,.02,.2,.01,2,-1),100.11),"initial sell stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(99,100,.02,.2,.01,2,1),99),"already wider structural stop is preserved");
   Check(APCostAwareInitialStop(99,100,.02,0,.01,2,1)==0,"invalid cost ratio blocks stop calculation");
   // Reproduce the two same-cycle v0.4 reopenings and the server-stop transition.
   Check(!APEntryCycleReady(true,true,1000,1000,5),"accepted close cannot reopen in same cycle");
   Check(!APEntryCycleReady(true,true,1000,1000,0),"same-cycle block applies even with zero cooldown");
   Check(!APEntryCycleReady(false,false,1400,1000,5),"unconfirmed history cannot reopen");
   Check(!APEntryCycleReady(false,true,1299,1000,5),"full 300 second cooldown enforced");
   Check(APEntryCycleReady(false,true,1300,1000,5),"eligible again at cooldown boundary");
   Check(!APCooldownReady(1000,1001,5),"future close timestamp blocks entries");
   Check(APCooldownReady(1000,0,5),"new session without earlier trades permitted");
   Check(!APCooldownReady(1000,0,-1),"negative cooldown invalid");
   Check(APStickyExit(AP_EXIT_GIVEBACK,AP_EXIT_NONE)==AP_EXIT_GIVEBACK,"rebound cannot cancel requested giveback exit");
   Check(APStickyExit(AP_EXIT_TIME,AP_EXIT_GIVEBACK)==AP_EXIT_TIME,"original exit reason survives retry and restart");
   Check(APStickyExit(AP_EXIT_NONE,AP_EXIT_GIVEBACK)==AP_EXIT_GIVEBACK,"exit request latched");
   Check(APRetrySeconds(138)==1&&APRetrySeconds(135)==1,"requote and changed price bounded retry");
   Check(APRetrySeconds(128)==10&&APRetrySeconds(6)==10,"uncertain acknowledgement reconciles with backoff");
   Check(APRetrySeconds(146)>=5&&APRetrySeconds(136)>=3,"busy and off-quotes do not spin");
   for(int wait_index=0;wait_index<75;wait_index++)
   {
      if(IsConnected()&&APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())&&APFinitePositive(AccountBalance()))break;
      Sleep(200);
   }
   bool history_ready=false;
   for(int history_wait=0;history_wait<75;history_wait++)
   {
      MqlRates rates[];
      CopyRates("XAUUSD",PERIOD_M5,0,120,rates);CopyRates("XAGUSD",PERIOD_M5,0,120,rates);
      history_ready=iBars("XAUUSD",PERIOD_M5)>=101&&iBars("XAGUSD",PERIOD_M5)>=101;
      if(history_ready)break;
      Sleep(200);
   }
   FolderCreate("DemoAutopilot");
   int f=FileOpen("DemoAutopilot\\self-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"passed\":"+IntegerToString(passed)+",\"failed\":"+IntegerToString(failed)+
         ",\"order_operations\":0,\"connected\":"+(IsConnected()?"true":"false")+
         ",\"expected_demo\":"+(APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())?"true":"false")+
         ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+"}");
      FileClose(f);
   }
   int data_file=FileOpen("DemoAutopilot\\m5-preflight.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(data_file!=INVALID_HANDLE)
   {
      string json="{\"m5_history_ready\":"+(history_ready?"true":"false")+",\"order_operations\":0,\"symbols\":[";
      string names[2]={"XAUUSD","XAGUSD"};
      for(int i=0;i<2;i++)
      {
         string symbol=names[i];if(i>0)json+=",";
         double h1_close=iClose(symbol,PERIOD_H1,1),h1_ema=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1);
         int side=APBias(h1_close,h1_ema);
         bool momentum=APMomentum(side,iOpen(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,2),iMA(symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE,1));
         json+="{\"symbol\":\""+symbol+"\",\"m5_bars\":"+IntegerToString(iBars(symbol,PERIOD_M5))+
            ",\"h1_bars\":"+IntegerToString(iBars(symbol,PERIOD_H1))+",\"h1_direction\":"+IntegerToString(side)+
            ",\"last_closed_m5_momentum_matches\":"+(momentum?"true":"false")+"}";
      }
      FileWriteString(data_file,json+"]}");FileClose(data_file);
   }
   Print("AP self-test: passed=",passed," failed=",failed,"; no order operations.");
}


struct Spec { double tick,value,point,minimum,step,maximum,spread,bid,ask,slip; int digits; };
string key="mock.",symbols[2]={"XAUUSD","XAGUSD"},mode="";
bool have_owner=true,working=false,closed_this_cycle=false,quotes_fresh[2]={false,false};
bool AutoEntries=true;int CooldownMinutes=5,MaximumHoldMinutes=20,SlippagePoints=20;
datetime last_status=0,last_sync=0,last_history_request=0,last_metrics_flush=0;
double current_spreads[2]={0,0},spread_minimum_risks[2]={0,0},RoundTripFeePerLotUSD=0,MaxSpreadFraction=.2;
string mock_names[200];double values[200];int vars=0;
bool mock_live=false,mock_visible=true,mock_mutation=true,mock_identity=true,mock_owner=true,mock_fresh=true;
bool mock_delay_history=false,mock_close_on_error=false;
int mock_error=0,mock_last_error=0,mock_closes=0,mock_entries=0,mock_tightens=0;
datetime mock_now=2200,mock_open=1000,mock_closed=0;
double mock_bid=102,mock_ask=102.02,mock_sl=95,mock_tp=110;
string K(const string field,const int ticket=0){return key+field+(ticket>0?"."+IntegerToString(ticket):"");}
int V(const string name){for(int i=0;i<vars;i++)if(mock_names[i]==name)return i;return -1;}
double FakeGlobalVariableGet(const string name){int i=V(name);return i>=0?values[i]:0;}
datetime FakeGlobalVariableSet(const string name,const double value)
{int i=V(name);if(i<0){i=vars++;mock_names[i]=name;}values[i]=value;return mock_now;}
bool FakeGlobalVariableCheck(const string name){return V(name)>=0;}
void FakeGlobalVariablesFlush(){}
bool Identity(){return mock_identity;}bool Owner(){return mock_owner;}
bool MutationAllowed(){return mock_identity&&mock_owner&&mock_mutation;}
bool Paused(){return FakeGlobalVariableGet(K("pause"))>0||FakeGlobalVariableGet(K("halt"))>0;}
int IndexOf(const string symbol){return symbol=="XAUUSD"?0:1;}
bool IsOwnedSelected(){return true;}
int OwnedCount(){return mock_live?1:0;}
bool FakeOrderSelect(const int value,const int select,const int pool=MODE_TRADES)
{return mock_live||(mock_visible&&mock_closed>0);}
int FakeOrdersTotal(){return mock_live?1:0;}
datetime FakeOrderCloseTime(){return mock_live?0:mock_closed;}
int FakeOrderTicket(){return 123;}
string FakeOrderSymbol(){return "XAUUSD";}
int FakeOrderType(){return OP_BUY;}
double FakeOrderLots(){return .01;}
datetime FakeOrderOpenTime(){return mock_open;}
double FakeOrderOpenPrice(){return 100;}
double FakeOrderStopLoss(){return mock_sl;}
double FakeOrderTakeProfit(){return mock_tp;}
double FakeOrderCommission(){return 0;}
double FakeOrderSwap(){return 0;}
datetime FakeTimeCurrent(){return mock_now;}
datetime FakeTimeLocal(){return mock_now;}
bool FakeRefreshRates(){return true;}
void FakeResetLastError(){mock_last_error=0;}
int FakeGetLastError(){return mock_last_error;}
bool FakeIsConnected(){return true;}bool FakeIsTradeAllowed(){return true;}
bool FakeOrderClose(const int ticket,const double lots,const double price,const int slippage,const color arrow)
{
   mock_closes++;mock_last_error=mock_error;
   if(mock_error==0||mock_close_on_error){mock_live=false;mock_closed=mock_now;mock_visible=!mock_delay_history;}
   return mock_error==0;
}
bool ReadSpec(const int index,Spec &s)
{s.tick=.01;s.value=1;s.point=.01;s.minimum=.01;s.step=.01;s.maximum=100;s.spread=.02;
 s.bid=mock_bid;s.ask=mock_ask;s.slip=.05;s.digits=2;return mock_fresh;}
void Event(const string action,const string symbol,const int ticket,const string details){}
void SyncClosed()
{
   if(!mock_live&&mock_visible&&mock_closed>FakeGlobalVariableGet(K("last_close")))
      FakeGlobalVariableSet(K("last_close"),(double)mock_closed);
}
bool SafeTighten(const int ticket,const double target){mock_tightens++;return true;}
void RequestHistory(){}void Display(){}void Status(){}
void TryEntry(const int index);
#define GlobalVariableGet FakeGlobalVariableGet
#define GlobalVariableSet FakeGlobalVariableSet
#define GlobalVariableCheck FakeGlobalVariableCheck
#define GlobalVariablesFlush FakeGlobalVariablesFlush
#define OrderSelect FakeOrderSelect
#define OrdersTotal FakeOrdersTotal
#define OrderCloseTime FakeOrderCloseTime
#define OrderTicket FakeOrderTicket
#define OrderSymbol FakeOrderSymbol
#define OrderType FakeOrderType
#define OrderLots FakeOrderLots
#define OrderOpenTime FakeOrderOpenTime
#define OrderOpenPrice FakeOrderOpenPrice
#define OrderStopLoss FakeOrderStopLoss
#define OrderTakeProfit FakeOrderTakeProfit
#define OrderCommission FakeOrderCommission
#define OrderSwap FakeOrderSwap
#define TimeCurrent FakeTimeCurrent
#define TimeLocal FakeTimeLocal
#define OrderClose FakeOrderClose
#define RefreshRates FakeRefreshRates
#define ResetLastError FakeResetLastError
#define GetLastError FakeGetLastError
#define IsConnected FakeIsConnected
#define IsTradeAllowed FakeIsTradeAllowed
bool ReconcileFlat()
{
   if(OrdersTotal()!=0)return false;
   int ticket=(int)GlobalVariableGet(K("last_live_ticket"));
   if(ticket>0)
   {
      if(!OrderSelect(ticket,SELECT_BY_TICKET)||!IsOwnedSelected()||OrderCloseTime()==0)return false;
      datetime closed=OrderCloseTime(),latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      GlobalVariableSet(K("last_live_ticket"),0);closed_this_cycle=true;
      SyncClosed();last_sync=TimeLocal();GlobalVariablesFlush();
   }
   return true;
}

bool EntryGate()
{
   if(!Identity()||!Owner()||OrdersTotal()!=0||Paused()||!AutoEntries)return false;
   bool reconciled=ReconcileFlat();
   return APEntryCycleReady(closed_this_cycle,reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes);
}

bool SafeClose(const int ticket,const int requested)
{
   if(!Identity()||!Owner()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int previous_intent=(int)GlobalVariableGet(K("exit_intent",ticket));
   int intent=APStickyExit(previous_intent,requested);
   if(intent!=previous_intent){GlobalVariableSet(K("exit_intent",ticket),intent);GlobalVariablesFlush();}
   if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))return false;
   if(!MutationAllowed())return false;
   string symbol=OrderSymbol();int index=IndexOf(symbol);Spec s;
   RefreshRates();
   if(!ReadSpec(index,s))return false;
   double lots=OrderLots(),price=OrderType()==OP_BUY?s.bid:s.ask;
   // The same account and ownership guards are rechecked immediately before every mutation.
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();
   if(ok)
   {
      // Persist immediately; SyncClosed's periodic scan was too late in v0.4.
      datetime closed=TimeCurrent();
      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0)closed=OrderCloseTime();
      datetime latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      closed_this_cycle=true;GlobalVariablesFlush();
   }
   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,APExitText(intent)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:APRetrySeconds(error))));
   return ok;
}

void ObserveProtectionSelected()
{
   int ticket=OrderTicket();double sl=OrderStopLoss(),tp=OrderTakeProfit();
   if(GlobalVariableCheck(K("observed_sl",ticket)))
   {
      double old_sl=GlobalVariableGet(K("observed_sl",ticket)),old_tp=GlobalVariableGet(K("observed_tp",ticket));
      if(MathAbs(sl-old_sl)>1e-7||MathAbs(tp-old_tp)>1e-7)
      {
         GlobalVariableSet(K("outside_change",ticket),1);
         Event("PROTECTION_CHANGED_OUTSIDE_EA",OrderSymbol(),ticket,"old_sl="+DoubleToString(old_sl,8)+" new_sl="+DoubleToString(sl,8)+
            " old_tp="+DoubleToString(old_tp,8)+" new_tp="+DoubleToString(tp,8)+" actor_unknown; retain permitted user adjustment");
      }
   }
   GlobalVariableSet(K("observed_sl",ticket),sl);GlobalVariableSet(K("observed_tp",ticket),tp);
}

void Manage()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      int ticket=OrderTicket(),side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());
      GlobalVariableSet(K("last_live_ticket"),ticket);
      ObserveProtectionSelected();
      Spec s;if(!ReadSpec(index,s))continue;
      if(GlobalVariableGet(K("flatten"))>0){SafeClose(ticket,AP_EXIT_USER);continue;}
      if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_PROTECTION);continue;}
      if(!GlobalVariableCheck(K("initial_R",ticket)))
      {
         // A crash immediately after OrderSend can recover the prior persisted plan.
         double pending=GlobalVariableGet(K("pending_R"));
         if(APFinitePositive(pending))GlobalVariableSet(K("initial_R",ticket),pending);
         else{GlobalVariableSet(K("halt"),1);mode="暂停：持仓初始风险状态缺失";continue;}
      }
      double r=GlobalVariableGet(K("initial_R",ticket));
      double units=OrderLots()*s.value/s.tick;
      double cost=MathMax(0,-OrderCommission())+MathMax(0,-OrderSwap());
      double remaining_risk=MathMax(0,side*(OrderOpenPrice()-OrderStopLoss()))*units+s.slip*units+cost;
      if(remaining_risk>r+0.01)
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_RISK);continue;}
      double price=side==1?s.bid:s.ask;
      double net=APNet(side,OrderOpenPrice(),price,units,cost);
      double peak=MathMax(net,GlobalVariableGet(K("peak",ticket)));
      GlobalVariableSet(K("peak",ticket),peak);
      double worst=GlobalVariableCheck(K("worst",ticket))?GlobalVariableGet(K("worst",ticket)):net;
      GlobalVariableSet(K("worst",ticket),MathMin(net,worst));
      if(TimeLocal()-last_metrics_flush>=5){GlobalVariablesFlush();last_metrics_flush=TimeLocal();}
      int intent=(int)GlobalVariableGet(K("exit_intent",ticket));
      if(intent>0){SafeClose(ticket,intent);continue;}
      if(APGiveback(peak,net,r)){SafeClose(ticket,AP_EXIT_GIVEBACK);continue;}
      if(MaximumHoldMinutes>0 && TimeCurrent()-OrderOpenTime()>=MaximumHoldMinutes*60)
      {SafeClose(ticket,AP_EXIT_TIME);continue;}
      if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))continue;
      if(net>=r)
      {
         double be=APBreakEven(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side);
         if(APFinitePositive(be))SafeTighten(ticket,be);
      }
   }
   if(OwnedCount()==0 && GlobalVariableGet(K("flatten"))>0)GlobalVariableSet(K("flatten"),0);
}

void Cycle()
{
   if(working)return;working=true;closed_this_cycle=false;
   if(!Identity())mode="账户不匹配，禁止交易";
   else if(!Owner())mode="重复实例，禁止交易";
   else if(!IsConnected())mode="断线；等待连接";
   else
   {
      if(TimeLocal()-last_history_request>=5){RequestHistory();last_history_request=TimeLocal();}
      Spec tmp;for(int i=0;i<2;i++)
      {
         quotes_fresh[i]=ReadSpec(i,tmp);
         if(quotes_fresh[i])
         {
            current_spreads[i]=tmp.spread;
            spread_minimum_risks[i]=APMinimumRiskForSpread(tmp.spread,MaxSpreadFraction,tmp.slip,tmp.tick,tmp.value,tmp.minimum,RoundTripFeePerLotUSD);
         }
      }
      if(TimeLocal()-last_sync>=5){SyncClosed();last_sync=TimeLocal();}
      Manage();
      bool flat_reconciled=OrdersTotal()==0?ReconcileFlat():false;
      if(GlobalVariableGet(K("halt"))>0)mode="异常暂停，检查记录";
      else if(!AutoEntries||Paused())mode="暂停新单";
      else if(!IsTradeAllowed())mode="自动交易权限关闭";
      else if(OrdersTotal()>0)mode=OwnedCount()>0?"持仓实时管理":"已有其他订单，暂停新单";
      else if(!flat_reconciled)mode="等待平仓记录确认";
      else if(!APEntryCycleReady(closed_this_cycle,flat_reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes))mode="平仓后冷却，继续观察";
      else
      {
         mode="持续观察，条件满足才入场";
         for(int i=0;i<2;i++){TryEntry(i);if(OrdersTotal()>0)break;}
      }
   }
   Display();if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}
   working=false;
}

void TryEntry(const int index){if(EntryGate())mock_entries++;}
void ResetScenario()
{
   vars=0;mock_live=true;mock_visible=true;mock_mutation=true;mock_identity=true;mock_owner=true;mock_fresh=true;
   mock_delay_history=false;mock_close_on_error=false;mock_error=0;mock_last_error=0;
   mock_closes=0;mock_entries=0;mock_tightens=0;mock_now=2200;mock_open=1000;mock_closed=0;
   mock_bid=102;mock_ask=102.02;mock_sl=95;mock_tp=110;working=false;closed_this_cycle=false;last_sync=0;last_status=0;
   last_history_request=0;last_metrics_flush=0;CooldownMinutes=5;MaximumHoldMinutes=20;AutoEntries=true;
   GlobalVariableSet(K("initial_R",123),6);GlobalVariableSet(K("peak",123),0);
}
int exec_passed=0,exec_failed=0;
void ECheck(const bool okay,const string label)
{if(okay)exec_passed++;else{exec_failed++;Print("Execution regression FAILED: ",label);}}
void RunExecutionTests()
{
   ResetScenario();Cycle();
   ECheck(mock_closes==1&&!mock_live&&mock_entries==0,"time exit plus eligible new signal does not reopen same cycle");
   ECheck(GlobalVariableGet(K("last_close"))==2200,"accepted close writes cooldown immediately");
   mock_now=2499;Cycle();ECheck(mock_entries==0,"one second before cooldown remains blocked");
   mock_now=2500;Cycle();ECheck(mock_entries>0,"new entries eligible at 300 seconds");

   ResetScenario();mock_delay_history=true;Cycle();
   mock_now=2600;Cycle();ECheck(mock_entries==0,"missing history blocks reopening beyond nominal cooldown");
   mock_visible=true;Cycle();ECheck(mock_entries==0,"confirmation cycle cannot reopen");
   Cycle();ECheck(mock_entries>0,"confirmed earlier close permits later cycle");

   ResetScenario();MaximumHoldMinutes=0;mock_open=2100;Manage();
   mock_live=false;mock_closed=2210;mock_now=2210;mock_visible=false;Cycle();
   ECheck(mock_entries==0,"server stop with delayed history blocks new signal");
   mock_visible=true;Cycle();ECheck(GlobalVariableGet(K("last_close"))==2210&&mock_entries==0,"server exit starts cooldown");

   ResetScenario();MaximumHoldMinutes=0;mock_bid=107;mock_ask=107.02;
   GlobalVariableSet(K("peak",123),10);mock_error=138;Cycle();
   ECheck(mock_closes==1&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,"requote retains giveback intent");
   mock_bid=108;mock_ask=108.02;mock_error=0;Cycle();
   ECheck(mock_closes==1,"retry not sent before backoff");
   mock_now++;Cycle();ECheck(mock_closes==2&&!mock_live&&mock_entries==0,"rebound cannot cancel pending exit");

   ResetScenario();mock_mutation=false;Manage();
   ECheck(mock_closes==0&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_TIME,"closed trade context still saves intent");
   mock_mutation=true;mock_fresh=false;Manage();ECheck(mock_closes==0,"stale quote blocks close request");
   mock_fresh=true;Manage();ECheck(mock_closes==1,"fresh quote completes saved request");

   ResetScenario();mock_identity=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"wrong account no mutations");
   ResetScenario();mock_owner=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"duplicate owner no mutations");
   ResetScenario();GlobalVariableSet(K("pause"),1);Cycle();
   ECheck(mock_closes==1&&mock_entries==0,"paused entries retain position management");
   ResetScenario();mock_error=128;mock_close_on_error=true;Cycle();
   ECheck(mock_closes==1&&mock_entries==0&&!mock_live,"ambiguous accepted close reconciles without duplicate send");
   ResetScenario();MaximumHoldMinutes=0;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==0,"first protection observation not mislabeled as outside edit");
   mock_sl=96;mock_tp=109;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==1&&mock_closes==0,"outside tightening and TP edit flagged without overriding user");

   int f=FileOpen("DemoAutopilot\\execution-regression.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
      ",\"actual_order_operations\":0,\"production_functions_under_mock_environment\":[\"SafeClose\",\"Manage\",\"ReconcileFlat\",\"EntryGate\",\"Cycle\"]}");FileClose(f);}
}
#undef GlobalVariableGet
#undef GlobalVariableSet
#undef GlobalVariableCheck
#undef GlobalVariablesFlush
#undef OrderSelect
#undef OrdersTotal
#undef OrderCloseTime
#undef OrderTicket
#undef OrderSymbol
#undef OrderType
#undef OrderLots
#undef OrderOpenTime
#undef OrderOpenPrice
#undef OrderStopLoss
#undef OrderTakeProfit
#undef OrderCommission
#undef OrderSwap
#undef TimeCurrent
#undef TimeLocal
#undef OrderClose
#undef RefreshRates
#undef ResetLastError
#undef GetLastError
#undef IsConnected
#undef IsTradeAllowed

void RunAudit()
{
   if(!APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())||AccountCurrency()!="USD")
   {Print("Audit blocked: demo identity mismatch");return;}
   int f=FileOpen("DemoAutopilot\\audit-history.csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   if(f==INVALID_HANDLE)return;
   FileWrite(f,"ticket","symbol","side","lots","open_server","close_server","open_price","close_price","final_sl","final_tp",
      "profit","commission","swap","net","magic","comment","reserved_r","observed_peak_estimate");
   int exported=0;
   for(int i=0;i<OrdersHistoryTotal();i++)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)||OrderMagicNumber()!=2026101217||OrderCloseTime()==0)continue;
      int ticket=OrderTicket();
      FileWrite(f,ticket,OrderSymbol(),OrderType()==OP_BUY?1:-1,DoubleToString(OrderLots(),8),
         TimeToString(OrderOpenTime(),TIME_DATE|TIME_SECONDS),TimeToString(OrderCloseTime(),TIME_DATE|TIME_SECONDS),
         DoubleToString(OrderOpenPrice(),8),DoubleToString(OrderClosePrice(),8),DoubleToString(OrderStopLoss(),8),DoubleToString(OrderTakeProfit(),8),
         DoubleToString(OrderProfit(),4),DoubleToString(OrderCommission(),4),DoubleToString(OrderSwap(),4),
         DoubleToString(OrderProfit()+OrderCommission()+OrderSwap(),4),OrderMagicNumber(),OrderComment(),
         DoubleToString(GlobalVariableGet("AP02.176318407.initial_R."+IntegerToString(ticket)),4),
         DoubleToString(GlobalVariableGet("AP02.176318407.peak."+IntegerToString(ticket)),4));
      exported++;
   }
   FileFlush(f);FileClose(f);
   string names_audit[2]={"XAUUSD","XAGUSD"};ENUM_TIMEFRAMES frames[2]={PERIOD_M5,PERIOD_H1};
   for(int s=0;s<2;s++)for(int t=0;t<2;t++)
   {
      MqlRates rates[];int copied=CopyRates(names_audit[s],frames[t],1,2200,rates);
      int rfile=FileOpen("DemoAutopilot\\audit-"+names_audit[s]+"-"+IntegerToString((int)frames[t])+".csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
      if(rfile==INVALID_HANDLE)continue;
      FileWrite(rfile,"bar_open_server","open","high","low","close","tick_volume","spread_points");
      for(int k=0;k<copied;k++)FileWrite(rfile,TimeToString(rates[k].time,TIME_DATE|TIME_SECONDS),DoubleToString(rates[k].open,8),
         DoubleToString(rates[k].high,8),DoubleToString(rates[k].low,8),DoubleToString(rates[k].close,8),rates[k].tick_volume,rates[k].spread);
      FileFlush(rfile);FileClose(rfile);
   }
   int status_file=FileOpen("DemoAutopilot\\audit-summary.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(status_file!=INVALID_HANDLE){FileWriteString(status_file,"{\"expected_demo\":true,\"history_trades_exported\":"+IntegerToString(exported)+
      ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+",\"actual_order_operations\":0}");FileClose(status_file);}
}
void OnStart(){RunCoreTests();RunExecutionTests();RunAudit();}
