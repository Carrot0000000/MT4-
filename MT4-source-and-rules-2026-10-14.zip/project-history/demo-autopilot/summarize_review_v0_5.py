"""Reconcile broker history with EA decisions; do not treat event timestamps as fills."""
import csv
import json
from decimal import Decimal
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REVIEW=ROOT/'review-v0.5'
trades=list(csv.DictReader((REVIEW/'audit-history.csv').open(encoding='utf-8-sig',newline='')))
events=list(csv.DictReader((REVIEW/'events.csv').open(encoding='utf-8-sig',newline='')))
parse=lambda text:datetime.strptime(text,'%Y.%m.%d %H:%M:%S')
plans={}; pending={}; exits={}
for event in events:
    if event['action']=='ENTRY_PLAN':pending[event['symbol']]=event['details']
    if event['action']=='ENTRY_ACCEPTED':plans[event['ticket']]=pending.get(event['symbol'],'')
    if event['action']=='CLOSE_ACCEPTED':exits[event['ticket']]=event['details'].split(' error=')[0]
def fields(text):
    return dict(token.split('=',1) for token in text.split() if '=' in token)

balance=Decimal('495.01'); peak=balance; max_drawdown=Decimal(0)
cooldown_violations=[]; enriched=[]
for i,t in enumerate(trades):
    net=Decimal(t['net']); balance+=net; peak=max(peak,balance); max_drawdown=max(max_drawdown,peak-balance)
    plan=fields(plans.get(t['ticket'],'')); gap=None
    if i:
        gap=(parse(t['open_server'])-parse(trades[i-1]['close_server'])).total_seconds()
        if gap<300:cooldown_violations.append({'previous_ticket':trades[i-1]['ticket'],'new_ticket':t['ticket'],'seconds':gap})
    original_sl=Decimal(plan['sl']); original_tp=Decimal(plan['tp'])
    sl_changed=original_sl!=Decimal(t['final_sl']);tp_changed=original_tp!=Decimal(t['final_tp'])
    own_stop=[e for e in events if e['ticket']==t['ticket'] and e['action']=='SL_TIGHTEN_ACCEPTED']
    outside=(sl_changed and not own_stop) or tp_changed
    reason=exits.get(t['ticket'],'SERVER_STOP' if '[sl]' in t['comment'] else 'NOT_CLASSIFIED')
    enriched.append({**t,'initial_sl_from_plan':str(original_sl),'initial_tp_from_plan':str(original_tp),
        'exit_reason':reason,'outside_protection_change_evidenced':outside,
        'net_r':float(net/Decimal(t['reserved_r'])),'balance_after':float(balance),
        'cooldown_gap_from_previous_seconds':gap,
        'peak_note':'observed quote estimate; zero means no positive sampled peak, not tick-complete MFE'})

wins=sum((Decimal(t['net']) for t in trades if Decimal(t['net'])>0),Decimal(0))
losses=-sum((Decimal(t['net']) for t in trades if Decimal(t['net'])<0),Decimal(0))
stats={'scope':'8 closed v0.4 automated demo orders; excludes original manual -4.99',
    'starting_balance':495.01,'ending_balance':float(balance),'net':float(wins-losses),
    'trades':len(trades),'wins':sum(Decimal(t['net'])>0 for t in trades),'gross_wins':float(wins),'gross_losses':float(losses),
    'profit_factor':float(wins/losses),'mean_net':float((wins-losses)/len(trades)),
    'maximum_closed_trade_drawdown':float(max_drawdown),'includes_intratrade_drawdown':False,
    'cooldown_violations':cooldown_violations,'outside_modified_tickets':[t['ticket'] for t in enriched if t['outside_protection_change_evidenced']],
    'unmodified_subset':{'trades':7,'net':-5.84},'profitability_validated':False,'trades_detail':enriched}
assert len(trades)==8 and balance==Decimal('488.17')
assert wins-losses==Decimal('-6.84') and len(cooldown_violations)==2
assert stats['outside_modified_tickets']==['1634527157']
(REVIEW/'trade-review.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

lines=['模拟交易复盘与执行升级 v0.5','复盘数据截止：2026-10-12 21:19（客户端北京时间；逐笔表时间为服务器时间）','',
'结论：提高频率没有被证明提高收益。先修复实际执行缺陷，保留固定入场规则采集新样本，避免按少量亏损反复调参。',
'本轮没有实盘操作，也没有提高单笔风险、手数或同时持仓数。', '',
'一、账目核对',
'原手动模拟单：500.00 → 495.01，亏损4.99美元，不计入自动策略8笔样本。',
'v0.4自动策略：495.01 → 488.17，共8笔，2笔盈利、6笔亏损，合计−6.84美元。',
'账面全部模拟交易：500.00 → 488.17，合计−11.83美元。',
f'自动策略毛盈利{wins:.2f}，毛亏损{losses:.2f}，盈利因子{wins/losses:.3f}，平均每笔{(wins-losses)/len(trades):.3f}美元。',
f'自动策略按逐单平仓余额计算的最大回撤{max_drawdown:.2f}美元；没有完整逐Tick曲线，不能当作真实最大浮动回撤。',
'所有8笔成交手数均为0.01；实际佣金、隔夜费均为0（仅描述这8笔，不代表其他账户或将来费用）。',
'服务器订单历史是价格、成交时间和净盈亏的依据；事件文件时间是本地处理/观察时间，两者不能混用。','',
'二、逐笔结果（服务器时间）',
'订单 | 品种方向 | 开仓→平仓 | 净盈亏 | 观察到的峰值估计 | 退出方式']
for t in enriched:
    lines.append(f"{t['ticket']} | {t['symbol']} {'买' if t['side']=='1' else '卖'} | {t['open_server']} → {t['close_server']} | {Decimal(t['net']):+.2f} | {Decimal(t['observed_peak_estimate']):.2f} | {t['exit_reason']}" )
lines += ['',
'三、有直接证据的问题',
'1. 冷却绕过：1634469241平仓与1634475339开仓都在12:45:01；1634492439平仓与1634498272开仓都在14:00:04。',
'   原因：管理函数成功平仓后，同一Cycle继续判断新入场；last_close仅每5秒从历史同步一次，还没更新就开了新单。',
'   改进：成功平仓当场保存冷却时间；平仓这一轮禁止重开；消失的持仓必须先在历史确认；TryEntry在发送前再次检查冷却。',
'   限制：不能断言这两笔亏损完全由冷却造成。修复后会跳过当时立即重开的动作，之后的价格路径和信号要重新测试。',
'2. 退出重新报价：1634504818在14:31:31出现138错误，14:31:36重试成功，最终盈利6.09美元。',
'   原来没有持久退出意图；失败后若价格回弹，触发条件可能消失，程序可能继续拿单。',
'   改进：退出理由在请求前持久保存，失败后保留；重新报价/价格改变等待1秒，缺报价3秒，忙碌5秒，超时/断线10秒后重新确认订单和报价。',
'   每次只发送一次该订单的平仓请求；同订单仍存在才重试；断线、陈旧报价、权限不满足时不发送；原服务器止损止盈保留。',
'3. 第8笔并非纯策略退出：开仓白银60.70，原止损60.36、止盈61.38；最终止损60.60、止盈60.86。',
'   原生终端日志21:18:22起有连续修改；自动程序事件无对应修改记录，且原程序不会在亏损时提保本或修改TP。修改者不能仅凭日志确定。',
'   该笔按改后的止损60.60退出，亏损1.00。与其余7笔分开标记，不能把它当作原退出规则的独立样本。',
'   改进：记录程序之外观察到的SL/TP变化，允许已授权的手动调整，但标记混合操作。程序自身仍不放宽现有止损。','',
'四、对交易规则的反思',
'v0.4同时放宽多个入场条件、改为M5和缩短持有时间，满足了更频繁练习，但缺乏分别验证，无法归因。',
'H1已完成K线的EMA50方向可能滞后于M5拐点；看到图上随后下跌，不能倒推当时必然应做空。',
'前7笔未发现程序之外保护线修改的订单仍净亏5.84美元；执行修复不能掩盖当前策略没有证明盈利。',
'样本只有8笔、同一天、两个相关金属品种，而且其中1笔有外部修改；不能把25%当作长期胜率，也不能声称已有统计优势。',
'初始TP是价格止损距离的2倍，但保本、利润回撤和20分钟退出会改变实际收益分布，不能用“2:1”直接推导预期赚钱。',
'峰值来自程序观察到的新鲜报价估计，零值被以0起始截断；并非所有成交Tick的真实MFE。v0.4没有可靠MAE，不补造。',
'当前不是新闻策略：没有接入可核实的实时经济日历，不伪称已经避开重大新闻。','',
'五、v0.5生效规则',
'范围：硬锁同一MetaQuotes-Demo模拟账号；真实账号、其他账号、重复控制器均禁止交易操作。',
'交易：黄金/白银；同时最多1笔（其他账户订单也会挡新入场）；每笔预留风险≤余额/净值较小者的1%，手数≤0.01。',
'累计亏损与每日次数：沿用用户明确授权，不设上限；不自动加倍、不加仓摊平、不加大风险追回亏损。',
'入场保持v0.4：H1已完成收盘相对EMA50定方向；M5已完成收盘同时满足蜡烛方向、相对上根收盘和EMA20；新M5开始后120秒内才考虑。',
'止损：前三根已完成M5结构极值±0.2ATR，考虑卖单Ask点差；初始成本距离扩展后再按预算定手数，最小手数超预算则跳过。',
'退出保持原阈值：达到1R尝试经济保本；观察峰值≥1.5R后回撤≥0.5R退出；持有20分钟退出；平仓冷却5分钟。',
'修复后的退出请求不能因一时回弹被取消。止损止盈在服务器；保本、回撤、定时管理依赖MT4运行和连接。',
'新日志：entry-features.csv记录下单前和成交后的因果特征；closed-trades.csv记录实际净盈亏、初始/最终保护价格、退出意图、观察峰值/谷值和外部修改标记。',
'执行修复是规则实施质量改善，盈利效果仍未验证。','',
'六、后续优化方法',
'固定v0.5规则收集后续独立模拟样本，每笔自动留证，不因刚亏一笔立即改阈值。',
'例行复盘可以先在新增30笔或一个完整交易日后进行；这是整理资料的节奏，不是足够统计显著的证明。',
'分别核对：执行错误与冷却合规、按品种/方向的扣费净期望、盈亏分布、持仓时间、真实逐Tick可观测程度、点差和外部修改。',
'候选规则一次只变一个概念，例如“增加M15方向一致性”，先记录为影子假设，不直接用这8笔选出看起来最好的参数。',
'回测必须按时间划分训练、验证和从未用于调参的后续区间；将测试过的所有候选保留在研究登记中，不只展示赢家。',
'仅M5 OHLC不能知道同根K线内先触碰SL还是TP，历史点差为0也不能当作免费成交；遇到歧义保守标记，使用真实双边Tick验证。',
'比较时纳入佣金、点差、滑点和失败退出；跨不同波动环境检查，不把一个时间段的收益当成保证。',
'自动化负责执行固定规则、收集证据；这一版本不会自行不断搜索并替换入场参数。后续参数升级需要新的评估证据。','',
'七、核实过的参考资料',
'MetaQuotes OrderClose：返回值、价格与滑点参数。 https://docs.mql4.com/trading/orderclose',
'MetaQuotes RefreshRates：更新图表预定义价格，其他品种仍通过SymbolInfoTick读取。 https://docs.mql4.com/series/refreshrates',
'MetaQuotes 错误码：138重新报价、135价格改变、128超时等。 https://docs.mql4.com/en/constants/errorswarnings/errorcodes',
'CME交易日志：记录入场、目标、指标和逐日复盘，区分成功和错误来源。 https://www.cmegroup.com/education/courses/building-a-trade-plan/keep-a-trade-log',
'Bailey等，The Probability of Backtest Overfitting：反复筛选策略导致样本内表现误导，必须审查样本外可靠性。 https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf',
'资料用于制定复盘与验证方法，没有任何一篇证明当前M5规则能盈利。','',
'相关证据：audit-history.csv、events.csv、trade-review.json、native-protection-edits.txt、guard-review-v0.5.json、self-test-v0.5.json、execution-regression-v0.5.json。']
(ROOT/'交易复盘与优化-v0.5.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
first=ROOT.parent/'trade-records'/'frequent-demo-v0.4'/'first-order.json'
old=json.loads(first.read_text(encoding='utf-8-sig'))
old.update({'Status':'closed','CloseTimeServer':trades[0]['close_server'],'ClosePrice':float(trades[0]['close_price']),
    'RealizedNetUSD':float(trades[0]['net']),'ExitReason':'TIME_EXIT_20_MINUTES','FinalStatusVerifiedFrom':'native audit-history.csv'})
first.write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in stats.items() if k!='trades_detail'},ensure_ascii=False))
