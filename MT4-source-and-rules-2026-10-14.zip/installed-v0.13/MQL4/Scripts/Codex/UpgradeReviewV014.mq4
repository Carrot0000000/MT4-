﻿#property strict
#property version "2.400"
#include <Codex/AutopilotCore.mqh>
#include <Codex/BudgetAdmission.mqh>
#include <Codex/ForwardCore.mqh>
#include <Codex/ProfitProtection.mqh>
#include <Codex/SnapshotWriter.mqh>
#include <Codex/ExecutionTiming.mqh>
#include <Codex/EntrySlippage.mqh>
#include <Codex/Capital150.mqh>
int passed=0,failed=0;
void Check(const bool condition,const string label)
{ if(condition)passed++;else{failed++;Print("AP self-test FAILED: ",label);} }
bool Near(const double a,const double b){return MathAbs(a-b)<1e-7;}
void RunCoreTests()
{
   Check(Near(APPracticeBudget(10000,10000,500,1),5),"large broker demo balance remains at five dollar risk");
   Check(Near(APPracticeBudget(500,480,500,1),4.8),"smaller broker equity reduces risk budget");
   Check(APPracticeBudget(10000,10000,501,1)==0,"practice capital above authorized cap rejected");
   Check(APPracticeBudget(10000,10000,500,3.01)==0,"risk percent above three rejected");
   Check(APPracticeBudget(10000,0,500,1)==0,"zero equity blocks budget");
   Check(APPracticeBudget(10000,10000,0,1)==0,"zero practice capital blocks budget");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,176318407,"MetaQuotes-Demo",false),"old login remains isolated");
   Check(APIdentity(ACCOUNT_TRADE_MODE_DEMO,48530368,"FPMarketsLtd-Demo2",false),"expected demo allowed");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_REAL,48530368,"FPMarketsLtd-Demo2",false),"real blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_CONTEST,48530368,"FPMarketsLtd-Demo2",false),"contest blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,1,"FPMarketsLtd-Demo2",false),"other login blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,48530368,"FPMarketsLtd-Live5",false),"other server blocked");
   Check(!APIdentity(ACCOUNT_TRADE_MODE_DEMO,48530368,"FPMarketsLtd-Demo2",true),"tester isolated");
   Check(Near(APLots(2.5,19.16,.02,.01,1,.01,.01,100,0),0),"minimum not forced up");
   Check(Near(APLots(10,4.99,.02,.01,1,.01,.01,100,0),.01),"floor under budget");
   Check(Near(APLots(10,5,.02,0,1,.01,.01,100,0),0),"zero tick blocks");
   Check(Near(APLots(10,5,.02,.01,1,.01,.01,100,-1),0),"negative cost blocks");
   Check(Near(APPrice(4185.951,.01,2,false),4185.95),"buy stop outward");
   Check(Near(APPrice(4185.951,.01,2,true),4185.96),"sell stop outward");
   Check(Near(APStop(100,5,-1,.3,.01,2),101.3),"Bid pivot to Ask stop");
   Check(Near(APStop(100,5,1,.3,.01,2),99),"buy structure");
   Check(Near(APNet(1,4205.11,4200.12,1,0),-4.99),"spread not charged twice");
   for(int side=-1;side<=1;side+=2)
   {
      double level=APBreakEven(100,10,.5,.02,.01,2,side);
      Check(APNet(side,100,level-side*.02,10,.5)>=.1-1e-7,"economic BE fees and reserve");
   }
   Check(!APGiveback(1.49,1,1),"profit gate not reached");
   Check(!APGiveback(1.7,1.21,1),"not enough giveback");
   Check(APGiveback(1.7,1.2,1),"giveback exit");
   double silver_floor=APMinimumRiskForSpread(.03,.1,.02,.01,10,.01,0);
   Check(Near(silver_floor,3.2),"spread and slip minimum risk");
   Check(silver_floor>495.01*.005,"0.5 percent incompatible at this spread");
   Check(silver_floor<495.01*.01,"1 percent removes this necessary-condition conflict");
   Check(Near(APLots(495.01*.01,.45,.02,.01,10,.01,.01,.01,0),.01),"silver minimum fits new budget");
   Check(Near(APLots(495.01*.005,.45,.02,.01,10,.01,.01,.01,0),0),"same structure rejected at old budget");
   Check(APMinimumRiskForSpread(.03,0,.02,.01,10,.01,0)<0,"invalid spread fraction marked unknown");
   Check(APEntryWindow(1000,1060)&&!APEntryWindow(1000,1061)&&!APEntryWindow(1000,999),"entry window boundaries");
   Check(!APEntryWindow(0,30),"unknown bar never eligible");
   Check(APRecordChanged(0,0,1000,AP_TRIGGER),"first refusal recorded");
   Check(!APRecordChanged(1000,AP_TRIGGER,1000,AP_TRIGGER),"same refusal not flooded per tick");
   Check(APRecordChanged(1000,AP_TRIGGER,1000,AP_BUDGET),"changed refusal within bar recorded");
   Check(APRecordChanged(1000,AP_TRIGGER,1900,AP_TRIGGER),"same refusal on new bar recorded");
   Check(APCheckText(AP_BUDGET)!=""&&APCheckText(AP_QUOTE)!=APCheckText(AP_BUDGET),"quote and budget causes distinguished");
   Check(APBias(101,100)==1,"simple H1 long bias");
   Check(APBias(99,100)==-1,"simple H1 short bias");
   Check(APBias(100,100)==0,"flat H1 has no forced direction");
   Check(APBias(0,100)==0,"missing H1 price blocked");
   Check(APMomentum(1,100,100.8,100.5,100.4),"buy momentum without requiring high breakout");
   Check(APMomentum(-1,100,99.2,99.5,99.6),"sell momentum");
   Check(!APMomentum(-1,100,100.8,100.5,100.4),"counter-direction momentum rejected");
   Check(!APMomentum(1,100,100,99,99),"doji not forced into a trade");
   Check(Near(APRangeExtreme(99,98,97,1),97),"closed-bar low extreme");
   Check(Near(APRangeExtreme(101,102,103,-1),103),"closed-bar high extreme");
   Check(APRangeExtreme(0,98,97,1)==0,"missing stop structure blocked");
   Check(Near(APDriftLimit(.05,.01,.25),.02),"drift limit respects quote ticks");
   Check(Near(APDriftLimit(4,.01,.25),1),"drift limit uses ATR for larger ranges");
   Check(APDriftLimit(0,.01,.25)==0,"invalid ATR drift blocked");
   Check(APEntryWindow(1000,1120,120)&&!APEntryWindow(1000,1121,120),"M5 two-minute window boundary");
   Check(!APEntryWindow(1000,1300,120),"expired M5 signal blocked");
   Check(Near(APMinimumRiskForSpread(.03,.2,.02,.01,10,.01,0),1.7),"M5 spread-cost lower bound");
   Check(Near(APCostAwareInitialStop(99.95,100,.02,.2,.01,2,1),99.89),"initial buy stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(100.05,100,.02,.2,.01,2,-1),100.11),"initial sell stop covers spread while remaining outside structure");
   Check(Near(APCostAwareInitialStop(99,100,.02,.2,.01,2,1),99),"already wider structural stop is preserved");
   Check(APCostAwareInitialStop(99,100,.02,0,.01,2,1)==0,"invalid cost ratio blocks stop calculation");
   // Reproduce the two same-cycle v0.4 reopenings and the server-stop transition.
   Check(!APEntryCycleReady(true,true,1000,1000,5),"accepted close cannot reopen in same cycle");
   Check(!APEntryCycleReady(true,true,1000,1000,0),"same-cycle block applies even with zero cooldown");
   Check(!APEntryCycleReady(false,false,1400,1000,5),"unconfirmed history cannot reopen");
   Check(!APEntryCycleReady(false,true,1299,1000,5),"full 300 second cooldown enforced");
   Check(APEntryCycleReady(false,true,1300,1000,5),"eligible again at cooldown boundary");
   Check(!APCooldownReady(1000,1001,5),"future close timestamp blocks entries");
   Check(APCooldownReady(1000,0,5),"new session without earlier trades permitted");
   Check(!APCooldownReady(1000,0,-1),"negative cooldown invalid");
   Check(APStickyExit(AP_EXIT_GIVEBACK,AP_EXIT_NONE)==AP_EXIT_GIVEBACK,"rebound cannot cancel requested giveback exit");
   Check(APStickyExit(AP_EXIT_TIME,AP_EXIT_GIVEBACK)==AP_EXIT_TIME,"original exit reason survives retry and restart");
   Check(APStickyExit(AP_EXIT_NONE,AP_EXIT_GIVEBACK)==AP_EXIT_GIVEBACK,"exit request latched");
   Check(APRetrySeconds(138)==1&&APRetrySeconds(135)==1,"requote and changed price bounded retry");
   Check(APRetrySeconds(128)==10&&APRetrySeconds(6)==10,"uncertain acknowledgement reconciles with backoff");
   Check(APRetrySeconds(146)>=5&&APRetrySeconds(136)>=3,"busy and off-quotes do not spin");
   for(int wait_index=0;wait_index<75;wait_index++)
   {
      if(IsConnected()&&APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())&&APFinitePositive(AccountBalance()))break;
      Sleep(200);
   }
   bool history_ready=false;
   for(int history_wait=0;history_wait<75;history_wait++)
   {
      MqlRates rates[];
      CopyRates("XAUUSD",PERIOD_M5,0,120,rates);CopyRates("XAGUSD",PERIOD_M5,0,120,rates);
      history_ready=iBars("XAUUSD",PERIOD_M5)>=101&&iBars("XAGUSD",PERIOD_M5)>=101;
      if(history_ready)break;
      Sleep(200);
   }
   FolderCreate("DemoAutopilot");
   int f=FileOpen("DemoAutopilot\\v014-core-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"passed\":"+IntegerToString(passed)+",\"failed\":"+IntegerToString(failed)+
         ",\"order_operations\":0,\"connected\":"+(IsConnected()?"true":"false")+
         ",\"expected_demo\":"+(APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())?"true":"false")+
         ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+"}");
      FileClose(f);
   }
   int data_file=FileOpen("DemoAutopilot\\v014-m5-preflight.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(data_file!=INVALID_HANDLE)
   {
      string json="{\"m5_history_ready\":"+(history_ready?"true":"false")+",\"order_operations\":0,\"symbols\":[";
      string names[2]={"XAUUSD","XAGUSD"};
      for(int i=0;i<2;i++)
      {
         string symbol=names[i];if(i>0)json+=",";
         double h1_close=iClose(symbol,PERIOD_H1,1),h1_ema=iMA(symbol,PERIOD_H1,50,0,MODE_EMA,PRICE_CLOSE,1);
         int side=APBias(h1_close,h1_ema);
         bool momentum=APMomentum(side,iOpen(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,1),iClose(symbol,PERIOD_M5,2),iMA(symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE,1));
         json+="{\"symbol\":\""+symbol+"\",\"m5_bars\":"+IntegerToString(iBars(symbol,PERIOD_M5))+
            ",\"h1_bars\":"+IntegerToString(iBars(symbol,PERIOD_H1))+",\"h1_direction\":"+IntegerToString(side)+
            ",\"last_closed_m5_momentum_matches\":"+(momentum?"true":"false")+"}";
      }
      FileWriteString(data_file,json+"]}");FileClose(data_file);
   }
   Print("AP self-test: passed=",passed," failed=",failed,"; no order operations.");
}


struct Spec { double tick,value,point,minimum,step,maximum,spread,bid,ask,slip; int digits; };
string key="mock.",symbols[2]={"XAUUSD","XAGUSD"},mode="";
bool have_owner=true,working=false,closed_this_cycle=false,quotes_fresh[2]={false,false};
bool AutoEntries=true;int CooldownMinutes=5,MaximumHoldMinutes=20,SlippagePoints=20;
datetime last_status=0,last_sync=0,last_history_request=0,last_metrics_flush=0;
double current_spreads[2]={0,0},spread_minimum_risks[2]={0,0},RoundTripFeePerLotUSD=0,MaxSpreadFraction=.2;
string mock_names[200];double values[200];int vars=0;
bool mock_live=false,mock_visible=true,mock_mutation=true,mock_identity=true,mock_owner=true,mock_fresh=true;
bool mock_delay_history=false,mock_close_on_error=false;
int mock_error=0,mock_last_error=0,mock_closes=0,mock_entries=0,mock_tightens=0;
datetime mock_now=2200,mock_open=1000,mock_closed=0;
double mock_bid=102,mock_ask=102.02,mock_sl=95,mock_tp=110;
string K(const string field,const int ticket=0){return key+field+(ticket>0?"."+IntegerToString(ticket):"");}
int V(const string name){for(int i=0;i<vars;i++)if(mock_names[i]==name)return i;return -1;}
double FakeGlobalVariableGet(const string name){int i=V(name);return i>=0?values[i]:0;}
datetime FakeGlobalVariableSet(const string name,const double value)
{int i=V(name);if(i<0){i=vars++;mock_names[i]=name;}values[i]=value;return mock_now;}
bool FakeGlobalVariableCheck(const string name){return V(name)>=0;}
void FakeGlobalVariablesFlush(){}
bool Identity(){return mock_identity;}bool Owner(){return mock_owner;}
bool MutationAllowed(){return mock_identity&&mock_owner&&mock_mutation;}
bool Paused(){return FakeGlobalVariableGet(K("pause"))>0||FakeGlobalVariableGet(K("halt"))>0;}
int IndexOf(const string symbol){return symbol=="XAUUSD"?0:1;}
bool IsOwnedSelected(){return true;}
int OwnedCount(){return mock_live?1:0;}
bool FakeOrderSelect(const int value,const int select,const int pool=MODE_TRADES)
{return mock_live||(mock_visible&&mock_closed>0);}
int FakeOrdersTotal(){return mock_live?1:0;}
datetime FakeOrderCloseTime(){return mock_live?0:mock_closed;}
int FakeOrderTicket(){return 123;}
string FakeOrderSymbol(){return "XAUUSD";}
int mock_side=OP_BUY;
int FakeOrderType(){return mock_side;}
double FakeOrderLots(){return .01;}
datetime FakeOrderOpenTime(){return mock_open;}
double FakeOrderOpenPrice(){return 100;}
double FakeOrderStopLoss(){return mock_sl;}
double FakeOrderTakeProfit(){return mock_tp;}
double FakeOrderCommission(){return mock_commission;}
double FakeOrderSwap(){return mock_swap;}
datetime FakeTimeCurrent(){return mock_now;}
datetime FakeTimeLocal(){return mock_now;}
bool FakeRefreshRates(){return true;}
double FakeOrderClosePrice(){return mock_side==OP_BUY?mock_bid:mock_ask;}
void FakeResetLastError(){mock_last_error=0;}
int FakeGetLastError(){return mock_last_error;}
bool FakeIsConnected(){return mock_connected;}bool FakeIsTradeAllowed(){return true;}
bool FakeOrderClose(const int ticket,const double lots,const double price,const int slippage,const color arrow)
{
   mock_closes++;mock_last_error=mock_error;
   if(mock_error==0||mock_close_on_error){mock_live=false;mock_closed=mock_now;mock_visible=!mock_delay_history;}
   return mock_error==0;
}

bool FakeOrderModify(const int ticket,const double open,const double sl,const double tp,const datetime expiry,const color arrow)
{
   mock_tightens++;mock_last_tighten=sl;mock_last_error=mock_error;
   if(mock_error!=0)return false;
   mock_sl=sl;mock_tp=tp;return true;
}

bool ReadSpec(const int index,Spec &s)
{s.tick=.01;s.value=1;s.point=.01;s.minimum=.01;s.step=.01;s.maximum=100;s.spread=.02;
 s.bid=mock_bid;s.ask=mock_ask;s.slip=.05;s.digits=2;
 if(mock_silver){s.tick=.001;s.value=5;s.point=.001;s.spread=.048;s.slip=.02;s.digits=3;}return mock_fresh;}
void Event(const string action,const string symbol,const int ticket,const string details){mock_event_count++;}
void SyncClosed()
{
   if(!mock_live&&mock_visible&&mock_closed>FakeGlobalVariableGet(K("last_close")))
      FakeGlobalVariableSet(K("last_close"),(double)mock_closed);
}

void RequestHistory(){}void Display(){}void Status(){}
void LabCycle(){}
void AlignedCycle(){}
void AlignedCycle12(){}
void AlignedCycle13(){}
string Escape(string s)
{ StringReplace(s,"\\","\\\\");StringReplace(s,"\"","\\\"");StringReplace(s,"\r"," ");StringReplace(s,"\n"," ");return s; }
string PermissionMode(){return "mock permission unavailable";}
void TryEntry(const int index);

double PracticeCapitalUSD=500,RiskPercent=1,MaximumLots=.01,EntryDriftATR=.25;
const ENUM_TIMEFRAMES ENTRY_TF=PERIOD_M5;
const int ENTRY_SECONDS=300,MAGIC=2026101217;
bool EnableForwardResearch=true;
int EntryWindowSeconds=120,mock_leverage=500,mock_event_count=0,mock_sends=0;
datetime last_draw=0,attempted[2]={0,0};
int admission_codes[2]={0,0},last_codes[2]={0,0},check_counts[2]={0,0};
double admission_floors[2]={-1,-1},minimum_lots[2]={-1,-1};
double last_budgets[2]={-1,-1},last_minimum_risks[2]={-1,-1};
datetime last_bars[2]={0,0},last_local_checks[2]={0,0},last_server_checks[2]={0,0};
string reasons[2]={"",""};
bool mock_connected=true,mock_silver=false,mock_aligned_signal=false;
double mock_commission=0,mock_swap=0,mock_last_tighten=0;
int FakeAccountLeverage(){return mock_leverage;}
double mock_balance=10000;
double FakeAccountBalance(){return mock_balance;}
double FakeAccountEquity(){return 10000;}
datetime FakeiTime(const string symbol,const int frame,const int shift)
{return (datetime)((mock_now/(frame*60))*frame*60-shift*frame*60);}
int FakeiBars(const string symbol,const int frame){return 101;}
double FakeiClose(const string symbol,const int frame,const int shift){return mock_aligned_signal&&frame==PERIOD_M5&&shift==2?(mock_direction==1?99.9:100.1):100;}
double FakeiOpen(const string symbol,const int frame,const int shift){return mock_aligned_signal?(mock_direction==1?99.8:100.2):100;}
double FakeiMA(const string symbol,const int frame,const int period,const int shift,const int method,const int price,const int bar){return !mock_aligned_signal?99:frame==PERIOD_M5?(mock_direction==1?99.95:100.05):frame==PERIOD_M15?(bar==1?99.5:99.4):99;}
double FakeiATR(const string symbol,const int frame,const int period,const int bar){return 1;}
double FakeMarketInfo(const string symbol,const int item){return item==MODE_TRADEALLOWED?1:(mock_aligned_signal&&item==MODE_MARGINREQUIRED?1000:0);}
double FakeAccountFreeMarginCheck(const string symbol,const int type,const double lots){return 500;}
int FakeOrderSend(const string symbol,const int type,const double lots,const double price,const int slip,const double sl,const double tp,const string note,const int magic,const datetime expiry,const color arrow)
{mock_sends++;return -1;}
int mock_direction=1;double mock_structure=99;
int Direction(const string symbol){return mock_direction;}
double RecentStructure(const string symbol,const int side){return mock_structure;}
bool EntryJournal(const int index,const int ticket,const int side,const Spec &s,const double lots,const double fill,const double sl,const double tp,const double risk,const double budget){return true;}

#define GlobalVariableGet FakeGlobalVariableGet
#define GlobalVariableSet FakeGlobalVariableSet
#define GlobalVariableCheck FakeGlobalVariableCheck
#define GlobalVariablesFlush FakeGlobalVariablesFlush
#define OrderSelect FakeOrderSelect
#define OrdersTotal FakeOrdersTotal
#define OrderCloseTime FakeOrderCloseTime
#define OrderTicket FakeOrderTicket
#define OrderSymbol FakeOrderSymbol
#define OrderType FakeOrderType
#define OrderLots FakeOrderLots
#define OrderOpenTime FakeOrderOpenTime
#define OrderOpenPrice FakeOrderOpenPrice
#define OrderStopLoss FakeOrderStopLoss
#define OrderTakeProfit FakeOrderTakeProfit
#define OrderCommission FakeOrderCommission
#define OrderSwap FakeOrderSwap
#define TimeCurrent FakeTimeCurrent
#define TimeLocal FakeTimeLocal
#define OrderClose FakeOrderClose
#define OrderClosePrice FakeOrderClosePrice
#include <Codex/ExecutionQuality.mqh>
#define RefreshRates FakeRefreshRates
#define ResetLastError FakeResetLastError
#define GetLastError FakeGetLastError
#define IsConnected FakeIsConnected
#define IsTradeAllowed FakeIsTradeAllowed
#define AccountLeverage FakeAccountLeverage
#define AccountBalance FakeAccountBalance
#define AccountEquity FakeAccountEquity
#define iTime FakeiTime
#define iBars FakeiBars
#define iClose FakeiClose
#define iOpen FakeiOpen
#define iMA FakeiMA
#define iATR FakeiATR
#define MarketInfo FakeMarketInfo
#define AccountFreeMarginCheck FakeAccountFreeMarginCheck
#define OrderSend FakeOrderSend
#define OrderModify FakeOrderModify
datetime ActionReadyAt(const int ticket,const bool closing)
{
   return APActionReadyAt((datetime)GlobalVariableGet(K(closing?"close_after":"modify_after",ticket)),
      (datetime)GlobalVariableGet(K("channel_after",ticket)),
      (datetime)GlobalVariableGet(K("action_after",ticket))); // preserve any legacy in-flight retry deadline
}
string ExitReasonText(const int intent)
{return intent==AP_EXIT_GIVEBACK?"PROFIT_PROTECTION_GIVEBACK":APExitText(intent);}
bool SafeTighten(const int ticket,const double target)
{
   if(!MutationAllowed()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   if(GlobalVariableGet(K("exit_intent",ticket))>0||TimeLocal()<ActionReadyAt(ticket,false))return false;
   int side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());Spec s;
   if(!ReadSpec(index,s)||!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))return false;
   double old=OrderStopLoss();
   if((side==1&&target<=old+s.tick*.5)||(side==-1&&target>=old-s.tick*.5))return false;
   double minimum=(MathMax(MarketInfo(OrderSymbol(),MODE_STOPLEVEL),MarketInfo(OrderSymbol(),MODE_FREEZELEVEL))+1)*s.point;
   if((side==1&&target>=s.bid-minimum)||(side==-1&&target<=s.ask+minimum))return false;
   string symbol=OrderSymbol();double open=OrderOpenPrice(),tp=OrderTakeProfit();
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderModify(ticket,open,target,tp,0,clrNONE);int error=GetLastError();
   if(ok)
   {GlobalVariableSet(K("observed_sl",ticket),target);GlobalVariableSet(K("observed_tp",ticket),tp);GlobalVariablesFlush();}
   Event(ok?"SL_TIGHTEN_ACCEPTED":"SL_TIGHTEN_FAILED",symbol,ticket,"sl="+DoubleToString(target,s.digits)+" error="+IntegerToString(error));
   GlobalVariableSet(K("modify_after",ticket),(double)(TimeLocal()+(ok?1:MathMax(5,APRetrySeconds(error)))));
   if(!ok&&APModifyBlocksClose(error))
      GlobalVariableSet(K("channel_after",ticket),(double)(TimeLocal()+APRetrySeconds(error)));
   GlobalVariablesFlush();
   return ok;
}
string DK(const int index,const string field){return K("d04."+symbols[index]+"."+field);}

void CheckOutcome(const int index,const int code,const double minimum_risk=-1,const bool force=false)
{
   reasons[index]=AP08CheckText(code);
   datetime bar=iTime(symbols[index],ENTRY_TF,0);
   if(!force&&!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds))return;
   bool changed=APRecordChanged(last_bars[index],last_codes[index],bar,code);
   last_bars[index]=bar;last_codes[index]=code;
   last_local_checks[index]=TimeLocal();last_server_checks[index]=TimeCurrent();
   last_budgets[index]=APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent);
   last_minimum_risks[index]=minimum_risk;
   if(!changed)return;
   check_counts[index]++;
   GlobalVariableSet(DK(index,"bar"),(double)bar);GlobalVariableSet(DK(index,"code"),code);
   GlobalVariableSet(DK(index,"local"),(double)last_local_checks[index]);
   GlobalVariableSet(DK(index,"server"),(double)last_server_checks[index]);
   GlobalVariableSet(DK(index,"budget"),last_budgets[index]);
   GlobalVariableSet(DK(index,"min_risk"),minimum_risk);GlobalVariableSet(DK(index,"count"),check_counts[index]);
   GlobalVariablesFlush();
   Event(code==AP_FILLED?"CHECK_ACCEPTED":"CHECK_REJECTED",symbols[index],0,
      "v0.13 timeframe=M5 bar_server="+TimeToString(bar,TIME_DATE|TIME_MINUTES)+" code="+IntegerToString(code)+
      " reason="+AP08CheckText(code)+" budget_usd="+DoubleToString(last_budgets[index],4)+
      " minimum_structural_risk_usd="+(minimum_risk>=0?DoubleToString(minimum_risk,4):"unknown")+
      " spread_gate_risk_lower_bound_usd="+(quotes_fresh[index]?DoubleToString(spread_minimum_risks[index],4):"unknown"));
}

void RefreshAdmission(const int index,const Spec &s)
{
   minimum_lots[index]=s.minimum;
   admission_floors[index]=APAdmissionRiskFloor(s.spread,MaxSpreadFraction,s.slip+APEntryReserve(SlippagePoints,s.point),s.tick,s.value,s.minimum,
      RoundTripFeePerLotUSD,MarketInfo(symbols[index],MODE_STOPLEVEL),s.point);
   admission_codes[index]=APAdmissionCode(admission_floors[index],
      APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),s.minimum,MathMin(s.maximum,MaximumLots));
}

bool ReconcileFlat()
{
   if(OrdersTotal()!=0)return false;
   int ticket=(int)GlobalVariableGet(K("last_live_ticket"));
   if(ticket>0)
   {
      if(!OrderSelect(ticket,SELECT_BY_TICKET)||!IsOwnedSelected()||OrderCloseTime()==0)return false;
      datetime closed=OrderCloseTime(),latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      GlobalVariableSet(K("last_live_ticket"),0);closed_this_cycle=true;
      SyncClosed();last_sync=TimeLocal();GlobalVariablesFlush();
   }
   return true;
}

bool EntryGate()
{
   if(!Identity()||!Owner()||OrdersTotal()!=0||Paused()||!AutoEntries)return false;
   bool reconciled=ReconcileFlat();
   return APEntryCycleReady(closed_this_cycle,reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes);
}

bool SafeClose(const int ticket,const int requested)
{
   if(!Identity()||!Owner()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int previous_intent=(int)GlobalVariableGet(K("exit_intent",ticket));
   int intent=APStickyExit(previous_intent,requested);
   if(intent!=previous_intent){GlobalVariableSet(K("exit_intent",ticket),intent);GlobalVariablesFlush();}
   if(TimeLocal()<ActionReadyAt(ticket,true))return false;
   if(!MutationAllowed())return false;
   string symbol=OrderSymbol();int index=IndexOf(symbol);Spec s;
   RefreshRates();
   if(!ReadSpec(index,s))return false;
   double lots=OrderLots(),price=OrderType()==OP_BUY?s.bid:s.ask;
   // The same account and ownership guards are rechecked immediately before every mutation.
   if(!MutationAllowed())return false;
   int eq_side=OrderType()==OP_BUY?1:-1;uint eq_started=GetTickCount();
   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();
   uint eq_elapsed=(uint)(GetTickCount()-eq_started);double eq_actual=0;
   if(ok)
   {
      // Persist immediately; SyncClosed's periodic scan was too late in v0.4.
      datetime closed=TimeCurrent();
      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0){closed=OrderCloseTime();eq_actual=OrderClosePrice();}
      datetime latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      closed_this_cycle=true;GlobalVariablesFlush();
   }
   EQRecord(false,symbol,ticket,eq_side,lots,price,eq_actual,ok,error,eq_elapsed,s.spread,lots*s.value/s.tick);
   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,ExitReasonText(intent)+" error="+IntegerToString(error));
   GlobalVariableSet(K("close_after",ticket),(double)(TimeLocal()+(ok?1:APRetrySeconds(error))));
   GlobalVariablesFlush();
   return ok;
}

void ObserveProtectionSelected()
{
   int ticket=OrderTicket();double sl=OrderStopLoss(),tp=OrderTakeProfit();
   if(GlobalVariableCheck(K("observed_sl",ticket)))
   {
      double old_sl=GlobalVariableGet(K("observed_sl",ticket)),old_tp=GlobalVariableGet(K("observed_tp",ticket));
      if(MathAbs(sl-old_sl)>1e-7||MathAbs(tp-old_tp)>1e-7)
      {
         GlobalVariableSet(K("outside_change",ticket),1);
         Event("PROTECTION_CHANGED_OUTSIDE_EA",OrderSymbol(),ticket,"old_sl="+DoubleToString(old_sl,8)+" new_sl="+DoubleToString(sl,8)+
            " old_tp="+DoubleToString(old_tp,8)+" new_tp="+DoubleToString(tp,8)+" actor_unknown; retain permitted user adjustment");
      }
   }
   GlobalVariableSet(K("observed_sl",ticket),sl);GlobalVariableSet(K("observed_tp",ticket),tp);
}

void Manage()
{
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)||!IsOwnedSelected())continue;
      int ticket=OrderTicket(),side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());
      GlobalVariableSet(K("last_live_ticket"),ticket);
      ObserveProtectionSelected();
      Spec s;if(!ReadSpec(index,s))continue;
      if(GlobalVariableGet(K("flatten"))>0){SafeClose(ticket,AP_EXIT_USER);continue;}
      if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_PROTECTION);continue;}
      if(!GlobalVariableCheck(K("initial_R",ticket)))
      {
         // A crash immediately after OrderSend can recover the prior persisted plan.
         double pending=GlobalVariableGet(K("pending_R"));
         if(APFinitePositive(pending))GlobalVariableSet(K("initial_R",ticket),pending);
         else{GlobalVariableSet(K("halt"),1);mode="暂停：持仓初始风险状态缺失";continue;}
      }
      double r=GlobalVariableGet(K("initial_R",ticket));
      double units=OrderLots()*s.value/s.tick;
      double cost=APConservativeCost(OrderLots(),RoundTripFeePerLotUSD,OrderCommission(),OrderSwap());
      if(cost<0){GlobalVariableSet(K("halt"),1);mode="费用数据异常，暂停新单";continue;}
      double remaining_risk=MathMax(0,side*(OrderOpenPrice()-OrderStopLoss()))*units+s.slip*units+cost;
      if(remaining_risk>r+0.01)
      {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_RISK);continue;}
      double price=side==1?s.bid:s.ask;
      double net=APNet(side,OrderOpenPrice(),price,units,cost);
      double peak=MathMax(net,GlobalVariableGet(K("peak",ticket)));
      GlobalVariableSet(K("peak",ticket),peak);
      double worst=GlobalVariableCheck(K("worst",ticket))?GlobalVariableGet(K("worst",ticket)):net;
      GlobalVariableSet(K("worst",ticket),MathMin(net,worst));
      if(TimeLocal()-last_metrics_flush>=5){GlobalVariablesFlush();last_metrics_flush=TimeLocal();}
      int intent=(int)GlobalVariableGet(K("exit_intent",ticket));
      if(intent>0){SafeClose(ticket,intent);continue;}
      if(APProtectedGiveback(peak,net,r)){SafeClose(ticket,AP_EXIT_GIVEBACK);continue;}
      if(MaximumHoldMinutes>0 && TimeCurrent()-OrderOpenTime()>=MaximumHoldMinutes*60)
      {SafeClose(ticket,AP_EXIT_TIME);continue;}
      if(TimeLocal()<ActionReadyAt(ticket,false))continue;
      if(APProtectedNet(peak,r)>=0)
      {
         double be=APProtectedStop(OrderOpenPrice(),units,cost,s.slip,s.tick,s.digits,side,peak,r);
         if(APFinitePositive(be))SafeTighten(ticket,be);
      }
   }
   if(OwnedCount()==0 && GlobalVariableGet(K("flatten"))>0)GlobalVariableSet(K("flatten"),0);
}

void Cycle()
{
   if(working)return;working=true;closed_this_cycle=false;uint eq_cycle_start=GetTickCount();
   if(!Identity()||!Owner()||!IsConnected())
      for(int qi=0;qi<2;qi++){quotes_fresh[qi]=false;admission_codes[qi]=AP_SPEC_INVALID;admission_floors[qi]=-1;}
   if(!Identity())mode="账户不匹配，禁止交易";
   else if(!Owner())mode="重复实例，禁止交易";
   else if(!IsConnected())mode="断线；等待连接";
   else
   {
      if(TimeLocal()-last_history_request>=5){RequestHistory();last_history_request=TimeLocal();}
      Spec tmp;for(int i=0;i<2;i++)
      {
         quotes_fresh[i]=ReadSpec(i,tmp);
         if(quotes_fresh[i])
         {
            RefreshAdmission(i,tmp);
            current_spreads[i]=tmp.spread;
            spread_minimum_risks[i]=APMinimumRiskForSpread(tmp.spread,MaxSpreadFraction,tmp.slip+APEntryReserve(SlippagePoints,tmp.point),tmp.tick,tmp.value,tmp.minimum,RoundTripFeePerLotUSD);
         }
      }
      if(TimeLocal()-last_sync>=5){SyncClosed();last_sync=TimeLocal();}
      Manage();
      bool flat_reconciled=OrdersTotal()==0?ReconcileFlat():false;
      if(GlobalVariableGet(K("halt"))>0)mode="异常暂停，检查记录";
      else if(!IsTradeAllowed())mode=PermissionMode();
      else if(AccountLeverage()!=500)mode="杠杆不是1:500，暂停新单";
      else if(!AutoEntries||Paused())mode="暂停新单";
      else if(OrdersTotal()>0)mode=OwnedCount()>0?"持仓实时管理":"已有其他订单，暂停新单";
      else if(!flat_reconciled)mode="等待平仓记录确认";
      else if(!APEntryCycleReady(closed_this_cycle,flat_reconciled,TimeCurrent(),(datetime)GlobalVariableGet(K("last_close")),CooldownMinutes))mode="平仓后冷却，继续观察";
      else
      {
         mode="持续观察，条件满足才入场";
         for(int i=0;i<2;i++){TryEntry(i);if(OrdersTotal()>0)break;}
      }
   }
   // Broker position management and entries above always run before read-only research.
   LabCycle();EPCycle();AlignedCycle();AlignedCycle12();AlignedCycle13();
   if(TimeLocal()!=last_draw){Display();last_draw=TimeLocal();}
   if(TimeLocal()-last_status>=5){Status();last_status=TimeLocal();}
   eq_cycle_last_ms=(uint)(GetTickCount()-eq_cycle_start);if(eq_cycle_last_ms>eq_cycle_max_ms)eq_cycle_max_ms=eq_cycle_last_ms;
   working=false;
}

void TryEntry(const int index){if(EntryGate())mock_entries++;}
void ResetScenario()
{
   mock_direction=1;mock_structure=99;mock_balance=10000;mock_aligned_signal=false;mock_side=OP_BUY;vars=0;RoundTripFeePerLotUSD=0;mock_leverage=500;mock_connected=true;mock_silver=false;mock_event_count=0;mock_sends=0;mock_commission=0;mock_swap=0;mock_last_tighten=0;last_draw=0;mock_live=true;mock_visible=true;mock_mutation=true;mock_identity=true;mock_owner=true;mock_fresh=true;
   mock_delay_history=false;mock_close_on_error=false;mock_error=0;mock_last_error=0;
   mock_closes=0;mock_entries=0;mock_tightens=0;mock_now=2200;mock_open=1000;mock_closed=0;
   mock_bid=102;mock_ask=102.02;mock_sl=95;mock_tp=110;working=false;closed_this_cycle=false;last_sync=0;last_status=0;
   last_history_request=0;last_metrics_flush=0;CooldownMinutes=5;MaximumHoldMinutes=20;AutoEntries=true;
   GlobalVariableSet(K("initial_R",123),6);GlobalVariableSet(K("peak",123),0);
}
int exec_passed=0,exec_failed=0;string failure_labels="";
void ECheck(const bool okay,const string label)
{if(okay)exec_passed++;else{exec_failed++;failure_labels+=(failure_labels==""?"":",")+"\""+label+"\"";Print("Execution regression FAILED: ",label);}}
void RunExecutionTests()
{
   ResetScenario();Cycle();
   ECheck(mock_closes==1&&!mock_live&&mock_entries==0,"time exit plus eligible new signal does not reopen same cycle");
   ECheck(GlobalVariableGet(K("last_close"))==2200,"accepted close writes cooldown immediately");
   mock_now=2499;Cycle();ECheck(mock_entries==0,"one second before cooldown remains blocked");
   mock_now=2500;Cycle();ECheck(mock_entries>0,"new entries eligible at 300 seconds");

   ResetScenario();mock_delay_history=true;Cycle();
   mock_now=2600;Cycle();ECheck(mock_entries==0,"missing history blocks reopening beyond nominal cooldown");
   mock_visible=true;Cycle();ECheck(mock_entries==0,"confirmation cycle cannot reopen");
   Cycle();ECheck(mock_entries>0,"confirmed earlier close permits later cycle");

   ResetScenario();MaximumHoldMinutes=0;mock_open=2100;Manage();
   mock_live=false;mock_closed=2210;mock_now=2210;mock_visible=false;Cycle();
   ECheck(mock_entries==0,"server stop with delayed history blocks new signal");
   mock_visible=true;Cycle();ECheck(GlobalVariableGet(K("last_close"))==2210&&mock_entries==0,"server exit starts cooldown");

   ResetScenario();MaximumHoldMinutes=0;mock_bid=107;mock_ask=107.02;
   GlobalVariableSet(K("peak",123),10);mock_error=138;Cycle();
   ECheck(mock_closes==1&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,"requote retains giveback intent");
   mock_bid=108;mock_ask=108.02;mock_error=0;Cycle();
   ECheck(mock_closes==1,"retry not sent before backoff");
   mock_now++;Cycle();ECheck(mock_closes==2&&!mock_live&&mock_entries==0,"rebound cannot cancel pending exit");

   ResetScenario();mock_mutation=false;Manage();
   ECheck(mock_closes==0&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_TIME,"closed trade context still saves intent");
   mock_mutation=true;mock_fresh=false;Manage();ECheck(mock_closes==0,"stale quote blocks close request");
   mock_fresh=true;Manage();ECheck(mock_closes==1,"fresh quote completes saved request");

   ResetScenario();mock_identity=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"wrong account no mutations");
   ResetScenario();mock_owner=false;Cycle();ECheck(mock_closes==0&&mock_entries==0,"duplicate owner no mutations");
   ResetScenario();GlobalVariableSet(K("pause"),1);Cycle();
   ECheck(mock_closes==1&&mock_entries==0,"paused entries retain position management");
   ResetScenario();mock_error=128;mock_close_on_error=true;Cycle();
   ECheck(mock_closes==1&&mock_entries==0&&!mock_live,"ambiguous accepted close reconciles without duplicate send");
   ResetScenario();MaximumHoldMinutes=0;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==0,"first protection observation not mislabeled as outside edit");
   mock_sl=96;mock_tp=109;Manage();
   ECheck(GlobalVariableGet(K("outside_change",123))==1&&mock_closes==0,"outside tightening and TP edit flagged without overriding user");

   int f=FileOpen("DemoAutopilot\\v014-execution-regression.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
      ",\"actual_order_operations\":0,\"production_functions_under_mock_environment\":[\"SafeClose\",\"Manage\",\"ReconcileFlat\",\"EntryGate\",\"Cycle\"]}");FileClose(f);}
}
void TestProductionTryEntry(const int index)
{
   if(!EntryGate())return;
   string symbol=symbols[index];Spec s;
   if(!ReadSpec(index,s)){CheckOutcome(index,AP_QUOTE);return;}
   if(iBars(symbol,PERIOD_H1)<101||iBars(symbol,ENTRY_TF)<101){CheckOutcome(index,AP_HISTORY);return;}
   datetime bar=iTime(symbol,ENTRY_TF,0),previous=iTime(symbol,ENTRY_TF,1);
   if(previous+ENTRY_SECONDS!=bar||!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds)){reasons[index]="等待下一次M5收盘触发";return;}
   RefreshAdmission(index,s);
   if(admission_codes[index]!=0){CheckOutcome(index,admission_codes[index]);return;}
   if(attempted[index]==bar || (datetime)GlobalVariableGet(K("bar_"+symbol))==bar){reasons[index]="本根K线已检查，等待新信号";return;}
   datetime h1_end=iTime(symbol,PERIOD_H1,1)+3600;
   if(h1_end>TimeCurrent()||TimeCurrent()-h1_end>=3600){CheckOutcome(index,AP_H1_STALE);return;}
   for(int j=1;j<5;j++)if(iTime(symbol,ENTRY_TF,j)-iTime(symbol,ENTRY_TF,j+1)!=ENTRY_SECONDS)
   {CheckOutcome(index,AP_GAP);return;}
   int side=Direction(symbol);
   if(side==0){CheckOutcome(index,AP_DIRECTION);return;}
   double close=iClose(symbol,ENTRY_TF,1),open=iOpen(symbol,ENTRY_TF,1);
   double ema=iMA(symbol,ENTRY_TF,20,0,MODE_EMA,PRICE_CLOSE,1),previous_close=iClose(symbol,ENTRY_TF,2);
   if(!APMomentum(side,open,close,previous_close,ema)){CheckOutcome(index,AP_TRIGGER);return;}
   double atr=iATR(symbol,ENTRY_TF,14,1),structure=RecentStructure(symbol,side);
   if(!APFinitePositive(atr)||!APFinitePositive(structure)){CheckOutcome(index,AP_STRUCTURE);return;}
   if(MathAbs(s.bid-close)>APDriftLimit(atr,s.tick,EntryDriftATR)){CheckOutcome(index,AP_DRIFT);return;}
   double structural_sl=APStop(structure,atr,side,s.spread,s.tick,s.digits),fill=side==1?s.ask:s.bid;
   double sl=APCostAwareInitialStop(structural_sl,fill,s.spread,MaxSpreadFraction,s.tick,s.digits,side);
   double distance=side*(fill-sl);
   if(!APFinitePositive(sl)||!APFinitePositive(distance)){CheckOutcome(index,AP_STOP);return;}
   double entry_reserve=APEntryReserve(SlippagePoints,s.point);
   if(entry_reserve<0){CheckOutcome(index,AP_SPEC_INVALID);return;}
   double minimum_risk=((distance+s.slip+entry_reserve)/s.tick*s.value+RoundTripFeePerLotUSD)*s.minimum;
   if(s.spread>MaxSpreadFraction*distance){CheckOutcome(index,AP_SPREAD,minimum_risk);return;}
   double budget=APPracticeBudget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent);
   double lots=APLots(budget,distance,s.slip+entry_reserve,s.tick,s.value,s.minimum,s.step,MathMin(s.maximum,MaximumLots),RoundTripFeePerLotUSD);
   if(lots==0){CheckOutcome(index,AP_BUDGET,minimum_risk);return;}
   double tp=APPrice(fill+side*2*distance,s.tick,s.digits,side==1);
   double stop_distance=(MarketInfo(symbol,MODE_STOPLEVEL)+1)*s.point;
   if((side==1&&(s.bid-sl<stop_distance||tp-s.bid<stop_distance)) ||
      (side==-1&&(sl-s.ask<stop_distance||s.ask-tp<stop_distance)))
   {CheckOutcome(index,AP_STOP_LEVEL,minimum_risk);return;}
   int type=side==1?OP_BUY:OP_SELL;ResetLastError();
   double free=AccountFreeMarginCheck(symbol,type,lots);int margin_error=GetLastError();
   if(margin_error!=0||free<=0||MarketInfo(symbol,MODE_TRADEALLOWED)==0){CheckOutcome(index,AP_MARGIN,minimum_risk);return;}
   if(!MutationAllowed()||!EntryGate()){CheckOutcome(index,AP_PERMISSION,minimum_risk);return;}
   // Persist signal consumption before sending. Unknown execution errors NEVER trigger an immediate duplicate resend.
   attempted[index]=bar;GlobalVariableSet(K("bar_"+symbol),(double)bar);
   double risk=(distance+s.slip+entry_reserve)/s.tick*s.value*lots+RoundTripFeePerLotUSD*lots;
   GlobalVariableSet(K("pending_R"),risk);GlobalVariablesFlush();
   Event("ENTRY_PLAN",symbol,0,"side="+IntegerToString(side)+" lots="+DoubleToString(lots,8)+" risk_usd="+DoubleToString(risk,4)+" sl="+DoubleToString(sl,s.digits)+" tp="+DoubleToString(tp,s.digits));
   if(!EntryJournal(index,0,side,s,lots,fill,sl,tp,risk,budget))return;
   if(!MutationAllowed()||!EntryGate())return;
   uint eq_started=GetTickCount();
   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.13",MAGIC,0,clrNONE);
   int error=GetLastError();uint eq_elapsed=(uint)(GetTickCount()-eq_started);
   if(ticket<0)
   {
      EQRecord(true,symbol,0,side,lots,fill,0,false,error,eq_elapsed,s.spread,lots*s.value/s.tick);
      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));
      if(error==128||error==6){GlobalVariableSet(K("halt"),1);Event("HALT",symbol,0,"uncertain execution; inspect account before manual recovery");}
      CheckOutcome(index,AP_SEND_ERROR,minimum_risk,true);return;
   }
   GlobalVariableSet(K("initial_R",ticket),risk);GlobalVariableSet(K("peak",ticket),0);
   GlobalVariableSet(K("last_live_ticket"),ticket);GlobalVariablesFlush();
   Event("ENTRY_ACCEPTED",symbol,ticket,"server returned ticket");
   if(!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())
   {GlobalVariableSet(K("halt"),1);Event("HALT",symbol,ticket,"cannot verify accepted ticket");return;}
   double eq_actual_fill=OrderOpenPrice(),eq_actual_lots=OrderLots();
   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)/s.tick*s.value*OrderLots()+RoundTripFeePerLotUSD*OrderLots();
   GlobalVariableSet(K("initial_R",ticket),actual);
   GlobalVariableSet(K("initial_sl",ticket),OrderStopLoss());GlobalVariableSet(K("initial_tp",ticket),OrderTakeProfit());
   GlobalVariableSet(K("observed_sl",ticket),OrderStopLoss());GlobalVariableSet(K("observed_tp",ticket),OrderTakeProfit());
   GlobalVariablesFlush();
   EntryJournal(index,ticket,side,s,OrderLots(),OrderOpenPrice(),OrderStopLoss(),OrderTakeProfit(),actual,budget);
   if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit())||actual>budget+0.01)
   {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_FILL);}
   if(GlobalVariableGet(K("halt"))==0)EPStart(ticket,index,s);
   EQRecord(true,symbol,ticket,side,eq_actual_lots,fill,eq_actual_fill,true,0,eq_elapsed,s.spread,eq_actual_lots*s.value/s.tick);
   CheckOutcome(index,AP_FILLED,minimum_risk,true);
}

void RunUpgradeTests()
{
   ResetScenario();RoundTripFeePerLotUSD=7;mock_now=1000;mock_live=false;
   CheckOutcome(0,AP_BUDGET,12.1);
   int events_before=mock_event_count,count_before=check_counts[0];
   mock_now=1001;CheckOutcome(0,AP_BUDGET,15.2);
   ECheck(last_local_checks[0]==1001&&Near(last_minimum_risks[0],15.2),"same refusal refreshes time and risk");
   ECheck(mock_event_count==events_before&&check_counts[0]==count_before,"same refusal does not duplicate event");
   mock_now=1002;CheckOutcome(0,AP_DRIFT);
   ECheck(last_minimum_risks[0]<0&&mock_event_count==events_before+1,"different reason clears obsolete risk and records change");
   ResetScenario();mock_live=false;mock_now=100000;RoundTripFeePerLotUSD=7;mock_silver=true;
   TestProductionTryEntry(1);
   ECheck(last_codes[1]==AP_COST_BUDGET&&mock_sends==0,"real TryEntry blocks unaffordable silver before indicator checks");
   ECheck(Near(admission_floors[1],14.12),"FP silver contract produces correct cost floor");
   mock_silver=false;TestProductionTryEntry(0);
   ECheck(last_codes[0]==AP_TRIGGER&&mock_sends==0,"affordable gold still requires closed-bar momentum signal");
   ResetScenario();quotes_fresh[0]=true;quotes_fresh[1]=true;mock_connected=false;Cycle();
   ECheck(!quotes_fresh[0]&&!quotes_fresh[1]&&mock_sends==0,"disconnect clears stale quote eligibility");
   ResetScenario();mock_leverage=100;Cycle();
   ECheck(mock_closes==1&&mock_entries==0,"unexpected leverage blocks entries but still manages exit");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;mock_commission=-.035;
   mock_bid=106.10;mock_ask=106.12;Manage();
   ECheck(mock_tightens==1&&Near(mock_last_tighten,101.66),"production profit lock reserves full round-trip fees");
   ResetScenario();mock_live=false;mock_now=100000;mock_identity=false;
   TestProductionTryEntry(0);ECheck(mock_sends==0,"production entry cannot send on wrong identity");

   ECheck(Near(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,0,.01),2.13),"gold exact cost floor includes tick buffer");
   ECheck(Near(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,500,.01),5.53),"server stop distance contributes to floor");
   ECheck(APAdmissionRiskFloor(.4,.2,.05,.01,1,.01,7,-1,.01)<0,"negative server stop data invalid");
   ECheck(APAdmissionCode(5,5,.01,.01)==0,"budget equality passes necessary condition");
   ECheck(APAdmissionCode(5.0001,5,.01,.01)==AP_COST_BUDGET,"above budget blocked");
   ECheck(APAdmissionCode(1,5,.1,.01)==AP_MINIMUM_VOLUME,"broker minimum cannot override lot cap");
   ECheck(APAdmissionCode(-1,5,.01,.01)==AP_SPEC_INVALID,"unknown risk does not pass");
   ECheck(Near(APConservativeCost(.01,7,-.035,0),.07),"opening-only fee does not understate round trip");
   ECheck(Near(APConservativeCost(.01,7,-.07,0),.07),"posted round-trip fee not double counted");
   ECheck(Near(APConservativeCost(.01,7,-.1,-.02),.12),"higher observed fee plus negative swap respected");
   ECheck(Near(APConservativeCost(.01,7,.01,.02),.07),"rebates do not consume risk reserve");
   ECheck(APConservativeCost(.01,-1,0,0)<0,"invalid fee estimate blocks calculation");
   ECheck(APNextBarSeconds(900,1021,300)==179&&APNextBarSeconds(900,1200,300)==-1,"countdown expires rather than wrapping stale bar");
   ECheck(APNextBarSeconds(900,899,300)==-1,"future bar is not a live countdown");

   // Vary side, structure, spread, and broker stops. A necessary lower bound must
   // never reject a plan accepted by the original sizing + server-distance rules.
   int cases=0,bad=0,admissible=0;
   for(int side=-1;side<=1;side+=2)for(int sp=0;sp<20;sp++)for(int st=0;st<10;st++)for(int bs=0;bs<4;bs++)
   {
      double spread=sp*.03,fill=100,structural=100-side*(.05+st*.4);
      double sl=APCostAwareInitialStop(structural,fill,spread,.2,.01,2,side);
      double distance=side*(fill-sl),server_distance=(bs*100+1)*.01;
      double risk=((distance+.05)/.01+7)*.01;
      double floor=APAdmissionRiskFloor(spread,.2,.05,.01,1,.01,7,bs*100,.01);
      bool old_accept=APLots(5,distance,.05,.01,1,.01,.01,.01,7)>0&&distance-spread>=server_distance-1e-7;
      if(old_accept){admissible++;if(APAdmissionCode(floor,5,.01,.01)!=0)bad++;}
      if(distance-spread>=server_distance-1e-7&&floor>risk+1e-7)bad++;
      cases++;
   }
   ECheck(cases==1600&&admissible>0&&bad==0,"1600 plan cases: preflight preserves all originally admissible plans");
   int f=FileOpen("DemoAutopilot\\v014-upgrade-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"version\":\"0.8\",\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
         ",\"failures\":["+failure_labels+"],\"property_scenarios\":"+IntegerToString(cases)+",\"originally_admissible_scenarios\":"+IntegerToString(admissible)+
         ",\"actual_order_operations\":0}");FileClose(f);
   }
}

#include <Codex/ExitComparison.mqh>

void ResetExitFixture(const bool new_path=true)
{
   ep_seq=0;ep_pairs=0;ep_baseline=0;ep_trial=0;ep_fault=false;ep_error="";ep_initialized=false;
   ep_last_cycle=0;ep_checkpoint=0;ep_status_time=0;
   for(int j=0;j<EP_SLOTS;j++)
   {ep_tickets[j]=0;ep_completed[j]=false;for(int m=0;m<2;m++){FLInit(ep_books[2*j+m],500);ep_nets[2*j+m]=0;}}
   if(new_path){ep_root="DemoAutopilot\\test-v014-"+IntegerToString(GetTickCount())+"-";ep_campaign=0;ep_signature="";}
}
void RunProtectionTests()
{
   ECheck(APProtectedNet(5.99,10)<0&&Near(APProtectedNet(6,10),0),"earlier BE trigger boundary is 0.6R");
   ECheck(Near(APProtectedNet(10,10),2.5),"at 1R the intended protected net is 0.25R");
   ECheck(Near(APProtectedNet(15,10),10),"at 1.5R the intended protected net is 1R");
   ECheck(!APProtectedGiveback(9,0,10),"sub-1R noise cannot trigger giveback market exit");
   ECheck(APProtectedGiveback(10,2.5,10)&&!APProtectedGiveback(10,2.51,10),"giveback boundary after 1R");
   ECheck(APProtectedGiveback(15,10,10)&&!APProtectedGiveback(15,10.01,10),"late giveback boundary retained");
   ECheck(APProtectedNet(10,0)<0&&APProtectedStop(100,0,0,.05,.01,2,1,10,10)==0,"invalid risk or units blocked");
   for(int side=-1;side<=1;side+=2)
   {
      double stop=APProtectedStop(100,1,.07,.05,.01,2,side,6,6);
      ECheck(APNet(side,100,stop-side*.05,1,.07)>=1.5-1e-7,"both sides protect requested net after modeled fee and slip");
      FLBook p;FLInit(p,500);p.active=true;p.side=side;p.fill=100;p.sl=100-side*5;p.tp=100+side*10;
      p.units=1;p.fee=.07;p.slip=.05;p.peak=6;p.r=6;
      double bid=side==1?106:93.98,ask=bid+.02;
      double old=p.sl;
      ECheck(APProtectedTighten(p,bid,ask,.01,2,.01)&&side*(p.sl-old)>0,"both sides tighten instead of widening");
      double same=p.sl;ECheck(!APProtectedTighten(p,bid,ask,.01,2,.01)&&Near(p.sl,same),"unchanged target does not resend modify");
      p.sl=100-side*5;ECheck(!APProtectedTighten(p,bid,ask,.01,2,10),"broker freeze or distance prevents impossible tightening");
   }
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;mock_bid=103.65;mock_ask=103.67;Manage();
   ECheck(mock_tightens==0&&mock_closes==0,"production Manage does not tighten below 0.6R");
   mock_bid=103.70;mock_ask=103.72;Manage();
   ECheck(mock_tightens==1&&Near(mock_last_tighten,100.13),"production Manage shifts BE above costs at 0.6R");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;
   GlobalVariableSet(K("peak",123),6);mock_bid=101.50;mock_ask=101.52;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,"earlier giveback uses existing sticky close machinery");
   ResetScenario();MaximumHoldMinutes=0;RoundTripFeePerLotUSD=7;
   GlobalVariableSet(K("peak",123),6);mock_bid=101.50;mock_ask=101.52;mock_error=138;Manage();
   mock_bid=107;mock_ask=107.02;mock_error=0;mock_now++;Manage();
   ECheck(mock_closes==2&&!mock_live,"rebound does not cancel earlier-protection exit intent");

   int cases=0,bad=0;
   for(int side=-1;side<=1;side+=2)for(int u=1;u<=5;u++)for(int k=0;k<=200;k++)
   {
      double r=5,peak=k*.01*r,keep=APProtectedNet(peak,r),units=u*.5;
      if(keep>=0)
      {
         double stop=APProtectedStop(100,units,.07,.05,.01,2,side,peak,r);
         if(stop<=0||APNet(side,100,stop-side*.05,units,.07)<keep-1e-7)bad++;
         if(keep>peak+1e-7)bad++;
      }
      cases++;
   }
   ECheck(cases==2010&&bad==0,"2010 price-step cases preserve costs and retained-net bound");

   // Replay future accepted-entry clone, then restore its append-only record.
   ResetScenario();MaximumHoldMinutes=20;RoundTripFeePerLotUSD=7;mock_open=2100;mock_now=2200;
   ResetExitFixture();Spec s;ReadSpec(0,s);EPStart(123,0,s);
   ECheck(ep_initialized&&!ep_fault&&ep_tickets[0]==123&&ep_books[0].active&&ep_books[1].active,"identical two-arm enrollment succeeds");
   EPStart(123,0,s);ECheck(ep_tickets[1]==0,"duplicate enrollment does not create another pair");
   mock_bid=104;mock_ask=104.02;ReadSpec(0,s);EPManage(0,0,s);EPManage(0,1,s);
   ECheck(Near(ep_books[0].sl,95)&&Near(ep_books[1].sl,100.13),"trial protects earlier on the same price path");
   mock_now=2250;mock_bid=100.12;mock_ask=100.14;ReadSpec(0,s);EPManage(0,0,s);EPManage(0,1,s);
   ECheck(ep_books[0].active&&!ep_books[1].active&&Near(ep_nets[1],0),"trial sampled stop includes adverse modeled fill and fees");
   mock_now=3300;mock_bid=98;mock_ask=98.02;ReadSpec(0,s);EPManage(0,0,s);EPComplete(0);
   ECheck(ep_pairs==1&&Near(ep_baseline,-2.12)&&Near(ep_trial,0),"paired result completes after baseline time exit");
   EPComplete(0);ECheck(ep_pairs==1,"same pair is not counted twice");
   long saved_seq=ep_seq;ResetExitFixture(false);
   ECheck(EPInitialize()&&!ep_fault&&ep_seq==saved_seq&&ep_pairs==1&&Near(ep_baseline,-2.12)&&Near(ep_trial,0),"native ledger restores complete paired results without double count");
   EPStart(123,0,s);ECheck(ep_pairs==1&&ep_tickets[1]==0,"restart retains enrollment idempotence");
   mock_identity=false;EPStart(124,0,s);ECheck(ep_tickets[0]==123,"wrong account cannot enroll virtual pair");
   mock_identity=true;
   FLBook gap;FLInit(gap,500);gap.side=1;gap.fill=100;gap.sl=100.13;gap.tp=110;gap.units=1;gap.fee=.07;gap.slip=.05;
   ECheck(Near(FLExitPrice(gap,98,98.02,FL_STOP),97.95),"gapped stop never invents a fill at protected level");
   int f=FileOpen("DemoAutopilot\\v014-protection-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"version\":\"0.9\",\"passed\":"+IntegerToString(exec_passed)+",\"failed\":"+IntegerToString(exec_failed)+
         ",\"failures\":["+failure_labels+"],\"protection_property_scenarios\":"+IntegerToString(cases)+",\"actual_order_operations\":0}");FileClose(f);
   }
}

bool LegacySafeClose(const int ticket,const int requested)
{
   if(!Identity()||!Owner()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int previous_intent=(int)GlobalVariableGet(K("exit_intent",ticket));
   int intent=APStickyExit(previous_intent,requested);
   if(intent!=previous_intent){GlobalVariableSet(K("exit_intent",ticket),intent);GlobalVariablesFlush();}
   if(TimeLocal()<(datetime)GlobalVariableGet(K("action_after",ticket)))return false;
   if(!MutationAllowed())return false;
   string symbol=OrderSymbol();int index=IndexOf(symbol);Spec s;
   RefreshRates();
   if(!ReadSpec(index,s))return false;
   double lots=OrderLots(),price=OrderType()==OP_BUY?s.bid:s.ask;
   // The same account and ownership guards are rechecked immediately before every mutation.
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderClose(ticket,lots,price,SlippagePoints,clrNONE);int error=GetLastError();
   if(ok)
   {
      // Persist immediately; SyncClosed's periodic scan was too late in v0.4.
      datetime closed=TimeCurrent();
      if(OrderSelect(ticket,SELECT_BY_TICKET)&&OrderCloseTime()>0)closed=OrderCloseTime();
      datetime latest=(datetime)GlobalVariableGet(K("last_close"));
      GlobalVariableSet(K("last_close"),(double)(closed>latest?closed:latest));
      closed_this_cycle=true;GlobalVariablesFlush();
   }
   Event(ok?"CLOSE_ACCEPTED":"CLOSE_FAILED",symbol,ticket,APExitText(intent)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:APRetrySeconds(error))));
   return ok;
}
bool LegacySafeTighten(const int ticket,const double target)
{
   if(!MutationAllowed()||!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())return false;
   int side=OrderType()==OP_BUY?1:-1,index=IndexOf(OrderSymbol());Spec s;
   if(!ReadSpec(index,s)||!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit()))return false;
   double old=OrderStopLoss();
   if((side==1&&target<=old+s.tick*.5)||(side==-1&&target>=old-s.tick*.5))return false;
   double minimum=(MathMax(MarketInfo(OrderSymbol(),MODE_STOPLEVEL),MarketInfo(OrderSymbol(),MODE_FREEZELEVEL))+1)*s.point;
   if((side==1&&target>=s.bid-minimum)||(side==-1&&target<=s.ask+minimum))return false;
   string symbol=OrderSymbol();double open=OrderOpenPrice(),tp=OrderTakeProfit();
   if(!MutationAllowed())return false;
   ResetLastError();bool ok=OrderModify(ticket,open,target,tp,0,clrNONE);int error=GetLastError();
   if(ok)
   {GlobalVariableSet(K("observed_sl",ticket),target);GlobalVariableSet(K("observed_tp",ticket),tp);GlobalVariablesFlush();}
   Event(ok?"SL_TIGHTEN_ACCEPTED":"SL_TIGHTEN_FAILED",symbol,ticket,"sl="+DoubleToString(target,s.digits)+" error="+IntegerToString(error));
   GlobalVariableSet(K("action_after",ticket),(double)(TimeLocal()+(ok?1:5)));
   return ok;
}

void RunTimingTests()
{
   // Reproduce the old bug with both ORIGINAL production functions under fake APIs.
   ResetScenario();mock_error=130;LegacySafeTighten(123,100.13);mock_error=0;
   bool old_closed=LegacySafeClose(123,AP_EXIT_USER);
   ECheck(!old_closed&&mock_closes==0&&mock_live&&GlobalVariableGet(K("action_after",123))==2205,
      "v09 reproduction: invalid modify blocks immediate user close for five seconds");
   for(int side=0;side<2;side++)for(int e=0;e<2;e++)
   {
      ResetScenario();mock_side=side==0?OP_BUY:OP_SELL;
      if(side==1){mock_bid=97.98;mock_ask=98;mock_sl=105;mock_tp=90;}
      double target=side==0?100.13:99.87;
      mock_error=e==0?130:145;
      ECheck(!SafeTighten(123,target)&&mock_tightens==1,"modify-specific rejection is observed");
      SafeTighten(123,target);ECheck(mock_tightens==1,"modify retry remains throttled after rejection");
      mock_error=0;
      ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==1&&!mock_live,"buy and sell user close bypasses modify-only rejection backoff");
   }
   ResetScenario();mock_error=130;SafeTighten(123,100.13);mock_error=0;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_TIME,
      "production time exit is no longer delayed by invalid modify");
   ResetScenario();MaximumHoldMinutes=0;mock_error=145;SafeTighten(123,100.13);mock_error=0;
   GlobalVariableSet(K("peak",123),6);mock_bid=101;mock_ask=101.02;Manage();
   ECheck(mock_closes==1&&!mock_live&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_GIVEBACK,
      "production profit giveback is no longer delayed by denied modify");
   int shared_errors[8]={4,6,8,128,137,139,141,146};
   for(int i=0;i<8;i++)
   {
      ResetScenario();mock_error=shared_errors[i];SafeTighten(123,100.13);
      mock_error=0;int wait=APRetrySeconds(shared_errors[i]);
      ECheck(!SafeClose(123,AP_EXIT_USER)&&mock_closes==0&&GlobalVariableGet(K("exit_intent",123))==AP_EXIT_USER,
         "transport or rate-limit failure retains shared backoff and persistent close intent");
      mock_now+=wait-1;SafeClose(123,AP_EXIT_USER);ECheck(mock_closes==0,"shared deadline is not bypassed one second early");
      mock_now++;ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==1,"close may retry at shared deadline");
   }
   ResetScenario();mock_error=130;SafeTighten(123,100.13);mock_error=138;SafeClose(123,AP_EXIT_USER);
   ECheck(mock_closes==1&&mock_live,"requote after modify rejection records separate close failure");
   mock_error=0;SafeClose(123,AP_EXIT_USER);ECheck(mock_closes==1,"independent close retry never spins within the same second");
   mock_now++;ECheck(SafeClose(123,AP_EXIT_USER)&&mock_closes==2,"close retry succeeds without waiting for modify deadline");
   ResetScenario();GlobalVariableSet(K("action_after",123),mock_now+10);
   ECheck(!SafeClose(123,AP_EXIT_TIME)&&mock_closes==0,"old persisted in-flight retry deadline is preserved on upgrade");
   mock_now+=10;ECheck(SafeClose(123,AP_EXIT_TIME),"legacy deadline expires normally");
   ResetScenario();GlobalVariableSet(K("exit_intent",123),AP_EXIT_TIME);
   ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"no modify may follow a latched close intent");
   ResetScenario();mock_identity=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"wrong account cannot modify");
   ResetScenario();mock_owner=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"wrong owner cannot modify");
   ResetScenario();mock_fresh=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"stale quote cannot modify");
   ResetScenario();mock_mutation=false;ECheck(!SafeTighten(123,100.13)&&mock_tightens==0,"closed permissions cannot modify");
   ResetScenario();ECheck(!SafeTighten(123,94)&&mock_tightens==0,"production buy stop cannot widen");
   ECheck(!SafeTighten(123,102)&&mock_tightens==0,"production stop cannot violate market distance");
   ResetScenario();mock_side=OP_SELL;mock_bid=97.98;mock_ask=98;mock_sl=105;mock_tp=90;
   ECheck(!SafeTighten(123,106)&&mock_tightens==0,"production sell stop cannot widen");
   ECheck(APHoldSecondsLeft(1000,2199,20)==1&&APHoldSecondsLeft(1000,2200,20)==0&&
      APHoldSecondsLeft(1000,2300,20)==0&&APHoldSecondsLeft(1000,2200,0)==-1,"display distinguishes remaining time, overdue and disabled limit");
   ECheck(ExitReasonText(AP_EXIT_GIVEBACK)=="PROFIT_PROTECTION_GIVEBACK","exit log no longer mislabels v09 giveback as 1.5R only");
   int f=FileOpen("DemoAutopilot\\v014-timing-test.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE)
   {
      FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
         ",\"failures\":["+failure_labels+"],\"old_bug_reproduced\":true,\"actual_order_operations\":0}");FileClose(f);
   }
}

#define AlignedCycle TestAlignedCycle
#include <Codex/AlignedForward.mqh>
#undef AlignedCycle

void ResetAligned(const bool fresh=true)
{
   af_campaign=0;af_started=0;af_initial_cash=0;af_last_cycle=0;af_last_status=0;af_checkpoint=0;af_calendar=0;
   af_initialized=false;af_fault=false;af_signature="";af_error="";
   for(int i=0;i<6;i++){FLInit(af_books[i],10000);af_reasons[i]="test";}
   if(fresh)af_root="DemoAutopilot\\test-v014-aligned-"+IntegerToString(GetTickCount())+"-";
}
void RunAlignedTests()
{
   ResetScenario();RoundTripFeePerLotUSD=7;
   ECheck(Near(AFBudget(10000),5)&&Near(AFBudget(11000),5),"aligned risk never compounds above authorized five dollars");
   ECheck(Near(AFBudget(450),4.5)&&AFBudget(0)==0,"low virtual cash reduces aligned risk");
   Spec a,b;ReadSpec(0,a);b=a;AFStressSpec(0,a);AFStressSpec(3,b);
   ECheck(Near(b.spread,2*a.spread)&&Near((a.bid+a.ask)/2,(b.bid+b.ask)/2)&&Near(b.slip,2*a.slip),"stress widens executable quotes at same midpoint and doubles slip");
   ECheck(Near(AFFee(0),7)&&Near(AFFee(3),14),"stress doubles fee before lot admission");
   ECheck(AFName(0)!=AFName(3)&&FLDirection(4%3,-1,1)==1,"direction and cost dimensions kept distinct");
   ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_bid=100;mock_ask=100.02;
   ResetAligned();ECheck(AFInitialize()&&!af_fault&&af_books[5].start==10000,"new campaign starts six cash books from broker balance and capped risk reference");
   mock_now=2420;
   for(int i=0;i<6;i++)
   {
      Spec s;AFReadSpec(0,i,s);FLBook p=af_books[i];
      ECheck(AFPlan(i,0,s,p)&&p.r<=5.0000001&&p.active,"all six future plans honor risk cap");
      ECheck(AFSave(i,p,"OPEN"),"six-arm native ledger persists planned virtual fills");af_books[i]=p;
      ECheck(!AFPlan(i,0,s,p),"same model and symbol never reuse the same consumed bar");
   }
   double fill=af_books[0].fill;AFCalendarSnapshot();ulong calendar_size=0;
   int cf=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);if(cf!=INVALID_HANDLE){calendar_size=FileSize(cf);FileClose(cf);}
   ResetAligned(false);ECheck(AFInitialize()&&!af_fault&&af_books[0].active&&Near(af_books[0].fill,fill)&&af_books[5].active,
      "six-arm native restore retains active fills and protocol");
   AFCalendarSnapshot();cf=FileOpen(AFPath("calendar.csv"),FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   ulong after_size=0;if(cf!=INVALID_HANDLE){after_size=FileSize(cf);FileClose(cf);}
   ECheck(calendar_size>0&&after_size==calendar_size,"restart does not duplicate the same calendar bar");
   // In a constructed wider-spread market, base cost fits while stressed cost does not.
   FLBook p;FLInit(p,10000);Spec wide;ReadSpec(0,wide);wide.bid=100;wide.ask=100.60;wide.spread=.60;
   double old_drift=EntryDriftATR;EntryDriftATR=.5;
   ECheck(AFPlan(0,0,wide,p)&&p.r<=5,"base execution costs can admit constructed wide-spread signal");
   FLInit(p,10000);AFStressSpec(3,wide);
   ECheck(!AFPlan(3,0,wide,p)&&!p.active,"doubled costs reject before opening instead of only subtracting profit afterward");
   EntryDriftATR=old_drift;
   mock_now=2421;mock_bid=101;mock_ask=101.02;double initial=af_books[0].sl;AFManageBook(0);
   ECheck(af_books[0].active&&af_books[0].sl>initial,"new virtual baseline uses current early profit protection");
   mock_now=2422;mock_bid=95;mock_ask=95.02;AFManageBook(0);
   ECheck(!af_books[0].active&&af_books[0].n==1&&af_books[0].cash<9996,"sampled gap never invents a fill at protected stop");
   AFManageBook(0);ECheck(af_books[0].n==1,"closed virtual position cannot be counted twice");
   AFShutdown();double saved_cash=af_books[0].cash;ResetAligned(false);
   ECheck(AFInitialize()&&!af_fault&&Near(af_books[0].cash,saved_cash)&&af_books[0].n==1,"realized net survives native ledger replay");
   mock_balance=20000;ResetAligned(false);
   ECheck(AFInitialize()&&Near(af_initial_cash,10000)&&Near(af_books[5].start,10000),"broker balance change cannot rebase an existing campaign");
   mock_balance=10000;
   RoundTripFeePerLotUSD=8;af_initialized=false;
   ECheck(!AFInitialize()&&af_fault,"changed assumptions cannot reuse prior evidence");
   ResetScenario();RoundTripFeePerLotUSD=7;ResetAligned();mock_identity=false;
   ECheck(!AFInitialize()&&!af_initialized,"wrong account cannot create aligned campaign");
   mock_identity=true;mock_owner=false;ECheck(!AFInitialize(),"duplicate owner cannot create aligned campaign");
   ResetScenario();RoundTripFeePerLotUSD=7;ResetAligned();
   af_root="DemoAutopilot\\test-v014-isolation-"+IntegerToString(GetTickCount())+"-";
   mock_aligned_signal=true;mock_now=2420;mock_bid=100;mock_ask=100.02;TestAlignedCycle();
   mock_now=2720;TestAlignedCycle();
   ECheck(mock_sends==0&&mock_closes==0&&mock_tightens==0,"complete new comparison cycle has zero broker order calls");
   // The new study must also decline new virtual entries while program inputs are paused.
   mock_now=3000;for(int i=0;i<6;i++)af_books[i].active=false;
   GlobalVariableSet(K("pause"),1);TestAlignedCycle();bool any=false;
   for(int i=0;i<6;i++)if(af_books[i].active)any=true;
   ECheck(!any,"paused entries also pause new virtual entries");
}
void RunQualityTests()
{
   ECheck(Near(EQAdversePrice(true,1,100,100.2),.2)&&Near(EQAdversePrice(true,-1,100,99.8),.2),"adverse entry slip sign is correct for buy and sell");
   ECheck(Near(EQAdversePrice(false,1,100,99.8),.2)&&Near(EQAdversePrice(false,-1,100,100.2),.2),"adverse exit slip sign is correct for buy and sell");
   ECheck(Near(EQAdversePrice(true,1,100,99.8),-.2)&&Near(EQAdversePrice(false,-1,100,99.8),-.2),"favorable fills are retained as negative adverse slip");
   ECheck(EQAdversePrice(true,0,100,100)==EMPTY_VALUE&&EQAdversePrice(true,1,100,0)==EMPTY_VALUE,"unknown fill is not recorded as zero slippage");
   uint before=4294967290,after=5;ECheck((uint)(after-before)==11,"elapsed milliseconds survive unsigned counter rollover");
   ResetScenario();eq_calls=0;eq_failures=0;eq_fills=0;eq_ms_sum=0;eq_ms_max=0;eq_adverse_sum=0;eq_adverse_max=0;
   eq_path="DemoAutopilot\\test-v014-quality-"+IntegerToString(GetTickCount())+".csv";
   EQRecord(true,"XAUUSD",123,1,.01,100,100.2,true,0,250,.4,1);
   EQRecord(false,"XAUUSD",123,1,.01,100,0,false,138,400,.4,1);
   ECheck(eq_calls==2&&eq_failures==1&&eq_fills==1&&Near(eq_ms_sum,650)&&Near(eq_adverse_sum,.2),"native quality accounting excludes failed fill while including call duration");
   int f=FileOpen(eq_path,FILE_READ|FILE_CSV|FILE_ANSI,',',CP_UTF8);int rows=0,bad=0;
   if(f!=INVALID_HANDLE){while(!FileIsEnding(f)){int n=0;while(!FileIsEnding(f)){string cell=FileReadString(f);n++;if(FileIsLineEnding(f))break;}if(n>1){rows++;if(n!=17)bad++;}}FileClose(f);}
   ECheck(rows==3&&bad==0,"native measurement CSV has header and two complete records");
   mock_identity=false;EQRecord(true,"XAUUSD",123,1,.01,100,100.2,true,0,250,.4,1);
   ECheck(eq_calls==2,"wrong account cannot contribute execution measurements");
   f=FileOpen("DemoAutopilot\\v014-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"new_research_model_count\":6}");FileClose(f);}
}

#define AlignedCycle12 TestAlignedCycle12
#include <Codex/AlignedForward12.mqh>
#undef AlignedCycle12

void RunEntryReserveTests()
{
   ECheck(Near(APEntryReserve(20,.01),.20)&&Near(APEntryReserve(20,.001),.020),"opening reserve converts broker points to price for each metal");
   ECheck(APEntryReserve(-1,.01)<0&&APEntryReserve(20,0)<0&&Near(APEntryReserve(0,.01),0),"invalid points blocked and explicit zero reserve preserved");
   double exit=.05,fee=.07,distance=4.83,entry=APEntryReserve(20,.01);
   ECheck(Near(distance+exit+fee,4.95)&&Near(distance+.15+exit+fee,5.10),"audited v011 incident reproduced numerically");
   ECheck(APLots(5,distance,exit+entry,.01,1,.01,.01,.01,7)==0,"audited incident rejected before OrderSend with opening reserve");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_bid=side==1?99.98:100;mock_ask=mock_bid+.02;mock_direction=side;mock_structure=side==1?95.37:104.61;
      attempted[0]=0;TestProductionTryEntry(0);
      ECheck(mock_sends==0&&last_codes[0]==AP_BUDGET&&Near(last_minimum_risks[0],5.15),"production buy and sell reject near-cap plan before sending");
      ResetScenario();RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_bid=side==1?99.98:100;mock_ask=mock_bid+.02;mock_direction=side;mock_structure=side==1?95.57:104.41;
      attempted[0]=0;TestProductionTryEntry(0);
      ECheck(mock_sends==1&&Near(last_minimum_risks[0],4.95),"production buy and sell with sufficient headroom remain eligible");
   }
   int checked=0,bad=0;
   for(int metal=0;metal<2;metal++)for(int d=1;d<=100;d++)
   {
      double point=metal==0?.01:.001,value=metal==0?1:5,slip=metal==0?.05:.02;
      double dist=d*(metal==0?.05:.001),reserve=APEntryReserve(20,point);
      double lots=APLots(5,dist,slip+reserve,point,value,.01,.01,.01,7);
      if(lots<=0)continue;
      for(int j=0;j<=20;j++)
      {
         double filled_risk=(dist+j*point+slip)/point*value*lots+7*lots;
         if(filled_risk>5+1e-7)bad++;checked++;
      }
   }
   ECheck(checked>1000&&bad==0,"all admitted metal plans remain under cap through their full reserved opening deviation");
   // Preserve the old paired campaign; start a new six-book campaign for changed admission.
   ResetScenario();RoundTripFeePerLotUSD=7;
   bf_root="DemoAutopilot\\test-v014-newaligned-"+IntegerToString(GetTickCount())+"-";
   ECheck(BF_PROTOCOL!=AF_PROTOCOL&&BFInitialize()&&!bf_fault,"new admission protocol is isolated from prior research");
   mock_now=2420;mock_aligned_signal=true;mock_bid=100;mock_ask=100.02;
   for(int i=0;i<6;i++)
   {
      Spec s;BFReadSpec(0,i,s);FLBook p=bf_books[i];
      ECheck(BFPlan(i,0,s,p)&&p.r<=5,"all six new admission books preserve capped post-fill risk");
   }
   int f=FileOpen("DemoAutopilot\\v014-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"entry_slip_property_scenarios\":"+IntegerToString(checked)+",\"actual_order_operations\":0}");FileClose(f);}
}

#define AlignedCycle13 TestAlignedCycle13
#include <Codex/AlignedForward13.mqh>
#undef AlignedCycle13

void RunAuthorizedBudgetTests()
{
   ECheck(Near(APPracticeBudget(10000,10000,500,3),15),"large broker balance never enlarges authorized fifteen dollar risk");
   ECheck(Near(APPracticeBudget(10000,450,500,3),13.5),"low real equity reduces higher practice budget");
   ECheck(APPracticeBudget(10000,10000,501,3)==0&&APPracticeBudget(10000,10000,500,10)==0,"capital inflation and superseded fifty dollar setting rejected");
   ECheck(APPracticeBudget(10000,10000,500,3.001)==0&&APPracticeBudget(10000,10000,500,-3)==0,"above authorized percent and negative risk rejected");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==1&&Near(last_budgets[1],15)&&Near(last_minimum_risks[1],14.97),"production silver buy and sell can reach send within fifteen dollars");
      ResetScenario();RiskPercent=1;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_COST_BUDGET,"same silver setup remains correctly blocked under original five dollars");
      ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;mock_aligned_signal=true;mock_now=2420;mock_live=false;mock_closed=0;
      mock_silver=true;mock_bid=100;mock_ask=100.048;mock_direction=side;mock_structure=side==1?99.5:100.5;attempted[1]=0;
      TestProductionTryEntry(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_BUDGET,"over-fifteen dollar structural risk remains blocked for both silver sides");
   }
   ECheck(Near(APLots(15,.1,.04,.001,5,.01,.01,.01,7),.01),"larger risk budget cannot bypass maximum 0.01 lot cap");
   ResetScenario();RiskPercent=3;RoundTripFeePerLotUSD=7;
   cf_root="DemoAutopilot\\test-v014-userbudget-"+IntegerToString(GetTickCount())+"-";
   ECheck(CF_PROTOCOL!=BF_PROTOCOL&&CFInitialize()&&!cf_fault,"authorized risk experiment receives independent protocol");
   ECheck(Near(CFBudget(10000),15)&&Near(CFBudget(500),15)&&Near(CFBudget(400),12),"new research follows static practice capital and lower-cash limits");
   int f=FileOpen("DemoAutopilot\\v014-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"authorized_risk_usd\":15,\"silver_production_entry_checked\":true}");FileClose(f);}
   RiskPercent=1;
}

void CheckOutcome150(const int index,const int code,const double minimum_risk=-1,const bool force=false)
{
   reasons[index]=AP08CheckText(code);
   datetime bar=iTime(symbols[index],ENTRY_TF,0);
   if(!force&&!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds))return;
   bool changed=APRecordChanged(last_bars[index],last_codes[index],bar,code);
   last_bars[index]=bar;last_codes[index]=code;
   last_local_checks[index]=TimeLocal();last_server_checks[index]=TimeCurrent();
   last_budgets[index]=APCapital150Budget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent);
   last_minimum_risks[index]=minimum_risk;
   if(!changed)return;
   check_counts[index]++;
   GlobalVariableSet(DK(index,"bar"),(double)bar);GlobalVariableSet(DK(index,"code"),code);
   GlobalVariableSet(DK(index,"local"),(double)last_local_checks[index]);
   GlobalVariableSet(DK(index,"server"),(double)last_server_checks[index]);
   GlobalVariableSet(DK(index,"budget"),last_budgets[index]);
   GlobalVariableSet(DK(index,"min_risk"),minimum_risk);GlobalVariableSet(DK(index,"count"),check_counts[index]);
   GlobalVariablesFlush();
   Event(code==AP_FILLED?"CHECK_ACCEPTED":"CHECK_REJECTED",symbols[index],0,
      "v0.14 timeframe=M5 bar_server="+TimeToString(bar,TIME_DATE|TIME_MINUTES)+" code="+IntegerToString(code)+
      " reason="+AP08CheckText(code)+" budget_usd="+DoubleToString(last_budgets[index],4)+
      " minimum_structural_risk_usd="+(minimum_risk>=0?DoubleToString(minimum_risk,4):"unknown")+
      " spread_gate_risk_lower_bound_usd="+(quotes_fresh[index]?DoubleToString(spread_minimum_risks[index],4):"unknown"));
}
void RefreshAdmission150(const int index,const Spec &s)
{
   minimum_lots[index]=s.minimum;
   admission_floors[index]=APAdmissionRiskFloor(s.spread,MaxSpreadFraction,s.slip+APEntryReserve(SlippagePoints,s.point),s.tick,s.value,s.minimum,
      RoundTripFeePerLotUSD,MarketInfo(symbols[index],MODE_STOPLEVEL),s.point);
   admission_codes[index]=APAdmissionCode(admission_floors[index],
      APCapital150Budget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent),s.minimum,MathMin(s.maximum,MaximumLots));
}
void TestProductionTryEntry150(const int index)
{
   if(!EntryGate())return;
   string symbol=symbols[index];Spec s;
   if(!ReadSpec(index,s)){CheckOutcome150(index,AP_QUOTE);return;}
   if(iBars(symbol,PERIOD_H1)<101||iBars(symbol,ENTRY_TF)<101){CheckOutcome150(index,AP_HISTORY);return;}
   datetime bar=iTime(symbol,ENTRY_TF,0),previous=iTime(symbol,ENTRY_TF,1);
   if(previous+ENTRY_SECONDS!=bar||!APEntryWindow(bar,TimeCurrent(),EntryWindowSeconds)){reasons[index]="等待下一次M5收盘触发";return;}
   RefreshAdmission150(index,s);
   if(admission_codes[index]!=0){CheckOutcome150(index,admission_codes[index]);return;}
   if(attempted[index]==bar || (datetime)GlobalVariableGet(K("bar_"+symbol))==bar){reasons[index]="本根K线已检查，等待新信号";return;}
   datetime h1_end=iTime(symbol,PERIOD_H1,1)+3600;
   if(h1_end>TimeCurrent()||TimeCurrent()-h1_end>=3600){CheckOutcome150(index,AP_H1_STALE);return;}
   for(int j=1;j<5;j++)if(iTime(symbol,ENTRY_TF,j)-iTime(symbol,ENTRY_TF,j+1)!=ENTRY_SECONDS)
   {CheckOutcome150(index,AP_GAP);return;}
   int side=Direction(symbol);
   if(side==0){CheckOutcome150(index,AP_DIRECTION);return;}
   double close=iClose(symbol,ENTRY_TF,1),open=iOpen(symbol,ENTRY_TF,1);
   double ema=iMA(symbol,ENTRY_TF,20,0,MODE_EMA,PRICE_CLOSE,1),previous_close=iClose(symbol,ENTRY_TF,2);
   if(!APMomentum(side,open,close,previous_close,ema)){CheckOutcome150(index,AP_TRIGGER);return;}
   double atr=iATR(symbol,ENTRY_TF,14,1),structure=RecentStructure(symbol,side);
   if(!APFinitePositive(atr)||!APFinitePositive(structure)){CheckOutcome150(index,AP_STRUCTURE);return;}
   if(MathAbs(s.bid-close)>APDriftLimit(atr,s.tick,EntryDriftATR)){CheckOutcome150(index,AP_DRIFT);return;}
   double structural_sl=APStop(structure,atr,side,s.spread,s.tick,s.digits),fill=side==1?s.ask:s.bid;
   double sl=APCostAwareInitialStop(structural_sl,fill,s.spread,MaxSpreadFraction,s.tick,s.digits,side);
   double distance=side*(fill-sl);
   if(!APFinitePositive(sl)||!APFinitePositive(distance)){CheckOutcome150(index,AP_STOP);return;}
   double entry_reserve=APEntryReserve(SlippagePoints,s.point);
   if(entry_reserve<0){CheckOutcome150(index,AP_SPEC_INVALID);return;}
   double minimum_risk=((distance+s.slip+entry_reserve)/s.tick*s.value+RoundTripFeePerLotUSD)*s.minimum;
   if(s.spread>MaxSpreadFraction*distance){CheckOutcome150(index,AP_SPREAD,minimum_risk);return;}
   double budget=APCapital150Budget(AccountBalance(),AccountEquity(),PracticeCapitalUSD,RiskPercent);
   double lots=APLots(budget,distance,s.slip+entry_reserve,s.tick,s.value,s.minimum,s.step,MathMin(s.maximum,MaximumLots),RoundTripFeePerLotUSD);
   if(lots==0){CheckOutcome150(index,AP_BUDGET,minimum_risk);return;}
   double tp=APPrice(fill+side*2*distance,s.tick,s.digits,side==1);
   double stop_distance=(MarketInfo(symbol,MODE_STOPLEVEL)+1)*s.point;
   if((side==1&&(s.bid-sl<stop_distance||tp-s.bid<stop_distance)) ||
      (side==-1&&(sl-s.ask<stop_distance||s.ask-tp<stop_distance)))
   {CheckOutcome150(index,AP_STOP_LEVEL,minimum_risk);return;}
   int type=side==1?OP_BUY:OP_SELL;ResetLastError();
   double free=AccountFreeMarginCheck(symbol,type,lots);int margin_error=GetLastError();
   if(margin_error!=0||free<=0||MarketInfo(symbol,MODE_TRADEALLOWED)==0){CheckOutcome150(index,AP_MARGIN,minimum_risk);return;}
   if(!MutationAllowed()||!EntryGate()){CheckOutcome150(index,AP_PERMISSION,minimum_risk);return;}
   // Persist signal consumption before sending. Unknown execution errors NEVER trigger an immediate duplicate resend.
   attempted[index]=bar;GlobalVariableSet(K("bar_"+symbol),(double)bar);
   double risk=(distance+s.slip+entry_reserve)/s.tick*s.value*lots+RoundTripFeePerLotUSD*lots;
   GlobalVariableSet(K("pending_R"),risk);GlobalVariablesFlush();
   Event("ENTRY_PLAN",symbol,0,"side="+IntegerToString(side)+" lots="+DoubleToString(lots,8)+" risk_usd="+DoubleToString(risk,4)+" sl="+DoubleToString(sl,s.digits)+" tp="+DoubleToString(tp,s.digits));
   if(!EntryJournal(index,0,side,s,lots,fill,sl,tp,risk,budget))return;
   if(!MutationAllowed()||!EntryGate())return;
   uint eq_started=GetTickCount();
   ResetLastError();int ticket=OrderSend(symbol,type,lots,fill,SlippagePoints,sl,tp,"DemoAutopilot-v0.14",MAGIC,0,clrNONE);
   int error=GetLastError();uint eq_elapsed=(uint)(GetTickCount()-eq_started);
   if(ticket<0)
   {
      EQRecord(true,symbol,0,side,lots,fill,0,false,error,eq_elapsed,s.spread,lots*s.value/s.tick);
      Event("ENTRY_FAILED",symbol,0,"error="+IntegerToString(error));
      if(error==128||error==6){GlobalVariableSet(K("halt"),1);Event("HALT",symbol,0,"uncertain execution; inspect account before manual recovery");}
      CheckOutcome150(index,AP_SEND_ERROR,minimum_risk,true);return;
   }
   GlobalVariableSet(K("initial_R",ticket),risk);GlobalVariableSet(K("peak",ticket),0);
   GlobalVariableSet(K("last_live_ticket"),ticket);GlobalVariablesFlush();
   Event("ENTRY_ACCEPTED",symbol,ticket,"server returned ticket");
   if(!OrderSelect(ticket,SELECT_BY_TICKET)||OrderCloseTime()!=0||!IsOwnedSelected())
   {GlobalVariableSet(K("halt"),1);Event("HALT",symbol,ticket,"cannot verify accepted ticket");return;}
   double eq_actual_fill=OrderOpenPrice(),eq_actual_lots=OrderLots();
   double actual=(MathAbs(OrderOpenPrice()-OrderStopLoss())+s.slip)/s.tick*s.value*OrderLots()+RoundTripFeePerLotUSD*OrderLots();
   GlobalVariableSet(K("initial_R",ticket),actual);
   GlobalVariableSet(K("initial_sl",ticket),OrderStopLoss());GlobalVariableSet(K("initial_tp",ticket),OrderTakeProfit());
   GlobalVariableSet(K("observed_sl",ticket),OrderStopLoss());GlobalVariableSet(K("observed_tp",ticket),OrderTakeProfit());
   GlobalVariablesFlush();
   EntryJournal(index,ticket,side,s,OrderLots(),OrderOpenPrice(),OrderStopLoss(),OrderTakeProfit(),actual,budget);
   if(!APFinitePositive(OrderStopLoss())||!APFinitePositive(OrderTakeProfit())||actual>budget+0.01)
   {GlobalVariableSet(K("halt"),1);SafeClose(ticket,AP_EXIT_FILL);}
   if(GlobalVariableGet(K("halt"))==0)EPStart(ticket,index,s);
   EQRecord(true,symbol,ticket,side,eq_actual_lots,fill,eq_actual_fill,true,0,eq_elapsed,s.spread,eq_actual_lots*s.value/s.tick);
   CheckOutcome150(index,AP_FILLED,minimum_risk,true);
}

void RunCapital150Tests()
{
   ECheck(Near(APCapital150Budget(150,150,150,10),15),"150 broker cash preserves requested fifteen dollar ceiling");
   ECheck(Near(APCapital150Budget(10000,10000,150,10),15),"large broker account cannot inflate a 150 dollar practice budget");
   ECheck(Near(APCapital150Budget(135,130,150,10),13),"lower broker equity reduces risk after losses");
   ECheck(APCapital150Budget(150,150,500,10)==0&&APCapital150Budget(150,150,150,10.01)==0,"wrong capital and higher percent cannot exceed fifteen dollars");
   ECheck(APCapital150Budget(0,150,150,10)==0&&APCapital150Budget(150,0,150,10)==0,"depleted capital or equity blocks new entry");
   for(int side=1;side>=-1;side-=2)
   {
      ResetScenario();PracticeCapitalUSD=150;RiskPercent=10;RoundTripFeePerLotUSD=7;mock_balance=150;mock_aligned_signal=true;
      mock_now=2420;mock_live=false;mock_closed=0;mock_silver=true;mock_bid=100;mock_ask=100.048;
      mock_direction=side;mock_structure=side==1?99.99:100.01;attempted[1]=0;
      TestProductionTryEntry150(1);
      ECheck(mock_sends==1&&Near(last_budgets[1],15)&&Near(last_minimum_risks[1],14.97),"prepared silver buy and sell preserve fifteen dollar admission with 150 cash");
      ResetScenario();PracticeCapitalUSD=150;RiskPercent=10;RoundTripFeePerLotUSD=7;mock_balance=150;mock_aligned_signal=true;
      mock_now=2420;mock_live=false;mock_closed=0;mock_silver=true;mock_bid=100;mock_ask=100.048;
      mock_direction=side;mock_structure=side==1?99.5:100.5;attempted[1]=0;
      TestProductionTryEntry150(1);
      ECheck(mock_sends==0&&last_codes[1]==AP_BUDGET,"prepared larger structural silver risk remains blocked");
   }
   int f=FileOpen("DemoAutopilot\\v014-all-tests.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,"{\"passed\":"+IntegerToString(passed+exec_passed)+",\"failed\":"+IntegerToString(failed+exec_failed)+
      ",\"failures\":["+failure_labels+"],\"actual_order_operations\":0,\"prepared_capital_usd\":150,\"maximum_risk_usd\":15,\"deployed\":false}");FileClose(f);}
   PracticeCapitalUSD=500;RiskPercent=1;
}

#undef OrderClosePrice
#undef OrderModify
#undef AccountLeverage
#undef AccountBalance
#undef AccountEquity
#undef iTime
#undef iBars
#undef iClose
#undef iOpen
#undef iMA
#undef iATR
#undef MarketInfo
#undef AccountFreeMarginCheck
#undef OrderSend
#undef GlobalVariableGet
#undef GlobalVariableSet
#undef GlobalVariableCheck
#undef GlobalVariablesFlush
#undef OrderSelect
#undef OrdersTotal
#undef OrderCloseTime
#undef OrderTicket
#undef OrderSymbol
#undef OrderType
#undef OrderLots
#undef OrderOpenTime
#undef OrderOpenPrice
#undef OrderStopLoss
#undef OrderTakeProfit
#undef OrderCommission
#undef OrderSwap
#undef TimeCurrent
#undef TimeLocal
#undef OrderClose
#undef RefreshRates
#undef ResetLastError
#undef GetLastError
#undef IsConnected
#undef IsTradeAllowed

void RunAudit()
{
   if(!APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())||AccountCurrency()!="USD")
   {Print("Audit blocked: demo identity mismatch");return;}
   int f=FileOpen("DemoAutopilot\\audit-history.csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
   if(f==INVALID_HANDLE)return;
   FileWrite(f,"ticket","symbol","side","lots","open_server","close_server","open_price","close_price","final_sl","final_tp",
      "profit","commission","swap","net","magic","comment","reserved_r","observed_peak_estimate");
   int exported=0;
   for(int i=0;i<OrdersHistoryTotal();i++)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)||OrderMagicNumber()!=2026101217||OrderCloseTime()==0)continue;
      int ticket=OrderTicket();
      FileWrite(f,ticket,OrderSymbol(),OrderType()==OP_BUY?1:-1,DoubleToString(OrderLots(),8),
         TimeToString(OrderOpenTime(),TIME_DATE|TIME_SECONDS),TimeToString(OrderCloseTime(),TIME_DATE|TIME_SECONDS),
         DoubleToString(OrderOpenPrice(),8),DoubleToString(OrderClosePrice(),8),DoubleToString(OrderStopLoss(),8),DoubleToString(OrderTakeProfit(),8),
         DoubleToString(OrderProfit(),4),DoubleToString(OrderCommission(),4),DoubleToString(OrderSwap(),4),
         DoubleToString(OrderProfit()+OrderCommission()+OrderSwap(),4),OrderMagicNumber(),OrderComment(),
         DoubleToString(GlobalVariableGet("AP02.48530368.initial_R."+IntegerToString(ticket)),4),
         DoubleToString(GlobalVariableGet("AP02.48530368.peak."+IntegerToString(ticket)),4));
      exported++;
   }
   FileFlush(f);FileClose(f);
   string names_audit[2]={"XAUUSD","XAGUSD"};ENUM_TIMEFRAMES frames[2]={PERIOD_M5,PERIOD_H1};
   for(int s=0;s<2;s++)for(int t=0;t<2;t++)
   {
      MqlRates rates[];int copied=CopyRates(names_audit[s],frames[t],1,2200,rates);
      int rfile=FileOpen("DemoAutopilot\\audit-"+names_audit[s]+"-"+IntegerToString((int)frames[t])+".csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
      if(rfile==INVALID_HANDLE)continue;
      FileWrite(rfile,"bar_open_server","open","high","low","close","tick_volume","spread_points");
      for(int k=0;k<copied;k++)FileWrite(rfile,TimeToString(rates[k].time,TIME_DATE|TIME_SECONDS),DoubleToString(rates[k].open,8),
         DoubleToString(rates[k].high,8),DoubleToString(rates[k].low,8),DoubleToString(rates[k].close,8),rates[k].tick_volume,rates[k].spread);
      FileFlush(rfile);FileClose(rfile);
   }
   int status_file=FileOpen("DemoAutopilot\\audit-summary.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(status_file!=INVALID_HANDLE){FileWriteString(status_file,"{\"expected_demo\":true,\"history_trades_exported\":"+IntegerToString(exported)+
      ",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"open_orders\":"+IntegerToString(OrdersTotal())+",\"actual_order_operations\":0}");FileClose(status_file);}
}




void OnStart(){eq_path="DemoAutopilot\\test-v014-main-quality-"+IntegerToString(GetTickCount())+".csv";ep_root="DemoAutopilot\\test-v014-main-"+IntegerToString(GetTickCount())+"-";RunCoreTests();RunExecutionTests();RunUpgradeTests();RunProtectionTests();RunTimingTests();RunAlignedTests();RunQualityTests();RunEntryReserveTests();RunAuthorizedBudgetTests();RunCapital150Tests();Print("V09 checks: ",passed+exec_passed," passed / ",failed+exec_failed," failed; zero real order operations.");}
