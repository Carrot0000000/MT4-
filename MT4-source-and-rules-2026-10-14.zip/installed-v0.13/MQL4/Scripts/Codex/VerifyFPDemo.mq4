#property strict
#property version "1.000"
// Read-only verification for the demo account created at the user's request.
string Number(double x){return MathIsValidNumber(x)?DoubleToString(x,8):"null";}
void OnStart()
{
   if(IsTesting() || AccountNumber()!=48530368 || AccountServer()!="FPMarketsLtd-Demo2" ||
      AccountInfoInteger(ACCOUNT_TRADE_MODE)!=ACCOUNT_TRADE_MODE_DEMO || AccountCurrency()!="USD")return;
   for(int tries=0;tries<30 && !IsConnected();tries++)Sleep(1000);
   if(!IsConnected())return;
   string specs="[";int found=0;
   for(int i=0;i<SymbolsTotal(false);i++)
   {
      string s=SymbolName(i,false);
      if(StringFind(s,"XAUUSD")!=0 && StringFind(s,"XAGUSD")!=0)continue;
      SymbolSelect(s,true);
      if(found++>0)specs+=",";
      specs+="{\"symbol\":\""+s+"\",\"contract_size\":"+Number(MarketInfo(s,MODE_LOTSIZE))+
         ",\"minimum_lots\":"+Number(MarketInfo(s,MODE_MINLOT))+",\"lot_step\":"+Number(MarketInfo(s,MODE_LOTSTEP))+
         ",\"tick_size\":"+Number(SymbolInfoDouble(s,SYMBOL_TRADE_TICK_SIZE))+",\"tick_value_usd\":"+Number(MarketInfo(s,MODE_TICKVALUE))+
         ",\"margin_required_per_lot_usd\":"+Number(MarketInfo(s,MODE_MARGINREQUIRED))+
         ",\"trade_allowed\":"+(MarketInfo(s,MODE_TRADEALLOWED)>0?"true":"false")+"}";
   }
   string json="{\"login\":"+IntegerToString(AccountNumber())+",\"server\":\""+AccountServer()+
      "\",\"demo\":true,\"currency\":\""+AccountCurrency()+"\",\"leverage\":"+IntegerToString(AccountLeverage())+
      ",\"balance\":"+Number(AccountBalance())+",\"open_orders\":"+IntegerToString(OrdersTotal())+
      ",\"connected\":true,\"local_time\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+"\",\"order_operations\":0,\"symbols\":"+specs+"]}";
   FolderCreate("FPDemoVerify");
   int f=FileOpen("FPDemoVerify\\account.json",FILE_WRITE|FILE_TXT|FILE_ANSI,',',CP_UTF8);
   if(f!=INVALID_HANDLE){FileWriteString(f,json);FileFlush(f);FileClose(f);}
}
