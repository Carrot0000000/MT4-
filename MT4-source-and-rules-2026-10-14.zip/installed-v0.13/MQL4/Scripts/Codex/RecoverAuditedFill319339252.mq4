#property strict
#include <Codex/AutopilotCore.mqh>
#include <Codex/SnapshotWriter.mqh>
// One incident only. Zero order calls. Never a generic clear-all-halts utility.
void OnStart()
{
   string k="AP02.48530368.";bool recovered=false;string why="checks failed";
   if(!APIdentity(AccountInfoInteger(ACCOUNT_TRADE_MODE),AccountNumber(),AccountServer(),IsTesting())||AccountCurrency()!="USD"||AccountLeverage()!=500)
      why="wrong demo identity";
   else if(!IsConnected()||!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)||OrdersTotal()!=0||GlobalVariableGet(k+"last_live_ticket")!=0||GlobalVariableGet(k+"owner")!=1)
      why="not connected or not confirmed flat";
   else if(!OrderSelect(319339252,SELECT_BY_TICKET)||OrderCloseTime()==0||OrderSymbol()!="XAUUSD"||OrderMagicNumber()!=2026101217||
      MathAbs(OrderLots()-.01)>1e-8||MathAbs(OrderProfit()+OrderCommission()+OrderSwap()+.47)>.001||
      MathAbs(GlobalVariableGet(k+"initial_R.319339252")-5.10)>.001||
      GlobalVariableGet(k+"exit_intent.319339252")!=AP_EXIT_FILL||!GlobalVariableCheck(k+"journal_closed.319339252"))
      why="audited incident does not match closed native history";
   else
   {
      // The native snapshot supplies the deployed revision; history checks above are live.
      int sf=FileOpen("DemoAutopilot\\status.json",FILE_READ|FILE_TXT|FILE_ANSI,',',CP_UTF8);
      string status=sf==INVALID_HANDLE?"":FileReadString(sf);if(sf!=INVALID_HANDLE)FileClose(sf);
      if(StringFind(status,"\"version\":\"0.12\"")<0||StringFind(status,"\"owner\":true")<0||StringFind(status,"\"auto_entries_input\":true")<0)
         why="new entry reserve version is not active";
      else if(GlobalVariableGet(k+"halt")!=1)why="halt already clear or unexpected value";
      else
      {recovered=GlobalVariableSetOnCondition(k+"halt",0,1);GlobalVariablesFlush();why=recovered?"audited fill-risk incident recovered; manual pause preserved":"halt changed concurrently";}
   }
   WriteSnapshot("DemoAutopilot\\recovery-319339252.json","{\"recovered\":"+(recovered?"true":"false")+",\"reason\":\""+why+"\",\"actual_order_operations\":0}");
   Print("Audited incident recovery: ",why);
}
