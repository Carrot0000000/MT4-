#ifndef CODEX_CAPITAL150_V014
#define CODEX_CAPITAL150_V014
// USD 150 initial practice capital with the unchanged USD 15 maximum planned risk.
double APCapital150Budget(const double balance,const double equity,const double capital,const double percent)
{
   if(!MathIsValidNumber(balance)||!MathIsValidNumber(equity)||!MathIsValidNumber(capital)||
      !MathIsValidNumber(percent)||balance<=0||equity<=0||capital<=0||capital>150||percent<=0||percent>10)return 0;
   return MathMin(capital,MathMin(balance,equity))*percent/100;
}
#endif
