﻿// Local demo-only protection. Does not change position sizing or order parameters.
#ifndef POSITION_SIZER_DEMO_GUARD_MQH
#define POSITION_SIZER_DEMO_GUARD_MQH
bool PSDemoTradingAllowed(const bool show_message = false)
{
    ResetLastError();
    const bool connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
    const long login = AccountInfoInteger(ACCOUNT_LOGIN);
    const long mode = AccountInfoInteger(ACCOUNT_TRADE_MODE);
    const bool account_trade_allowed = (bool)AccountInfoInteger(ACCOUNT_TRADE_ALLOWED);
    const bool account_expert_allowed = (bool)AccountInfoInteger(ACCOUNT_TRADE_EXPERT);
    const int query_error = GetLastError();
    const bool allowed = (query_error == 0 && connected && login > 0
                          && mode == ACCOUNT_TRADE_MODE_DEMO
                          && account_trade_allowed && account_expert_allowed);
    if (!allowed && show_message)
        Alert("模拟保护：仅限已连接且允许交易的模拟账户；当前操作已取消。");
    return allowed;
}
#endif
