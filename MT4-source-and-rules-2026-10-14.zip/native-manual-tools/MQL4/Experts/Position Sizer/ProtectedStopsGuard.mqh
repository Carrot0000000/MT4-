﻿// Local validation only: never changes prices, sends orders, or removes stops.
#ifndef POSITION_SIZER_PROTECTED_STOPS_GUARD_MQH
#define POSITION_SIZER_PROTECTED_STOPS_GUARD_MQH
bool PSAttachedStopsAreValid(const int order_type, const double entry, const double sl, const double tp)
{
    if (!MathIsValidNumber(entry) || !MathIsValidNumber(sl) || !MathIsValidNumber(tp)) return false;
    if (entry <= 0 || sl <= 0 || tp <= 0) return false;
    if (order_type == OP_BUY || order_type == OP_BUYLIMIT || order_type == OP_BUYSTOP)
        return (sl < entry && entry < tp);
    if (order_type == OP_SELL || order_type == OP_SELLLIMIT || order_type == OP_SELLSTOP)
        return (tp < entry && entry < sl);
    return false;
}
#endif
