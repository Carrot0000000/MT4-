#property strict
#property version "1.000"
// Login verification only. Contains no order mutation calls.
void OnStart()
{
   for(int i=0;i<100;i++)
   {
      if(IsConnected()&&AccountNumber()==52426128&&AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL)break;
      Sleep(200);
   }
   bool exact=AccountNumber()==52426128&&AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL&&
      (AccountServer()=="FPMarkets-Live5"||AccountServer()=="FPMarketsLtd-Live5")&&!IsTesting();
   FolderCreate("RealManualLogin");
   int f=FileOpen("RealManualLogin\\status.json",FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_SHARE_READ,',',CP_UTF8);
   if(f==INVALID_HANDLE)return;
   FileWriteString(f,"{\"checked_local\":\""+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+"\",\"expected_real_login\":"+(exact?"true":"false")+
      ",\"connected\":"+(IsConnected()?"true":"false")+",\"login\":"+IntegerToString(AccountNumber())+",\"server\":\""+AccountServer()+
      "\",\"account_trade_mode\":"+IntegerToString((int)AccountInfoInteger(ACCOUNT_TRADE_MODE))+",\"currency\":\""+AccountCurrency()+
      "\",\"balance\":"+DoubleToString(AccountBalance(),2)+",\"equity\":"+DoubleToString(AccountEquity(),2)+
      ",\"leverage\":"+IntegerToString(AccountLeverage())+",\"open_orders\":"+IntegerToString(OrdersTotal())+
      ",\"global_auto_trading\":"+(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)?"true":"false")+",\"actual_order_operations\":0}");
   FileFlush(f);FileClose(f);
}
